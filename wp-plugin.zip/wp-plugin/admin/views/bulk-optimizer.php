<?php
/**
 * Bulk optimizer page template.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

$stats = MPIO_Bulk_Optimizer::get_instance()->get_stats();
$is_running = MPIO_Bulk_Optimizer::get_instance()->is_running();
?>
<div class="wrap mpio-wrap">
    <h1 class="mpio-page-title">
        <span class="mpio-logo">&#9889;</span>
        <?php esc_html_e( 'Bulk Optimization', 'mpire-image-optimizer' ); ?>
    </h1>

    <!-- Stats Overview -->
    <div class="mpio-stats-grid">
        <div class="mpio-stat-card">
            <div class="mpio-stat-number" id="mpio-stat-total"><?php echo esc_html( $stats['total_images'] ); ?></div>
            <div class="mpio-stat-label"><?php esc_html_e( 'Total Images', 'mpire-image-optimizer' ); ?></div>
        </div>
        <div class="mpio-stat-card mpio-stat-success">
            <div class="mpio-stat-number" id="mpio-stat-optimized"><?php echo esc_html( $stats['optimized'] ); ?></div>
            <div class="mpio-stat-label"><?php esc_html_e( 'Optimized', 'mpire-image-optimizer' ); ?></div>
        </div>
        <div class="mpio-stat-card mpio-stat-warning">
            <div class="mpio-stat-number" id="mpio-stat-unoptimized"><?php echo esc_html( $stats['unoptimized'] ); ?></div>
            <div class="mpio-stat-label"><?php esc_html_e( 'Unoptimized', 'mpire-image-optimizer' ); ?></div>
        </div>
        <div class="mpio-stat-card mpio-stat-error">
            <div class="mpio-stat-number" id="mpio-stat-errors"><?php echo esc_html( $stats['errors'] ); ?></div>
            <div class="mpio-stat-label"><?php esc_html_e( 'Errors', 'mpire-image-optimizer' ); ?></div>
        </div>
        <div class="mpio-stat-card mpio-stat-info">
            <div class="mpio-stat-number" id="mpio-stat-savings">
                <?php
                $savings = $stats['total_original_size'] > 0
                    ? round( ( ( $stats['total_original_size'] - $stats['total_optimized_size'] ) / $stats['total_original_size'] ) * 100, 1 )
                    : 0;
                echo esc_html( $savings . '%' );
                ?>
            </div>
            <div class="mpio-stat-label"><?php esc_html_e( 'Total Savings', 'mpire-image-optimizer' ); ?></div>
        </div>
    </div>

    <!-- Bulk Actions -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'Bulk Actions', 'mpire-image-optimizer' ); ?></h3>

        <?php if ( $stats['unoptimized'] > 0 ) : ?>
            <p>
                <?php
                printf(
                    /* translators: %d: number of images */
                    esc_html__( 'You have %d images that can be optimized.', 'mpire-image-optimizer' ),
                    $stats['unoptimized']
                );
                ?>
            </p>
        <?php else : ?>
            <p class="mpio-all-done"><?php esc_html_e( 'All images are optimized! Nothing to do.', 'mpire-image-optimizer' ); ?></p>
        <?php endif; ?>

        <div class="mpio-bulk-controls">
            <button type="button" id="mpio-bulk-start" class="button button-primary mpio-btn-primary" <?php echo $is_running ? 'style="display:none"' : ''; ?> <?php echo $stats['unoptimized'] < 1 ? 'disabled' : ''; ?>>
                <?php esc_html_e( 'Start Bulk Optimization', 'mpire-image-optimizer' ); ?>
            </button>
            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-ajax.php?action=mpio_export_csv' ), 'mpio_nonce', 'nonce' ) ); ?>" class="button button-secondary">
                <?php esc_html_e( 'Export CSV', 'mpire-image-optimizer' ); ?>
            </a>
            <button type="button" id="mpio-bulk-stop" class="button button-secondary" <?php echo ! $is_running ? 'style="display:none"' : ''; ?>>
                <?php esc_html_e( 'Stop', 'mpire-image-optimizer' ); ?>
            </button>
            <?php if ( $stats['optimized'] > 0 ) : ?>
            <button type="button" id="mpio-bulk-restore-all" class="button button-secondary" style="color:#ef4444;border-color:#ef4444<?php echo $is_running ? ';display:none' : ''; ?>">
                <?php esc_html_e( 'Restore All Originals', 'mpire-image-optimizer' ); ?>
            </button>
            <?php endif; ?>
        </div>

        <!-- Progress -->
        <div id="mpio-bulk-progress" class="mpio-progress-wrap" <?php echo ! $is_running ? 'style="display:none"' : ''; ?>>
            <div class="mpio-progress-bar">
                <div class="mpio-progress-fill" id="mpio-progress-fill" style="width: 0%"></div>
            </div>
            <div class="mpio-progress-text">
                <span id="mpio-progress-percent">0%</span>
                <span id="mpio-progress-count">0 / 0</span>
            </div>
            <div class="mpio-progress-details">
                <span><?php esc_html_e( 'Success:', 'mpire-image-optimizer' ); ?> <strong id="mpio-progress-success">0</strong></span>
                <span><?php esc_html_e( 'Errors:', 'mpire-image-optimizer' ); ?> <strong id="mpio-progress-errors">0</strong></span>
                <span><?php esc_html_e( 'Elapsed:', 'mpire-image-optimizer' ); ?> <strong id="mpio-progress-elapsed">0s</strong></span>
            </div>
        </div>

        <!-- Log -->
        <div id="mpio-bulk-log" class="mpio-log" style="display:none">
            <h4><?php esc_html_e( 'Activity Log', 'mpire-image-optimizer' ); ?></h4>
            <div id="mpio-log-entries" class="mpio-log-entries"></div>
        </div>
    </div>

    <!-- Debug Log Viewer -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'Debug Log', 'mpire-image-optimizer' ); ?></h3>
        <?php
        $logger   = MPIO_Logger::get_instance();
        $log_lines = $logger->get_recent( 100 );
        if ( ! empty( $log_lines ) ) :
        ?>
        <div class="mpio-log-entries">
            <?php foreach ( array_reverse( $log_lines ) as $line ) :
                $cls = '';
                if ( strpos( $line, '[ERROR]' ) !== false ) {
                    $cls = 'mpio-log-error';
                } elseif ( strpos( $line, '[WARNING]' ) !== false ) {
                    $cls = 'mpio-log-warning';
                } elseif ( strpos( $line, '[INFO]' ) !== false ) {
                    $cls = 'mpio-log-success';
                }
            ?>
                <div class="mpio-log-entry <?php echo esc_attr( $cls ); ?>"><?php echo esc_html( $line ); ?></div>
            <?php endforeach; ?>
        </div>
        <p class="mpio-field-desc" style="margin-top:8px">
            <?php printf( esc_html__( 'Log size: %s', 'mpire-image-optimizer' ), esc_html( mpio_format_bytes( $logger->get_log_size() ) ) ); ?>
        </p>
        <?php else : ?>
        <p class="mpio-field-desc"><?php esc_html_e( 'No log entries yet. Run an optimization to generate logs.', 'mpire-image-optimizer' ); ?></p>
        <?php endif; ?>
    </div>
</div>
