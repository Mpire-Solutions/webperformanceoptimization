<?php
/**
 * Settings page template.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

$settings    = get_option( 'mpio_settings', mpio_get_default_settings() );
$engine_info = MPIO_Admin::get_engine_info();
?>
<div class="wrap mpio-wrap">
    <h1 class="mpio-page-title">
        <span class="mpio-logo">&#9889;</span>
        <?php esc_html_e( 'Mpire Image Optimizer', 'mpire-image-optimizer' ); ?>
        <span class="mpio-version">v<?php echo esc_html( MPIO_VERSION ); ?></span>
    </h1>

    <div class="mpio-settings-layout">
        <!-- Sidebar: Engine Info -->
        <div class="mpio-sidebar">
            <div class="mpio-card">
                <h3><?php esc_html_e( 'Engine Status', 'mpire-image-optimizer' ); ?></h3>
                <table class="mpio-info-table">
                    <tr>
                        <td><?php esc_html_e( 'Active Engine', 'mpire-image-optimizer' ); ?></td>
                        <td><strong><?php echo esc_html( ucfirst( $engine_info['current_engine'] ) ); ?></strong></td>
                    </tr>
                    <tr>
                        <td><?php esc_html_e( 'GD Library', 'mpire-image-optimizer' ); ?></td>
                        <td><?php echo $engine_info['gd_available'] ? '<span class="mpio-badge mpio-badge-success">Available</span>' : '<span class="mpio-badge mpio-badge-error">Not Available</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><?php esc_html_e( 'Imagick', 'mpire-image-optimizer' ); ?></td>
                        <td><?php echo $engine_info['imagick_available'] ? '<span class="mpio-badge mpio-badge-success">Available</span>' : '<span class="mpio-badge mpio-badge-error">Not Available</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><?php esc_html_e( 'PHP Version', 'mpire-image-optimizer' ); ?></td>
                        <td><?php echo esc_html( $engine_info['php_version'] ); ?></td>
                    </tr>
                    <tr>
                        <td><?php esc_html_e( 'Memory Limit', 'mpire-image-optimizer' ); ?></td>
                        <td><?php echo esc_html( $engine_info['memory_limit'] ); ?></td>
                    </tr>
                    <tr>
                        <td><?php esc_html_e( 'Max Upload', 'mpire-image-optimizer' ); ?></td>
                        <td><?php echo esc_html( mpio_format_bytes( $engine_info['max_upload'] ) ); ?></td>
                    </tr>
                </table>

                <h4><?php esc_html_e( 'Format Support', 'mpire-image-optimizer' ); ?></h4>
                <?php
                $formats_source = 'imagick' === $engine_info['current_engine'] ? $engine_info['imagick_formats'] : $engine_info['gd_formats'];
                if ( ! empty( $formats_source ) ) :
                ?>
                <div class="mpio-format-badges">
                    <?php foreach ( $formats_source as $format => $supported ) : ?>
                        <span class="mpio-badge <?php echo $supported ? 'mpio-badge-success' : 'mpio-badge-muted'; ?>">
                            <?php echo esc_html( strtoupper( $format ) ); ?>
                        </span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <div class="mpio-card">
                <h3><?php esc_html_e( 'Quick Links', 'mpire-image-optimizer' ); ?></h3>
                <ul class="mpio-quick-links">
                    <li><a href="<?php echo esc_url( admin_url( 'options-general.php?page=mpio-getting-started' ) ); ?>"><?php esc_html_e( 'Getting Started', 'mpire-image-optimizer' ); ?></a></li>
                    <li><a href="<?php echo esc_url( admin_url( 'upload.php?page=mpio-bulk-optimizer' ) ); ?>"><?php esc_html_e( 'Bulk Optimize', 'mpire-image-optimizer' ); ?></a></li>
                    <li><a href="<?php echo esc_url( admin_url( 'upload.php?page=mpio-batch-converter' ) ); ?>"><?php esc_html_e( 'Batch Converter', 'mpire-image-optimizer' ); ?></a></li>
                    <li><a href="<?php echo esc_url( admin_url( 'upload.php?page=mpio-custom-folders' ) ); ?>"><?php esc_html_e( 'Custom Folders', 'mpire-image-optimizer' ); ?></a></li>
                    <li><a href="<?php echo esc_url( admin_url( 'upload.php' ) ); ?>"><?php esc_html_e( 'Media Library', 'mpire-image-optimizer' ); ?></a></li>
                </ul>
            </div>
        </div>

        <!-- Main Settings Form -->
        <div class="mpio-main">
            <form method="post" action="options.php" id="mpio-settings-form">
                <?php settings_fields( 'mpio-settings' ); ?>

                <!-- General Settings -->
                <div class="mpio-card">
                    <h3><?php esc_html_e( 'General Settings', 'mpire-image-optimizer' ); ?></h3>

                    <div class="mpio-field">
                        <label class="mpio-toggle">
                            <input type="checkbox" name="mpio_settings[auto_optimize]" value="1" <?php checked( $settings['auto_optimize'] ?? true ); ?>>
                            <span class="mpio-toggle-slider"></span>
                            <?php esc_html_e( 'Auto-optimize on upload', 'mpire-image-optimizer' ); ?>
                            <a href="#" class="mpio-help-tip" onclick="return false">?<span class="mpio-tooltip"><?php esc_html_e( 'When enabled, every image you upload through the Media Library, post editor, or WooCommerce will be automatically optimized. A backup of the original is kept so you can restore anytime.', 'mpire-image-optimizer' ); ?></span></a>
                        </label>
                        <p class="mpio-field-desc"><?php esc_html_e( 'Automatically optimize images when uploaded to the Media Library.', 'mpire-image-optimizer' ); ?></p>
                    </div>

                    <div class="mpio-field">
                        <label><?php esc_html_e( 'Optimization Level', 'mpire-image-optimizer' ); ?></label>
                        <div class="mpio-radio-group">
                            <?php
                            $levels = [
                                'lossless' => [
                                    __( 'Max Quality', 'mpire-image-optimizer' ),
                                    __( 'Lossless compression. No visible quality loss. Smaller file size savings (~10-20%).', 'mpire-image-optimizer' ),
                                    '100%',
                                    '#10b981',
                                ],
                                'lossy'    => [
                                    __( 'Recommended', 'mpire-image-optimizer' ),
                                    __( 'Best balance of quality and size. Virtually indistinguishable from original (~40-60% savings).', 'mpire-image-optimizer' ),
                                    '80%',
                                    '#4f46e5',
                                ],
                                'ultra'    => [
                                    __( 'Max Compression', 'mpire-image-optimizer' ),
                                    __( 'Aggressive compression for maximum savings. Some quality loss may be visible (~60-80% savings).', 'mpire-image-optimizer' ),
                                    '60%',
                                    '#f59e0b',
                                ],
                            ];
                            foreach ( $levels as $value => $label ) :
                            ?>
                                <label class="mpio-radio-card <?php echo ( $settings['optimization_level'] ?? 'lossy' ) === $value ? 'active' : ''; ?>" data-quality="<?php echo esc_attr( $label[2] ); ?>">
                                    <input type="radio" name="mpio_settings[optimization_level]" value="<?php echo esc_attr( $value ); ?>" <?php checked( $settings['optimization_level'] ?? 'lossy', $value ); ?> data-quality="<?php echo esc_attr( intval( $label[2] ) ); ?>">
                                    <?php if ( 'lossy' === $value ) : ?><span class="mpio-preset-badge" style="background:<?php echo esc_attr( $label[3] ); ?>;color:#fff"><?php esc_html_e( 'RECOMMENDED', 'mpire-image-optimizer' ); ?></span><?php endif; ?>
                                    <strong><?php echo esc_html( $label[0] ); ?></strong>
                                    <span><?php echo esc_html( $label[1] ); ?></span>
                                    <span class="mpio-radio-card-quality" style="color:<?php echo esc_attr( $label[3] ); ?>">Quality: <?php echo esc_html( $label[2] ); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="mpio-field">
                        <label for="mpio-quality"><?php esc_html_e( 'Quality', 'mpire-image-optimizer' ); ?>: <span id="mpio-quality-value"><?php echo esc_html( $settings['quality'] ?? 80 ); ?></span>%</label>
                        <input type="range" id="mpio-quality" name="mpio_settings[quality]" min="1" max="100" value="<?php echo esc_attr( $settings['quality'] ?? 80 ); ?>" class="mpio-range">
                        <div class="mpio-range-labels">
                            <span><?php esc_html_e( 'Smaller', 'mpire-image-optimizer' ); ?></span>
                            <span><?php esc_html_e( 'Higher Quality', 'mpire-image-optimizer' ); ?></span>
                        </div>
                    </div>

                    <div class="mpio-field-row">
                        <div class="mpio-field">
                            <label class="mpio-toggle">
                                <input type="checkbox" name="mpio_settings[strip_exif]" value="1" <?php checked( $settings['strip_exif'] ?? true ); ?>>
                                <span class="mpio-toggle-slider"></span>
                                <?php esc_html_e( 'Strip EXIF metadata', 'mpire-image-optimizer' ); ?>
                            <a href="#" class="mpio-help-tip" onclick="return false">?<span class="mpio-tooltip"><?php esc_html_e( 'EXIF data includes camera info, GPS location, date taken, etc. Stripping it reduces file size and removes potentially sensitive location data. Disable if you need to preserve photo metadata (e.g., photography portfolios).', 'mpire-image-optimizer' ); ?></span></a>
                            </label>
                        </div>
                        <div class="mpio-field">
                            <label class="mpio-toggle">
                                <input type="checkbox" name="mpio_settings[slugify_filenames]" value="1" <?php checked( $settings['slugify_filenames'] ?? false ); ?>>
                                <span class="mpio-toggle-slider"></span>
                                <?php esc_html_e( 'Slugify filenames', 'mpire-image-optimizer' ); ?>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Backup Settings -->
                <div class="mpio-card">
                    <h3><?php esc_html_e( 'Backup', 'mpire-image-optimizer' ); ?></h3>
                    <div class="mpio-field">
                        <label class="mpio-toggle">
                            <input type="checkbox" name="mpio_settings[keep_backup]" value="1" <?php checked( $settings['keep_backup'] ?? true ); ?>>
                            <span class="mpio-toggle-slider"></span>
                            <?php esc_html_e( 'Keep backup of originals', 'mpire-image-optimizer' ); ?>
                        </label>
                        <p class="mpio-field-desc"><?php esc_html_e( 'Store a backup so you can restore original images later.', 'mpire-image-optimizer' ); ?></p>
                    </div>
                    <div class="mpio-field">
                        <label for="mpio-backup-days"><?php esc_html_e( 'Keep backups for (days)', 'mpire-image-optimizer' ); ?></label>
                        <input type="number" id="mpio-backup-days" name="mpio_settings[backup_days]" value="<?php echo esc_attr( $settings['backup_days'] ?? 30 ); ?>" min="0" max="365" class="small-text">
                        <p class="mpio-field-desc"><?php esc_html_e( '0 = keep forever.', 'mpire-image-optimizer' ); ?></p>
                    </div>
                </div>

                <!-- Format Conversion -->
                <div class="mpio-card">
                    <h3><?php esc_html_e( 'Format Conversion', 'mpire-image-optimizer' ); ?></h3>

                    <div class="mpio-field">
                        <label><?php esc_html_e( 'Output Format', 'mpire-image-optimizer' ); ?></label>
                        <select name="mpio_settings[output_format]" class="mpio-select">
                            <option value="original" <?php selected( $settings['output_format'] ?? 'original', 'original' ); ?>><?php esc_html_e( 'Keep Original Format', 'mpire-image-optimizer' ); ?></option>
                            <option value="webp" <?php selected( $settings['output_format'] ?? 'original', 'webp' ); ?>>WebP</option>
                            <option value="avif" <?php selected( $settings['output_format'] ?? 'original', 'avif' ); ?>>AVIF</option>
                            <option value="jpeg" <?php selected( $settings['output_format'] ?? 'original', 'jpeg' ); ?>>JPEG</option>
                            <option value="png" <?php selected( $settings['output_format'] ?? 'original', 'png' ); ?>>PNG</option>
                        </select>
                    </div>

                    <div class="mpio-field-row">
                        <div class="mpio-field">
                            <label class="mpio-toggle">
                                <input type="checkbox" name="mpio_settings[convert_to_webp]" value="1" <?php checked( $settings['convert_to_webp'] ?? true ); ?>>
                                <span class="mpio-toggle-slider"></span>
                                <?php esc_html_e( 'Also create WebP version', 'mpire-image-optimizer' ); ?>
                            <a href="#" class="mpio-help-tip" onclick="return false">?<span class="mpio-tooltip"><?php esc_html_e( 'Creates a .webp copy alongside the original. WebP is supported by all modern browsers and is typically 25-35% smaller than JPEG. The plugin automatically serves WebP to supported browsers via <picture> tags or server rewrite rules.', 'mpire-image-optimizer' ); ?></span></a>
                            </label>
                        </div>
                        <div class="mpio-field">
                            <label class="mpio-toggle">
                                <input type="checkbox" name="mpio_settings[convert_to_avif]" value="1" <?php checked( $settings['convert_to_avif'] ?? false ); ?>>
                                <span class="mpio-toggle-slider"></span>
                                <?php esc_html_e( 'Also create AVIF version', 'mpire-image-optimizer' ); ?>
                            <a href="#" class="mpio-help-tip" onclick="return false">?<span class="mpio-tooltip"><?php esc_html_e( 'AVIF is a next-gen format that offers even better compression than WebP (~50% smaller than JPEG). Browser support is growing but not universal yet. Requires PHP 8.1+ with GD or Imagick with AVIF support.', 'mpire-image-optimizer' ); ?></span></a>
                            </label>
                        </div>
                    </div>

                    <div class="mpio-field">
                        <label class="mpio-toggle">
                            <input type="checkbox" name="mpio_settings[delete_original]" value="1" <?php checked( $settings['delete_original'] ?? false ); ?>>
                            <span class="mpio-toggle-slider"></span>
                            <?php esc_html_e( 'Delete original after conversion', 'mpire-image-optimizer' ); ?>
                            <a href="#" class="mpio-help-tip" onclick="return false">?<span class="mpio-tooltip"><?php esc_html_e( 'Removes the original JPEG/PNG file after creating the WebP/AVIF version. Saves disk space but means older browsers that don\'t support WebP/AVIF won\'t be able to display the image. Only recommended if you\'re sure all your visitors use modern browsers.', 'mpire-image-optimizer' ); ?></span></a>
                        </label>
                        <p class="mpio-field-desc mpio-warning"><?php esc_html_e( 'Warning: This will remove the original format file. Backup recommended.', 'mpire-image-optimizer' ); ?></p>
                    </div>
                </div>

                <!-- Display / Serving -->
                <div class="mpio-card">
                    <h3><?php esc_html_e( 'Image Serving', 'mpire-image-optimizer' ); ?></h3>
                    <p class="mpio-field-desc" style="margin-bottom:16px"><?php esc_html_e( 'How converted WebP/AVIF images are served to visitors. This automatically updates all pages to use the new formats.', 'mpire-image-optimizer' ); ?></p>

                    <div class="mpio-field">
                        <label><?php esc_html_e( 'Display Mode', 'mpire-image-optimizer' ); ?></label>
                        <div class="mpio-radio-group">
                            <?php
                            $modes = [
                                'picture' => [ __( 'Picture Tags', 'mpire-image-optimizer' ), __( 'Rewrites <img> to <picture> with WebP/AVIF sources. Works on all servers.', 'mpire-image-optimizer' ) ],
                                'rewrite' => [ __( 'Server Rewrite', 'mpire-image-optimizer' ), __( 'Apache/Nginx rules serve next-gen formats transparently. No HTML changes.', 'mpire-image-optimizer' ) ],
                                'both'    => [ __( 'Both', 'mpire-image-optimizer' ), __( 'Use picture tags AND server rewrites for maximum compatibility.', 'mpire-image-optimizer' ) ],
                                'none'    => [ __( 'None', 'mpire-image-optimizer' ), __( 'Only optimize files. Don\'t change how they\'re served.', 'mpire-image-optimizer' ) ],
                            ];
                            foreach ( $modes as $value => $label ) :
                            ?>
                                <label class="mpio-radio-card <?php echo ( $settings['display_mode'] ?? 'picture' ) === $value ? 'active' : ''; ?>">
                                    <input type="radio" name="mpio_settings[display_mode]" value="<?php echo esc_attr( $value ); ?>" <?php checked( $settings['display_mode'] ?? 'picture', $value ); ?>>
                                    <strong><?php echo esc_html( $label[0] ); ?></strong>
                                    <span><?php echo esc_html( $label[1] ); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="mpio-field">
                        <label class="mpio-toggle">
                            <input type="checkbox" name="mpio_settings[rewrite_rules]" value="1" <?php checked( $settings['rewrite_rules'] ?? false ); ?>>
                            <span class="mpio-toggle-slider"></span>
                            <?php esc_html_e( 'Add server rewrite rules', 'mpire-image-optimizer' ); ?>
                        </label>
                        <p class="mpio-field-desc"><?php esc_html_e( 'Automatically add .htaccess rules (Apache/LiteSpeed) to serve WebP/AVIF. For Nginx, copy the config snippet below.', 'mpire-image-optimizer' ); ?></p>
                    </div>

                    <?php
                    $rewrite = MPIO_Rewrite_Rules::get_instance();
                    if ( $rewrite->is_nginx() ) :
                        $nginx_config = $rewrite->generate_nginx_config(
                            $settings['convert_to_webp'] ?? true,
                            $settings['convert_to_avif'] ?? false
                        );
                    ?>
                    <div class="mpio-field">
                        <label><?php esc_html_e( 'Nginx Configuration', 'mpire-image-optimizer' ); ?></label>
                        <p class="mpio-field-desc"><?php esc_html_e( 'Copy this into your nginx server {} block:', 'mpire-image-optimizer' ); ?></p>
                        <textarea readonly class="large-text code" rows="12" style="font-family:monospace;font-size:12px;background:#f1f5f9"><?php echo esc_textarea( $nginx_config ); ?></textarea>
                    </div>
                    <?php endif; ?>

                    <?php if ( $rewrite->has_htaccess_rules() ) : ?>
                    <div class="mpio-field">
                        <span class="mpio-badge mpio-badge-success"><?php esc_html_e( 'Rewrite rules active in .htaccess', 'mpire-image-optimizer' ); ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Resize -->
                <div class="mpio-card">
                    <h3><?php esc_html_e( 'Resize', 'mpire-image-optimizer' ); ?></h3>
                    <div class="mpio-field">
                        <label class="mpio-toggle">
                            <input type="checkbox" name="mpio_settings[resize_enabled]" value="1" <?php checked( $settings['resize_enabled'] ?? false ); ?>>
                            <span class="mpio-toggle-slider"></span>
                            <?php esc_html_e( 'Resize large images', 'mpire-image-optimizer' ); ?>
                        </label>
                        <p class="mpio-field-desc"><?php esc_html_e( 'Downscale images exceeding max dimensions (maintains aspect ratio).', 'mpire-image-optimizer' ); ?></p>
                    </div>
                    <div class="mpio-field-row">
                        <div class="mpio-field">
                            <label for="mpio-max-width"><?php esc_html_e( 'Max Width (px)', 'mpire-image-optimizer' ); ?></label>
                            <input type="number" id="mpio-max-width" name="mpio_settings[resize_max_width]" value="<?php echo esc_attr( $settings['resize_max_width'] ?? 2560 ); ?>" min="100" max="10000" class="small-text">
                        </div>
                        <div class="mpio-field">
                            <label for="mpio-max-height"><?php esc_html_e( 'Max Height (px)', 'mpire-image-optimizer' ); ?></label>
                            <input type="number" id="mpio-max-height" name="mpio_settings[resize_max_height]" value="<?php echo esc_attr( $settings['resize_max_height'] ?? 2560 ); ?>" min="100" max="10000" class="small-text">
                        </div>
                    </div>
                </div>

                <!-- Watermark -->
                <div class="mpio-card">
                    <h3><?php esc_html_e( 'Watermark', 'mpire-image-optimizer' ); ?></h3>
                    <div class="mpio-field">
                        <label class="mpio-toggle">
                            <input type="checkbox" name="mpio_settings[watermark_enabled]" value="1" <?php checked( $settings['watermark_enabled'] ?? false ); ?>>
                            <span class="mpio-toggle-slider"></span>
                            <?php esc_html_e( 'Enable watermark', 'mpire-image-optimizer' ); ?>
                        </label>
                    </div>
                    <div class="mpio-field">
                        <label for="mpio-watermark-text"><?php esc_html_e( 'Watermark Text', 'mpire-image-optimizer' ); ?></label>
                        <input type="text" id="mpio-watermark-text" name="mpio_settings[watermark_text]" value="<?php echo esc_attr( $settings['watermark_text'] ?? '' ); ?>" class="regular-text">
                    </div>
                    <div class="mpio-field-row">
                        <div class="mpio-field">
                            <label for="mpio-watermark-position"><?php esc_html_e( 'Position', 'mpire-image-optimizer' ); ?></label>
                            <select id="mpio-watermark-position" name="mpio_settings[watermark_position]" class="mpio-select">
                                <?php
                                $positions = [
                                    'top-left'     => __( 'Top Left', 'mpire-image-optimizer' ),
                                    'top-right'    => __( 'Top Right', 'mpire-image-optimizer' ),
                                    'center'       => __( 'Center', 'mpire-image-optimizer' ),
                                    'bottom-left'  => __( 'Bottom Left', 'mpire-image-optimizer' ),
                                    'bottom-right' => __( 'Bottom Right', 'mpire-image-optimizer' ),
                                ];
                                foreach ( $positions as $val => $lbl ) :
                                ?>
                                    <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $settings['watermark_position'] ?? 'bottom-right', $val ); ?>><?php echo esc_html( $lbl ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mpio-field">
                            <label for="mpio-watermark-opacity"><?php esc_html_e( 'Opacity', 'mpire-image-optimizer' ); ?>: <span id="mpio-opacity-value"><?php echo esc_html( $settings['watermark_opacity'] ?? 40 ); ?></span>%</label>
                            <input type="range" id="mpio-watermark-opacity" name="mpio_settings[watermark_opacity]" min="1" max="100" value="<?php echo esc_attr( $settings['watermark_opacity'] ?? 40 ); ?>" class="mpio-range">
                        </div>
                        <div class="mpio-field">
                            <label for="mpio-watermark-size"><?php esc_html_e( 'Font Size (px)', 'mpire-image-optimizer' ); ?></label>
                            <input type="number" id="mpio-watermark-size" name="mpio_settings[watermark_size]" value="<?php echo esc_attr( $settings['watermark_size'] ?? 16 ); ?>" min="8" max="72" class="small-text">
                        </div>
                    </div>
                </div>

                <!-- Bulk Settings -->
                <div class="mpio-card">
                    <h3><?php esc_html_e( 'Bulk Optimization', 'mpire-image-optimizer' ); ?></h3>
                    <div class="mpio-field-row">
                        <div class="mpio-field">
                            <label for="mpio-chunk-size"><?php esc_html_e( 'Images per batch', 'mpire-image-optimizer' ); ?></label>
                            <input type="number" id="mpio-chunk-size" name="mpio_settings[bulk_chunk_size]" value="<?php echo esc_attr( $settings['bulk_chunk_size'] ?? 5 ); ?>" min="1" max="50" class="small-text">
                        </div>
                        <div class="mpio-field">
                            <label class="mpio-toggle">
                                <input type="checkbox" name="mpio_settings[bulk_thumbnails]" value="1" <?php checked( $settings['bulk_thumbnails'] ?? true ); ?>>
                                <span class="mpio-toggle-slider"></span>
                                <?php esc_html_e( 'Also optimize thumbnails', 'mpire-image-optimizer' ); ?>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Advanced -->
                <div class="mpio-card">
                    <h3><?php esc_html_e( 'Advanced', 'mpire-image-optimizer' ); ?></h3>
                    <div class="mpio-field">
                        <label for="mpio-engine"><?php esc_html_e( 'Processing Engine', 'mpire-image-optimizer' ); ?></label>
                        <select id="mpio-engine" name="mpio_settings[preferred_engine]" class="mpio-select">
                            <option value="auto" <?php selected( $settings['preferred_engine'] ?? 'auto', 'auto' ); ?>><?php esc_html_e( 'Auto (prefer Imagick)', 'mpire-image-optimizer' ); ?></option>
                            <option value="gd" <?php selected( $settings['preferred_engine'] ?? 'auto', 'gd' ); ?>>GD Library</option>
                            <option value="imagick" <?php selected( $settings['preferred_engine'] ?? 'auto', 'imagick' ); ?>>Imagick</option>
                        </select>
                    </div>
                    <div class="mpio-field">
                        <label for="mpio-max-file-size"><?php esc_html_e( 'Max file size to optimize (KB)', 'mpire-image-optimizer' ); ?></label>
                        <input type="number" id="mpio-max-file-size" name="mpio_settings[max_file_size]" value="<?php echo esc_attr( $settings['max_file_size'] ?? 0 ); ?>" min="0" class="small-text">
                        <p class="mpio-field-desc"><?php esc_html_e( '0 = no limit. Files larger than this will be skipped.', 'mpire-image-optimizer' ); ?></p>
                    </div>
                    <div class="mpio-field">
                        <label for="mpio-exclude-patterns">
                            <?php esc_html_e( 'Exclude from optimization', 'mpire-image-optimizer' ); ?>
                            <a href="#" class="mpio-help-tip" onclick="return false">?<span class="mpio-tooltip"><?php esc_html_e( 'One pattern per line. Supports: exact filenames (logo.png), wildcards (banner-*), and path fragments (/uploads/logos/). Lines starting with # are ignored.', 'mpire-image-optimizer' ); ?></span></a>
                        </label>
                        <textarea id="mpio-exclude-patterns" name="mpio_settings[exclude_patterns]" rows="4" class="large-text code" placeholder="logo.png&#10;banner-*&#10;/uploads/originals/&#10;# Comment lines are ignored"><?php echo esc_textarea( $settings['exclude_patterns'] ?? '' ); ?></textarea>
                    </div>
                </div>

                <?php submit_button( __( 'Save Settings', 'mpire-image-optimizer' ), 'primary mpio-btn-primary', 'submit', true ); ?>
            </form>
        </div>
    </div>
</div>
