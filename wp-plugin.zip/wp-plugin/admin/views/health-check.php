<?php
/**
 * Health Check / Diagnostics page.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

$engine_info  = MPIO_Admin::get_engine_info();
$upload_dir   = wp_upload_dir();
$backup_dir   = $upload_dir['basedir'] . '/mpio-backups';
$backup_stats = MPIO_Backup::get_instance()->get_backup_stats();
$log_size     = MPIO_Logger::get_instance()->get_log_size();
$recent_logs  = MPIO_Logger::get_instance()->get_recent( 20 );
$conflicts    = MPIO_Admin_Notices::get_instance()->detect_conflicts();

// Run a test optimization if requested.
$test_result = null;
if ( isset( $_GET['mpio_test'] ) && wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'mpio_health_test' ) ) {
    $test_result = mpio_run_health_test();
}

function mpio_run_health_test(): array {
    // Find a small JPEG in the media library to test with.
    $test_image = get_posts( [
        'post_type'      => 'attachment',
        'post_mime_type' => 'image/jpeg',
        'posts_per_page' => 1,
        'orderby'        => 'rand',
        'fields'         => 'ids',
    ] );

    if ( empty( $test_image ) ) {
        return [ 'success' => false, 'message' => 'No JPEG images found in media library to test with.' ];
    }

    $attachment_id = $test_image[0];
    $file_path     = get_attached_file( $attachment_id );

    if ( ! $file_path || ! file_exists( $file_path ) ) {
        return [ 'success' => false, 'message' => 'Test image file not found on disk.' ];
    }

    // Copy to a temp file so we don't modify the original.
    $temp_file = wp_tempnam( $file_path );
    copy( $file_path, $temp_file );

    $start  = microtime( true );
    $result = MPIO_Optimizer::get_instance()->optimize_file( $temp_file );
    $time   = round( ( microtime( true ) - $start ) * 1000 );

    @unlink( $temp_file );

    if ( $result['success'] ) {
        return [
            'success'        => true,
            'message'        => sprintf( 'Test passed! Optimized in %dms. %s → %s (-%s%%)',
                $time,
                mpio_format_bytes( $result['original_size'] ),
                mpio_format_bytes( $result['optimized_size'] ),
                $result['original_size'] > 0
                    ? round( ( ( $result['original_size'] - $result['optimized_size'] ) / $result['original_size'] ) * 100, 1 )
                    : 0
            ),
            'time_ms'        => $time,
            'original_size'  => $result['original_size'],
            'optimized_size' => $result['optimized_size'],
        ];
    }

    return [ 'success' => false, 'message' => 'Optimization failed on test image.' ];
}
?>
<div class="wrap mpio-wrap">
    <h1 class="mpio-page-title">
        <span class="mpio-logo">&#9889;</span>
        <?php esc_html_e( 'Health Check', 'mpire-image-optimizer' ); ?>
    </h1>

    <?php if ( $test_result ) : ?>
        <div class="notice <?php echo $test_result['success'] ? 'notice-success' : 'notice-error'; ?> is-dismissible">
            <p><strong><?php echo esc_html( $test_result['message'] ); ?></strong></p>
        </div>
    <?php endif; ?>

    <!-- System Status -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'System Status', 'mpire-image-optimizer' ); ?></h3>
        <table class="widefat striped" style="max-width:600px">
            <tbody>
                <?php
                $checks = [
                    [ __( 'PHP Version', 'mpire-image-optimizer' ), $engine_info['php_version'], version_compare( PHP_VERSION, '7.4', '>=' ) ],
                    [ __( 'WordPress Version', 'mpire-image-optimizer' ), get_bloginfo( 'version' ), version_compare( get_bloginfo( 'version' ), '6.0', '>=' ) ],
                    [ __( 'Active Engine', 'mpire-image-optimizer' ), ucfirst( $engine_info['current_engine'] ), true ],
                    [ __( 'GD Library', 'mpire-image-optimizer' ), $engine_info['gd_available'] ? __( 'Available', 'mpire-image-optimizer' ) : __( 'Not Available', 'mpire-image-optimizer' ), $engine_info['gd_available'] ],
                    [ __( 'Imagick', 'mpire-image-optimizer' ), $engine_info['imagick_available'] ? __( 'Available', 'mpire-image-optimizer' ) : __( 'Not Available', 'mpire-image-optimizer' ), $engine_info['imagick_available'] ],
                    [ __( 'Memory Limit', 'mpire-image-optimizer' ), $engine_info['memory_limit'], (int) ini_get( 'memory_limit' ) >= 128 ],
                    [ __( 'Max Execution Time', 'mpire-image-optimizer' ), ini_get( 'max_execution_time' ) . 's', (int) ini_get( 'max_execution_time' ) >= 30 || (int) ini_get( 'max_execution_time' ) === 0 ],
                    [ __( 'Max Upload Size', 'mpire-image-optimizer' ), mpio_format_bytes( $engine_info['max_upload'] ), true ],
                    [ __( 'Uploads Writable', 'mpire-image-optimizer' ), wp_is_writable( $upload_dir['basedir'] ) ? __( 'Yes', 'mpire-image-optimizer' ) : __( 'No', 'mpire-image-optimizer' ), wp_is_writable( $upload_dir['basedir'] ) ],
                    [ __( 'Backup Dir Writable', 'mpire-image-optimizer' ), wp_is_writable( $backup_dir ) ? __( 'Yes', 'mpire-image-optimizer' ) : __( 'No / Missing', 'mpire-image-optimizer' ), wp_is_writable( $backup_dir ) ],
                ];

                foreach ( $checks as $check ) :
                ?>
                <tr>
                    <td style="width:200px"><?php echo esc_html( $check[0] ); ?></td>
                    <td><strong><?php echo esc_html( $check[1] ); ?></strong></td>
                    <td style="width:40px;text-align:center">
                        <?php echo $check[2]
                            ? '<span style="color:#10b981;font-size:18px">&#10003;</span>'
                            : '<span style="color:#ef4444;font-size:18px">&#10007;</span>'; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Format Support -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'Format Support', 'mpire-image-optimizer' ); ?></h3>
        <?php
        $formats = 'imagick' === $engine_info['current_engine'] ? $engine_info['imagick_formats'] : $engine_info['gd_formats'];
        if ( ! empty( $formats ) ) :
        ?>
        <div class="mpio-format-badges" style="gap:8px">
            <?php foreach ( $formats as $format => $supported ) : ?>
                <span class="mpio-badge <?php echo $supported ? 'mpio-badge-success' : 'mpio-badge-error'; ?>" style="font-size:13px;padding:4px 12px">
                    <?php echo esc_html( strtoupper( $format ) ); ?>
                    <?php echo $supported ? '&#10003;' : '&#10007;'; ?>
                </span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Disk Usage -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'Disk Usage', 'mpire-image-optimizer' ); ?></h3>
        <table class="widefat striped" style="max-width:400px">
            <tbody>
                <tr>
                    <td><?php esc_html_e( 'Backups', 'mpire-image-optimizer' ); ?></td>
                    <td><strong><?php echo esc_html( $backup_stats['total_backups'] ); ?></strong> <?php esc_html_e( 'files', 'mpire-image-optimizer' ); ?></td>
                    <td><strong><?php echo esc_html( mpio_format_bytes( $backup_stats['total_size'] ) ); ?></strong></td>
                </tr>
                <tr>
                    <td><?php esc_html_e( 'Log File', 'mpire-image-optimizer' ); ?></td>
                    <td colspan="2"><strong><?php echo esc_html( mpio_format_bytes( $log_size ) ); ?></strong></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Plugin Conflicts -->
    <?php if ( ! empty( $conflicts ) ) : ?>
    <div class="mpio-card">
        <h3 style="color:var(--mpio-warning)"><?php esc_html_e( 'Plugin Conflicts Detected', 'mpire-image-optimizer' ); ?></h3>
        <p><?php esc_html_e( 'The following image optimization plugins are also active:', 'mpire-image-optimizer' ); ?></p>
        <ul style="list-style:disc;margin-left:20px">
            <?php foreach ( $conflicts as $plugin ) : ?>
                <li><?php echo esc_html( $plugin ); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- Test Optimization -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'Test Optimization', 'mpire-image-optimizer' ); ?></h3>
        <p><?php esc_html_e( 'Run a test optimization on a random image from your media library to verify everything is working.', 'mpire-image-optimizer' ); ?></p>
        <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'upload.php?page=mpio-health-check&mpio_test=1' ), 'mpio_health_test' ) ); ?>" class="button button-primary mpio-btn-primary">
            <?php esc_html_e( 'Run Test', 'mpire-image-optimizer' ); ?>
        </a>
    </div>

    <!-- Recent Logs -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'Recent Log Entries', 'mpire-image-optimizer' ); ?></h3>
        <?php if ( empty( $recent_logs ) ) : ?>
            <p class="mpio-empty-state"><?php esc_html_e( 'No log entries yet.', 'mpire-image-optimizer' ); ?></p>
        <?php else : ?>
            <div class="mpio-log-entries" style="max-height:250px;overflow-y:auto;border:1px solid var(--mpio-border);border-radius:6px;padding:8px;font-size:11px;font-family:monospace;background:#fafafa">
                <?php foreach ( array_reverse( $recent_logs ) as $line ) : ?>
                    <div class="mpio-log-entry <?php
                        if ( strpos( $line, '[ERROR]' ) !== false ) echo 'mpio-log-error';
                        elseif ( strpos( $line, '[WARNING]' ) !== false ) echo 'mpio-log-error';
                    ?>"><?php echo esc_html( $line ); ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
