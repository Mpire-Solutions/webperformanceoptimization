<?php
/**
 * Custom Folders page template.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

$custom_folders = MPIO_Custom_Folders::get_instance();
$folders        = $custom_folders->get_folders();
$stats          = $custom_folders->get_custom_stats();
?>
<div class="wrap mpio-wrap">
    <h1 class="mpio-page-title">
        <span class="mpio-logo">&#9889;</span>
        <?php esc_html_e( 'Custom Folders', 'mpire-image-optimizer' ); ?>
    </h1>

    <div class="mpio-card">
        <h3><?php esc_html_e( 'Add a Folder', 'mpire-image-optimizer' ); ?></h3>
        <p><?php esc_html_e( 'Optimize images in custom directories outside the WordPress uploads folder.', 'mpire-image-optimizer' ); ?></p>

        <div class="mpio-add-folder-form">
            <label for="mpio-folder-path"><?php esc_html_e( 'Folder Path', 'mpire-image-optimizer' ); ?></label>
            <div class="mpio-input-group">
                <code class="mpio-abspath"><?php echo esc_html( ABSPATH ); ?></code>
                <input type="text" id="mpio-folder-path" placeholder="wp-content/themes/my-theme/images" class="regular-text">
                <button type="button" id="mpio-add-folder-btn" class="button button-primary"><?php esc_html_e( 'Add Folder', 'mpire-image-optimizer' ); ?></button>
            </div>
            <p class="mpio-field-desc"><?php esc_html_e( 'Enter a path relative to your WordPress installation root.', 'mpire-image-optimizer' ); ?></p>
            <div id="mpio-folder-message" class="mpio-message" style="display:none"></div>
        </div>
    </div>

    <!-- Custom Folder Stats -->
    <?php if ( ! empty( $folders ) ) : ?>
    <div class="mpio-stats-grid mpio-stats-grid-small">
        <div class="mpio-stat-card">
            <div class="mpio-stat-number"><?php echo esc_html( $stats['total_files'] ); ?></div>
            <div class="mpio-stat-label"><?php esc_html_e( 'Total Files', 'mpire-image-optimizer' ); ?></div>
        </div>
        <div class="mpio-stat-card mpio-stat-success">
            <div class="mpio-stat-number"><?php echo esc_html( $stats['optimized'] ); ?></div>
            <div class="mpio-stat-label"><?php esc_html_e( 'Optimized', 'mpire-image-optimizer' ); ?></div>
        </div>
        <div class="mpio-stat-card mpio-stat-warning">
            <div class="mpio-stat-number"><?php echo esc_html( $stats['unoptimized'] ); ?></div>
            <div class="mpio-stat-label"><?php esc_html_e( 'Unoptimized', 'mpire-image-optimizer' ); ?></div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Folders List -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'Configured Folders', 'mpire-image-optimizer' ); ?></h3>

        <?php if ( empty( $folders ) ) : ?>
            <p class="mpio-empty-state"><?php esc_html_e( 'No custom folders configured yet.', 'mpire-image-optimizer' ); ?></p>
        <?php else : ?>
            <table class="wp-list-table widefat fixed striped" id="mpio-folders-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Folder Path', 'mpire-image-optimizer' ); ?></th>
                        <th class="mpio-col-num"><?php esc_html_e( 'Files', 'mpire-image-optimizer' ); ?></th>
                        <th class="mpio-col-num"><?php esc_html_e( 'Optimized', 'mpire-image-optimizer' ); ?></th>
                        <th class="mpio-col-actions"><?php esc_html_e( 'Actions', 'mpire-image-optimizer' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $folders as $folder ) :
                        $folder_files = $custom_folders->get_folder_files( $folder );
                        $folder_optimized = array_filter( $folder_files, function( $f ) { return 'optimized' === $f->status; } );
                    ?>
                        <tr data-folder="<?php echo esc_attr( $folder ); ?>">
                            <td><code><?php echo esc_html( $folder ); ?></code></td>
                            <td class="mpio-col-num"><?php echo esc_html( count( $folder_files ) ); ?></td>
                            <td class="mpio-col-num"><?php echo esc_html( count( $folder_optimized ) ); ?></td>
                            <td class="mpio-col-actions">
                                <button type="button" class="button button-small mpio-sync-folder" data-folder="<?php echo esc_attr( $folder ); ?>"><?php esc_html_e( 'Sync', 'mpire-image-optimizer' ); ?></button>
                                <button type="button" class="button button-small mpio-optimize-folder" data-folder="<?php echo esc_attr( $folder ); ?>"><?php esc_html_e( 'Optimize', 'mpire-image-optimizer' ); ?></button>
                                <button type="button" class="button button-small mpio-remove-folder" data-folder="<?php echo esc_attr( $folder ); ?>"><?php esc_html_e( 'Remove', 'mpire-image-optimizer' ); ?></button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
