<?php
/**
 * Batch Converter page — embeds the client-side React converter app.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap mpio-wrap">
    <h1 class="mpio-page-title">
        <span class="mpio-logo">&#9889;</span>
        <?php esc_html_e( 'Batch Converter', 'mpire-image-optimizer' ); ?>
        <span class="mpio-subtitle"><?php esc_html_e( 'Client-side image conversion (no server upload required)', 'mpire-image-optimizer' ); ?></span>
    </h1>

    <div class="mpio-batch-converter-info mpio-card">
        <p>
            <?php esc_html_e( 'This tool converts images directly in your browser using advanced WASM codecs (MozJPEG, libwebp, libaom, OxiPNG). No images are uploaded to the server — all processing happens locally.', 'mpire-image-optimizer' ); ?>
        </p>
        <ul>
            <li><?php esc_html_e( 'Drag & drop files or folders', 'mpire-image-optimizer' ); ?></li>
            <li><?php esc_html_e( 'Convert between WebP, AVIF, PNG, JPG', 'mpire-image-optimizer' ); ?></li>
            <li><?php esc_html_e( 'Resize, watermark, strip EXIF', 'mpire-image-optimizer' ); ?></li>
            <li><?php esc_html_e( 'Before/after comparison', 'mpire-image-optimizer' ); ?></li>
            <li><?php esc_html_e( 'Download as ZIP', 'mpire-image-optimizer' ); ?></li>
        </ul>
    </div>

    <!-- React app mount point -->
    <div id="mpio-batch-converter-root"></div>
</div>

<style>
    /* Override WP admin styles for the batch converter */
    #mpio-batch-converter-root {
        margin: 0 -1px;
    }
    /* Let the React app handle its own styling */
    #mpio-batch-converter-root * {
        box-sizing: border-box;
    }
</style>
