<?php
/**
 * Getting Started page template.
 *
 * Shown after plugin activation to guide users through initial setup.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

$engine_info = MPIO_Admin::get_engine_info();
$stats       = MPIO_Bulk_Optimizer::get_instance()->get_stats();
$settings    = get_option( 'mpio_settings', mpio_get_default_settings() );
$has_webp    = false;
$has_avif    = false;

$formats = 'imagick' === $engine_info['current_engine'] ? $engine_info['imagick_formats'] : $engine_info['gd_formats'];
if ( ! empty( $formats ) ) {
    $has_webp = ! empty( $formats['webp'] );
    $has_avif = ! empty( $formats['avif'] );
}
?>
<div class="wrap mpio-wrap">
    <h1 class="mpio-page-title">
        <span class="mpio-logo">&#9889;</span>
        <?php esc_html_e( 'Getting Started', 'mpire-image-optimizer' ); ?>
    </h1>

    <!-- Welcome -->
    <div class="mpio-card mpio-getting-started-hero">
        <h2><?php esc_html_e( 'Welcome to Mpire Image Optimizer', 'mpire-image-optimizer' ); ?></h2>
        <p><?php esc_html_e( 'Optimize every image on your site with zero external dependencies. WebP/AVIF conversion, auto-optimization on upload, bulk processing, and smart serving -- all running locally on your server.', 'mpire-image-optimizer' ); ?></p>
    </div>

    <!-- Quick Setup Steps -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'Quick Setup (3 steps)', 'mpire-image-optimizer' ); ?></h3>

        <div class="mpio-setup-steps">
            <!-- Step 1 -->
            <div class="mpio-setup-step">
                <div class="mpio-step-number">1</div>
                <div class="mpio-step-content">
                    <h4><?php esc_html_e( 'Verify Your Server', 'mpire-image-optimizer' ); ?></h4>
                    <p><?php esc_html_e( 'The plugin uses your server\'s image libraries. Here\'s what we detected:', 'mpire-image-optimizer' ); ?></p>
                    <table class="mpio-info-table mpio-setup-table">
                        <tr>
                            <td><?php esc_html_e( 'Active Engine', 'mpire-image-optimizer' ); ?></td>
                            <td><strong><?php echo esc_html( ucfirst( $engine_info['current_engine'] ) ); ?></strong></td>
                        </tr>
                        <tr>
                            <td><?php esc_html_e( 'WebP Support', 'mpire-image-optimizer' ); ?></td>
                            <td>
                                <?php if ( $has_webp ) : ?>
                                    <span class="mpio-badge mpio-badge-success"><?php esc_html_e( 'Supported', 'mpire-image-optimizer' ); ?></span>
                                <?php else : ?>
                                    <span class="mpio-badge mpio-badge-error"><?php esc_html_e( 'Not Available', 'mpire-image-optimizer' ); ?></span>
                                    <span class="mpio-step-hint"><?php esc_html_e( 'Try switching to Imagick in Settings > Advanced.', 'mpire-image-optimizer' ); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><?php esc_html_e( 'AVIF Support', 'mpire-image-optimizer' ); ?></td>
                            <td>
                                <?php if ( $has_avif ) : ?>
                                    <span class="mpio-badge mpio-badge-success"><?php esc_html_e( 'Supported', 'mpire-image-optimizer' ); ?></span>
                                <?php else : ?>
                                    <span class="mpio-badge mpio-badge-muted"><?php esc_html_e( 'Not Available', 'mpire-image-optimizer' ); ?></span>
                                    <span class="mpio-step-hint"><?php esc_html_e( 'Optional. Requires PHP 8.1+ with Imagick.', 'mpire-image-optimizer' ); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><?php esc_html_e( 'PHP Version', 'mpire-image-optimizer' ); ?></td>
                            <td><?php echo esc_html( $engine_info['php_version'] ); ?></td>
                        </tr>
                    </table>
                    <?php if ( $has_webp ) : ?>
                        <p class="mpio-step-status mpio-step-ok"><?php esc_html_e( 'Your server is ready for image optimization.', 'mpire-image-optimizer' ); ?></p>
                    <?php else : ?>
                        <p class="mpio-step-status mpio-step-warn"><?php esc_html_e( 'WebP is not available. Images will still be compressed, but WebP conversion won\'t work.', 'mpire-image-optimizer' ); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Step 2 -->
            <div class="mpio-setup-step">
                <div class="mpio-step-number">2</div>
                <div class="mpio-step-content">
                    <h4><?php esc_html_e( 'Review Settings', 'mpire-image-optimizer' ); ?></h4>
                    <p><?php esc_html_e( 'The defaults work well for most sites. Key settings:', 'mpire-image-optimizer' ); ?></p>
                    <table class="mpio-info-table mpio-setup-table">
                        <tr>
                            <td><?php esc_html_e( 'Auto-optimize on upload', 'mpire-image-optimizer' ); ?></td>
                            <td>
                                <span class="mpio-badge <?php echo ( $settings['auto_optimize'] ?? true ) ? 'mpio-badge-success' : 'mpio-badge-muted'; ?>">
                                    <?php echo ( $settings['auto_optimize'] ?? true ) ? esc_html__( 'On', 'mpire-image-optimizer' ) : esc_html__( 'Off', 'mpire-image-optimizer' ); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php esc_html_e( 'Quality', 'mpire-image-optimizer' ); ?></td>
                            <td><?php echo esc_html( $settings['quality'] ?? 80 ); ?>%</td>
                        </tr>
                        <tr>
                            <td><?php esc_html_e( 'Create WebP versions', 'mpire-image-optimizer' ); ?></td>
                            <td>
                                <span class="mpio-badge <?php echo ( $settings['convert_to_webp'] ?? true ) ? 'mpio-badge-success' : 'mpio-badge-muted'; ?>">
                                    <?php echo ( $settings['convert_to_webp'] ?? true ) ? esc_html__( 'On', 'mpire-image-optimizer' ) : esc_html__( 'Off', 'mpire-image-optimizer' ); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php esc_html_e( 'Backup originals', 'mpire-image-optimizer' ); ?></td>
                            <td>
                                <span class="mpio-badge <?php echo ( $settings['keep_backup'] ?? true ) ? 'mpio-badge-success' : 'mpio-badge-muted'; ?>">
                                    <?php echo ( $settings['keep_backup'] ?? true ) ? esc_html__( 'On', 'mpire-image-optimizer' ) : esc_html__( 'Off', 'mpire-image-optimizer' ); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><?php esc_html_e( 'Serving mode', 'mpire-image-optimizer' ); ?></td>
                            <td><?php echo esc_html( ucfirst( $settings['display_mode'] ?? 'picture' ) ); ?> Tags</td>
                        </tr>
                    </table>
                    <p>
                        <a href="<?php echo esc_url( admin_url( 'options-general.php?page=mpio-settings' ) ); ?>" class="button"><?php esc_html_e( 'Review All Settings', 'mpire-image-optimizer' ); ?></a>
                    </p>
                </div>
            </div>

            <!-- Step 3 -->
            <div class="mpio-setup-step">
                <div class="mpio-step-number">3</div>
                <div class="mpio-step-content">
                    <h4><?php esc_html_e( 'Optimize Your Images', 'mpire-image-optimizer' ); ?></h4>
                    <?php if ( $stats['unoptimized'] > 0 ) : ?>
                        <p>
                            <?php
                            printf(
                                /* translators: 1: unoptimized count, 2: total count */
                                esc_html__( 'You have %1$d of %2$d images that need optimization. Run a bulk optimization to process them all at once.', 'mpire-image-optimizer' ),
                                $stats['unoptimized'],
                                $stats['total_images']
                            );
                            ?>
                        </p>
                        <p>
                            <a href="<?php echo esc_url( admin_url( 'upload.php?page=mpio-bulk-optimizer' ) ); ?>" class="button button-primary mpio-btn-primary"><?php esc_html_e( 'Start Bulk Optimization', 'mpire-image-optimizer' ); ?></a>
                        </p>
                    <?php else : ?>
                        <p class="mpio-step-status mpio-step-ok"><?php esc_html_e( 'All images are already optimized. New uploads will be handled automatically.', 'mpire-image-optimizer' ); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- How It Works -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'How It Works', 'mpire-image-optimizer' ); ?></h3>
        <div class="mpio-how-grid">
            <div class="mpio-how-item">
                <div class="mpio-how-icon">&#128247;</div>
                <h4><?php esc_html_e( 'Upload', 'mpire-image-optimizer' ); ?></h4>
                <p><?php esc_html_e( 'Upload images normally through the Media Library, post editor, or any plugin. The optimizer runs automatically.', 'mpire-image-optimizer' ); ?></p>
            </div>
            <div class="mpio-how-item">
                <div class="mpio-how-icon">&#9881;</div>
                <h4><?php esc_html_e( 'Optimize', 'mpire-image-optimizer' ); ?></h4>
                <p><?php esc_html_e( 'Images are compressed, resized if needed, and converted to WebP/AVIF. Originals are backed up for safe restoration.', 'mpire-image-optimizer' ); ?></p>
            </div>
            <div class="mpio-how-item">
                <div class="mpio-how-icon">&#9889;</div>
                <h4><?php esc_html_e( 'Serve', 'mpire-image-optimizer' ); ?></h4>
                <p><?php esc_html_e( 'Visitors automatically receive the smallest format their browser supports via <picture> tags. No manual work needed.', 'mpire-image-optimizer' ); ?></p>
            </div>
        </div>
    </div>

    <!-- Feature Overview -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'Features at a Glance', 'mpire-image-optimizer' ); ?></h3>
        <div class="mpio-features-grid">
            <div class="mpio-feature-item">
                <strong><?php esc_html_e( 'Bulk Optimize', 'mpire-image-optimizer' ); ?></strong>
                <span><?php esc_html_e( 'Process all existing media library images in one click.', 'mpire-image-optimizer' ); ?></span>
                <a href="<?php echo esc_url( admin_url( 'upload.php?page=mpio-bulk-optimizer' ) ); ?>"><?php esc_html_e( 'Go to Bulk Optimizer', 'mpire-image-optimizer' ); ?></a>
            </div>
            <div class="mpio-feature-item">
                <strong><?php esc_html_e( 'WebP/AVIF Conversion', 'mpire-image-optimizer' ); ?></strong>
                <span><?php esc_html_e( 'Create next-gen format versions alongside originals for 30-90% smaller files.', 'mpire-image-optimizer' ); ?></span>
                <a href="<?php echo esc_url( admin_url( 'options-general.php?page=mpio-settings' ) ); ?>"><?php esc_html_e( 'Configure in Settings', 'mpire-image-optimizer' ); ?></a>
            </div>
            <div class="mpio-feature-item">
                <strong><?php esc_html_e( 'Smart Serving', 'mpire-image-optimizer' ); ?></strong>
                <span><?php esc_html_e( 'Automatically rewrites HTML to serve WebP/AVIF to supported browsers using <picture> tags.', 'mpire-image-optimizer' ); ?></span>
                <a href="<?php echo esc_url( admin_url( 'options-general.php?page=mpio-settings' ) ); ?>"><?php esc_html_e( 'Configure Display Mode', 'mpire-image-optimizer' ); ?></a>
            </div>
            <div class="mpio-feature-item">
                <strong><?php esc_html_e( 'Backup & Restore', 'mpire-image-optimizer' ); ?></strong>
                <span><?php esc_html_e( 'Every original is backed up. Restore any image to its original state with one click.', 'mpire-image-optimizer' ); ?></span>
            </div>
            <div class="mpio-feature-item">
                <strong><?php esc_html_e( 'Media Library Integration', 'mpire-image-optimizer' ); ?></strong>
                <span><?php esc_html_e( 'Status column, filter dropdown, and before/after comparison right in your media library.', 'mpire-image-optimizer' ); ?></span>
                <a href="<?php echo esc_url( admin_url( 'upload.php' ) ); ?>"><?php esc_html_e( 'View Media Library', 'mpire-image-optimizer' ); ?></a>
            </div>
            <div class="mpio-feature-item">
                <strong><?php esc_html_e( 'Custom Folders', 'mpire-image-optimizer' ); ?></strong>
                <span><?php esc_html_e( 'Optimize images outside the uploads directory -- theme images, custom directories, etc.', 'mpire-image-optimizer' ); ?></span>
                <a href="<?php echo esc_url( admin_url( 'upload.php?page=mpio-custom-folders' ) ); ?>"><?php esc_html_e( 'Manage Custom Folders', 'mpire-image-optimizer' ); ?></a>
            </div>
        </div>
    </div>

    <!-- Need Help -->
    <div class="mpio-card">
        <h3><?php esc_html_e( 'Need Help?', 'mpire-image-optimizer' ); ?></h3>
        <p><?php esc_html_e( 'Check the FAQ below or visit the plugin documentation for detailed guides.', 'mpire-image-optimizer' ); ?></p>

        <div class="mpio-faq-list">
            <details class="mpio-faq-item">
                <summary><?php esc_html_e( 'Do I need an API key or external service?', 'mpire-image-optimizer' ); ?></summary>
                <p><?php esc_html_e( 'No. All processing happens on your server using PHP\'s GD or Imagick extensions. There are no API keys, subscriptions, or usage limits.', 'mpire-image-optimizer' ); ?></p>
            </details>

            <details class="mpio-faq-item">
                <summary><?php esc_html_e( 'Will this slow down my site?', 'mpire-image-optimizer' ); ?></summary>
                <p><?php esc_html_e( 'No. Optimization happens during upload or when you run bulk optimization. It does not affect page load speed. In fact, optimized images will make your site faster.', 'mpire-image-optimizer' ); ?></p>
            </details>

            <details class="mpio-faq-item">
                <summary><?php esc_html_e( 'What happens to my original images?', 'mpire-image-optimizer' ); ?></summary>
                <p><?php esc_html_e( 'If "Keep backup of originals" is enabled (it is by default), a copy of every original image is stored. You can restore any image at any time from the Media Library or with the "Restore All Originals" button.', 'mpire-image-optimizer' ); ?></p>
            </details>

            <details class="mpio-faq-item">
                <summary><?php esc_html_e( 'How does WebP/AVIF serving work?', 'mpire-image-optimizer' ); ?></summary>
                <p><?php esc_html_e( 'The plugin creates .webp (and optionally .avif) copies of every image. Then it rewrites the HTML on your pages, wrapping <img> tags in <picture> elements with <source> tags for each format. Browsers automatically pick the best format they support. Visitors with older browsers still see the original JPEG/PNG as a fallback.', 'mpire-image-optimizer' ); ?></p>
            </details>

            <details class="mpio-faq-item">
                <summary><?php esc_html_e( 'Total Savings shows 0% -- is it working?', 'mpire-image-optimizer' ); ?></summary>
                <p><?php esc_html_e( 'The "Total Savings" stat measures how much the main JPEG/PNG files were compressed. If your images are already well-optimized, re-encoding them won\'t make them smaller. However, the WebP companion files (which are 30-90% smaller) are still created and served to visitors. The real savings happen at the browser level when WebP is delivered instead of the original.', 'mpire-image-optimizer' ); ?></p>
            </details>

            <details class="mpio-faq-item">
                <summary><?php esc_html_e( 'Does it work with page caching (WP Engine, Cloudflare, etc.)?', 'mpire-image-optimizer' ); ?></summary>
                <p><?php esc_html_e( 'Yes. After running bulk optimization, purge your page cache so the new <picture> tags are served. The plugin adds the necessary Vary headers so CDNs cache different format versions correctly.', 'mpire-image-optimizer' ); ?></p>
            </details>

            <details class="mpio-faq-item">
                <summary><?php esc_html_e( 'Can I use this with WooCommerce?', 'mpire-image-optimizer' ); ?></summary>
                <p><?php esc_html_e( 'Yes. Product images are stored in the Media Library and are optimized like any other image. WebP versions are served automatically on product pages.', 'mpire-image-optimizer' ); ?></p>
            </details>
        </div>
    </div>
</div>
