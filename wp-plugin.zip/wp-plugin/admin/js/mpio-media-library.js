/**
 * Mpire Image Optimizer — Media Library Integration
 */
(function($) {
    'use strict';

    var MPIO = {
        init: function() {
            $(document).on('click', '.mpio-optimize-btn', this.optimizeSingle);
            $(document).on('click', '.mpio-restore-btn', this.restoreSingle);
            $(document).on('click', '.mpio-reoptimize', this.reoptimizeSingle);
            $(document).on('click', '.mpio-compare', this.showCompare);
            $(document).on('click', '.mpio-exclude-btn', this.excludeSingle);
            $(document).on('click', '.mpio-include-btn', this.includeSingle);
            this.injectCompareModal();
        },

        injectCompareModal: function() {
            if ($('#mpio-compare-modal').length) return;
            $('body').append(
                '<div id="mpio-compare-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:100000;align-items:center;justify-content:center;padding:20px">' +
                '<div style="background:#fff;border-radius:10px;padding:20px;max-width:800px;width:100%;max-height:90vh;overflow:auto;position:relative">' +
                '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">' +
                '<strong>Before / After Comparison</strong>' +
                '<button id="mpio-compare-close" style="background:none;border:none;font-size:22px;cursor:pointer;color:#666">&times;</button></div>' +
                '<div id="mpio-compare-container" style="position:relative;width:100%;aspect-ratio:16/10;border-radius:6px;overflow:hidden;cursor:col-resize;background:#000">' +
                '<img id="mpio-compare-original" src="" alt="Original" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain">' +
                '<div id="mpio-compare-clip" style="position:absolute;inset:0;width:50%;overflow:hidden">' +
                '<img id="mpio-compare-optimized" src="" alt="Optimized" style="position:absolute;top:0;left:0;width:200%;height:100%;object-fit:contain;max-width:none">' +
                '</div>' +
                '<div id="mpio-compare-line" style="position:absolute;top:0;bottom:0;left:50%;width:2px;background:#4f46e5;transform:translateX(-1px);pointer-events:none">' +
                '<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:26px;height:26px;border-radius:50%;background:#4f46e5;display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;font-weight:700">&harr;</div></div>' +
                '<div style="position:absolute;top:6px;left:6px;background:rgba(0,0,0,.7);color:#fff;padding:2px 8px;border-radius:4px;font-size:10px">Optimized</div>' +
                '<div style="position:absolute;top:6px;right:6px;background:rgba(0,0,0,.7);color:#fff;padding:2px 8px;border-radius:4px;font-size:10px">Original</div>' +
                '</div></div></div>'
            );

            var $modal = $('#mpio-compare-modal');
            var $container = $('#mpio-compare-container');

            $modal.on('click', function(e) {
                if (e.target === this) $modal.hide();
            });
            $('#mpio-compare-close').on('click', function() { $modal.hide(); });
            $(document).on('keydown', function(e) {
                if (e.key === 'Escape') $modal.hide();
            });

            $container.on('mousemove touchmove', function(e) {
                var rect = this.getBoundingClientRect();
                var x = ((e.clientX || (e.originalEvent.touches && e.originalEvent.touches[0].clientX) || 0) - rect.left);
                var pct = Math.max(1, Math.min(99, (x / rect.width) * 100));
                $('#mpio-compare-clip').css('width', pct + '%');
                $('#mpio-compare-optimized').css('width', (100 / (pct / 100)) + '%');
                $('#mpio-compare-line').css('left', pct + '%');
            });
        },

        optimizeSingle: function(e) {
            e.preventDefault();
            var $btn = $(this);
            var attachmentId = $btn.data('id');
            var $wrap = $btn.closest('.mpio-ml-status');

            $btn.prop('disabled', true).text(mpioMedia.i18n.optimizing);
            $wrap.find('.mpio-ml-actions').html('<span class="mpio-ml-spinner"></span>');

            $.ajax({
                url: mpioMedia.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_optimize_single',
                    nonce: mpioMedia.nonce,
                    attachment_id: attachmentId
                },
                success: function(response) {
                    if (response.success) {
                        var d = response.data;
                        var savings = d.savings_percent ? d.savings_percent + '%' : '0%';
                        var html = '<span class="mpio-ml-optimized">';
                        html += '<strong class="mpio-ml-savings">-' + savings + '</strong> saved';
                        html += '</span>';
                        html += '<div class="mpio-ml-details">' + d.original_size_formatted + ' → ' + d.optimized_size_formatted + '</div>';
                        html += '<div class="mpio-ml-actions">';
                        html += '<a href="#" class="mpio-restore-btn" data-id="' + attachmentId + '">Restore</a>';
                        html += '</div>';
                        $wrap.html(html);
                    } else {
                        $wrap.html('<span class="mpio-ml-error">' + (response.data.message || mpioMedia.i18n.error) + '</span>' +
                            '<div class="mpio-ml-actions"><a href="#" class="mpio-optimize-btn" data-id="' + attachmentId + '">Retry</a></div>');
                    }
                },
                error: function() {
                    $wrap.html('<span class="mpio-ml-error">' + mpioMedia.i18n.error + '</span>' +
                        '<div class="mpio-ml-actions"><a href="#" class="mpio-optimize-btn" data-id="' + attachmentId + '">Retry</a></div>');
                }
            });
        },

        restoreSingle: function(e) {
            e.preventDefault();
            var $btn = $(this);
            var attachmentId = $btn.data('id');
            var $wrap = $btn.closest('.mpio-ml-status');

            if (!confirm('Restore original image? This will undo the optimization.')) {
                return;
            }

            $btn.text(mpioMedia.i18n.restoring);
            $wrap.find('.mpio-ml-actions').html('<span class="mpio-ml-spinner"></span>');

            $.ajax({
                url: mpioMedia.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_restore_single',
                    nonce: mpioMedia.nonce,
                    attachment_id: attachmentId
                },
                success: function(response) {
                    if (response.success) {
                        var html = '<button type="button" class="mpio-ml-btn mpio-optimize-btn" data-id="' + attachmentId + '">Optimize</button>';
                        $wrap.html(html);
                    } else {
                        $wrap.find('.mpio-ml-actions').html(
                            '<span class="mpio-ml-error">' + (response.data.message || mpioMedia.i18n.error) + '</span>'
                        );
                    }
                },
                error: function() {
                    $wrap.find('.mpio-ml-actions').html(
                        '<span class="mpio-ml-error">' + mpioMedia.i18n.error + '</span>'
                    );
                }
            });
        },

        showCompare: function(e) {
            e.preventDefault();
            var $link = $(this);
            var originalUrl = $link.data('original');
            var optimizedUrl = $link.data('optimized');

            $('#mpio-compare-original').attr('src', originalUrl);
            $('#mpio-compare-optimized').attr('src', optimizedUrl);
            $('#mpio-compare-clip').css('width', '50%');
            $('#mpio-compare-optimized').css('width', '200%');
            $('#mpio-compare-line').css('left', '50%');
            $('#mpio-compare-modal').css('display', 'flex');
        },

        excludeSingle: function(e) {
            e.preventDefault();
            var $btn = $(this);
            var attachmentId = $btn.data('id');
            var $wrap = $btn.closest('td');

            $.ajax({
                url: mpioMedia.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_exclude_single',
                    nonce: mpioMedia.nonce,
                    attachment_id: attachmentId
                },
                success: function(response) {
                    if (response.success) {
                        $wrap.html(
                            '<span class="mpio-badge mpio-badge-skipped" style="color:#826eb4;">Skipped (excluded)</span><br>' +
                            '<a href="#" class="mpio-include-btn" data-id="' + attachmentId + '">Remove exclusion</a>'
                        );
                    }
                }
            });
        },

        includeSingle: function(e) {
            e.preventDefault();
            var $btn = $(this);
            var attachmentId = $btn.data('id');
            var $wrap = $btn.closest('td');

            $.ajax({
                url: mpioMedia.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_include_single',
                    nonce: mpioMedia.nonce,
                    attachment_id: attachmentId
                },
                success: function(response) {
                    if (response.success) {
                        $wrap.html(
                            '<button type="button" class="button button-small mpio-optimize-btn" data-id="' + attachmentId + '">Optimize</button> ' +
                            '<a href="#" class="mpio-exclude-btn" data-id="' + attachmentId + '">Skip</a>'
                        );
                    }
                }
            });
        },

        reoptimizeSingle: function(e) {
            e.preventDefault();
            var $btn = $(this);
            var attachmentId = $btn.data('id');
            var $wrap = $btn.closest('.mpio-ml-status');
            if (!$wrap.length) $wrap = $btn.closest('td');

            if (!confirm('Re-optimize this image with current settings?')) return;

            $btn.text('Re-optimizing...');

            $.ajax({
                url: mpioMedia.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_reoptimize_single',
                    nonce: mpioMedia.nonce,
                    attachment_id: attachmentId
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.data.message || mpioMedia.i18n.error);
                        $btn.text('Re-optimize');
                    }
                },
                error: function() {
                    alert(mpioMedia.i18n.error);
                    $btn.text('Re-optimize');
                }
            });
        }
    };

    $(document).ready(function() {
        MPIO.init();

        // Grid view badges: inject optimization status into media grid tiles.
        if (typeof wp !== 'undefined' && wp.media && wp.media.view && wp.media.view.Attachment) {
            var OriginalRender = wp.media.view.Attachment.Library.prototype.render;
            wp.media.view.Attachment.Library.prototype.render = function() {
                OriginalRender.apply(this, arguments);

                var model = this.model;
                if (!model || model.get('type') !== 'image') return this;

                var $el = this.$el;
                // Remove existing badge if re-rendering.
                $el.find('.mpio-grid-badge').remove();

                var mpioStatus = model.get('mpio_status');
                var mpioSavings = model.get('mpio_savings');

                var mpioExcluded = model.get('mpio_excluded');

                if (mpioExcluded) {
                    $el.find('.thumbnail').append(
                        '<span class="mpio-grid-badge mpio-grid-skipped" title="Excluded from optimization" style="background:#826eb4;">Skip</span>'
                    );
                } else if (mpioStatus === 'optimized') {
                    var pct = mpioSavings ? parseFloat(mpioSavings).toFixed(0) : '0';
                    $el.find('.thumbnail').append(
                        '<span class="mpio-grid-badge mpio-grid-optimized" title="Optimized: ' + pct + '% saved">-' + pct + '%</span>'
                    );
                } else if (mpioStatus === 'error') {
                    $el.find('.thumbnail').append(
                        '<span class="mpio-grid-badge mpio-grid-error" title="Optimization error">!</span>'
                    );
                }

                return this;
            };
        }
    });

})(jQuery);
