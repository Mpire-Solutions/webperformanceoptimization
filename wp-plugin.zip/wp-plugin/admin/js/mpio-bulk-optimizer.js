/**
 * Mpire Image Optimizer — Bulk Optimizer JS
 *
 * Drives bulk optimization via sequential AJAX batch calls
 * and polls status separately for real-time progress updates.
 */
(function($) {
    'use strict';

    var BulkOptimizer = {
        startedAt: null,
        timerInterval: null,
        statusPolling: null,
        isProcessing: false,
        isStopped: false,
        retryCount: 0,
        maxRetries: 10,

        init: function() {
            $('#mpio-bulk-start').on('click', this.start.bind(this));
            $('#mpio-bulk-stop').on('click', this.stop.bind(this));
            $('#mpio-bulk-restore-all').on('click', this.restoreAll.bind(this));

            // If already running, resume processing.
            if ($('#mpio-bulk-stop').is(':visible')) {
                this.startedAt = Date.now();
                this.startTimer();
                this.startStatusPolling();
                this.processNextBatch();
            }
        },

        start: function() {
            var self = this;

            this.isStopped = false;
            $('#mpio-bulk-start').hide();
            $('#mpio-bulk-stop').show();
            $('#mpio-bulk-progress').show();
            $('#mpio-bulk-log').show();
            this.startedAt = Date.now();
            this.startTimer();

            this.addLog('Starting bulk optimization...', 'info');

            $.ajax({
                url: mpioBulk.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_bulk_start',
                    nonce: mpioBulk.nonce
                },
                success: function(response) {
                    if (response.success) {
                        self.addLog('Queued ' + response.data.total + ' images for optimization.', 'info');
                        self.startStatusPolling();
                        self.processNextBatch();
                    } else {
                        self.addLog('Failed to start: ' + (response.data.message || 'Unknown error'), 'error');
                        self.resetUI();
                    }
                },
                error: function() {
                    self.addLog('Failed to start bulk optimization.', 'error');
                    self.resetUI();
                }
            });
        },

        /**
         * Process the next batch via AJAX.
         * Calls itself recursively until done or stopped.
         */
        processNextBatch: function() {
            var self = this;

            if (this.isStopped || this.isProcessing) return;
            this.isProcessing = true;

            $.ajax({
                url: mpioBulk.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_bulk_process_batch',
                    nonce: mpioBulk.nonce
                },
                timeout: 120000, // 2 minute timeout per batch
                success: function(response) {
                    self.isProcessing = false;

                    if (self.isStopped) return;

                    if (!response.success) {
                        self.addLog('Batch processing error: ' + (response.data && response.data.message || 'Unknown'), 'error');
                        self.resetUI();
                        return;
                    }

                    self.retryCount = 0;
                    var d = response.data;
                    self.updateProgress(d);

                    if (d.is_running === false) {
                        // Done.
                        self.stopStatusPolling();
                        self.stopTimer();
                        self.addLog(mpioBulk.i18n.complete, 'success');
                        self.resetUI();
                        self.showCelebration(d);
                    } else {
                        // Process next batch immediately.
                        self.processNextBatch();
                    }
                },
                error: function(xhr, status) {
                    self.isProcessing = false;

                    if (self.isStopped || status === 'abort') return;

                    self.retryCount++;
                    if (self.retryCount >= self.maxRetries) {
                        self.addLog('Too many consecutive errors (' + self.retryCount + '). Stopping.', 'error');
                        self.stop();
                        return;
                    }

                    var delay = Math.min(5000 * self.retryCount, 30000);
                    self.addLog('Request error (' + status + '), retry ' + self.retryCount + '/' + self.maxRetries + ' in ' + Math.round(delay/1000) + 's...', 'error');
                    setTimeout(function() {
                        if (!self.isStopped) {
                            self.processNextBatch();
                        }
                    }, delay);
                }
            });
        },

        /**
         * Poll status endpoint every 2s for real-time progress
         * updates while batches are processing.
         */
        startStatusPolling: function() {
            var self = this;
            this.stopStatusPolling();
            this.statusPolling = setInterval(function() {
                self.pollStatus();
            }, 2000);
        },

        stopStatusPolling: function() {
            if (this.statusPolling) {
                clearInterval(this.statusPolling);
                this.statusPolling = null;
            }
        },

        pollStatus: function() {
            var self = this;

            $.ajax({
                url: mpioBulk.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_bulk_status',
                    nonce: mpioBulk.nonce
                },
                success: function(response) {
                    if (response.success) {
                        self.updateProgress(response.data);
                    }
                }
            });
        },

        stop: function() {
            var self = this;
            this.isStopped = true;
            this.stopStatusPolling();
            this.stopTimer();

            $.ajax({
                url: mpioBulk.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_bulk_stop',
                    nonce: mpioBulk.nonce
                },
                success: function() {
                    self.addLog(mpioBulk.i18n.stopped, 'info');
                },
                complete: function() {
                    self.resetUI();
                }
            });
        },

        startTimer: function() {
            var self = this;
            this.stopTimer();
            this.timerInterval = setInterval(function() {
                if (self.startedAt) {
                    var elapsed = Math.round((Date.now() - self.startedAt) / 1000);
                    var mins = Math.floor(elapsed / 60);
                    var secs = elapsed % 60;
                    $('#mpio-progress-elapsed').text(mins > 0 ? mins + 'm ' + secs + 's' : secs + 's');
                }
            }, 1000);
        },

        stopTimer: function() {
            if (this.timerInterval) {
                clearInterval(this.timerInterval);
                this.timerInterval = null;
            }
        },

        updateProgress: function(data) {
            var total = data.total || 0;
            var processed = data.processed || 0;
            var percent = total > 0 ? Math.round((processed / total) * 100) : 0;

            $('#mpio-progress-fill').css('width', percent + '%');
            $('#mpio-progress-percent').text(percent + '%');
            $('#mpio-progress-count').text(processed + ' / ' + total);
            $('#mpio-progress-success').text(data.success || 0);
            $('#mpio-progress-errors').text(data.errors || 0);

            // Update stat cards.
            if (data.stats) {
                $('#mpio-stat-optimized').text(data.stats.optimized || 0);
                $('#mpio-stat-unoptimized').text(data.stats.unoptimized || 0);
                $('#mpio-stat-errors').text(data.stats.errors || 0);

                var origSize = data.stats.total_original_size || 0;
                var optSize = data.stats.total_optimized_size || 0;
                var savingsPct = origSize > 0 ? Math.round(((origSize - optSize) / origSize) * 1000) / 10 : 0;
                $('#mpio-stat-savings').text(savingsPct + '%');
            }
        },

        resetUI: function() {
            $('#mpio-bulk-start').show();
            $('#mpio-bulk-stop').hide();
            this.isProcessing = false;
        },

        addLog: function(message, type) {
            var $log = $('#mpio-log-entries');
            var cls = type === 'error' ? 'mpio-log-error' : type === 'success' ? 'mpio-log-success' : '';
            var time = new Date().toLocaleTimeString();
            $log.prepend('<div class="mpio-log-entry ' + cls + '">[' + time + '] ' + message + '</div>');
        },

        restoreAll: function() {
            if (!confirm('Restore ALL optimized images to their originals? This cannot be undone.')) return;

            var $btn = $('#mpio-bulk-restore-all');
            $btn.prop('disabled', true).text('Restoring...');

            $.ajax({
                url: mpioBulk.ajaxUrl,
                method: 'POST',
                data: { action: 'mpio_bulk_restore_all', nonce: mpioBulk.nonce },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        location.reload();
                    } else {
                        alert(response.data.message || 'Restore failed.');
                        $btn.prop('disabled', false).text('Restore All Originals');
                    }
                },
                error: function() {
                    alert('Request failed.');
                    $btn.prop('disabled', false).text('Restore All Originals');
                }
            });
        },

        showCelebration: function(data) {
            var success = data.success || 0;
            var errors = data.errors || 0;
            var elapsed = this.startedAt ? Math.round((Date.now() - this.startedAt) / 1000) : 0;
            var mins = Math.floor(elapsed / 60);
            var secs = elapsed % 60;
            var timeStr = mins > 0 ? mins + 'm ' + secs + 's' : secs + 's';

            $.ajax({
                url: mpioBulk.ajaxUrl,
                method: 'POST',
                data: { action: 'mpio_get_stats', nonce: mpioBulk.nonce },
                success: function(resp) {
                    if (!resp.success) return;
                    var s = resp.data;
                    var totalSaved = (s.total_original_size || 0) - (s.total_optimized_size || 0);
                    var pct = s.total_original_size > 0 ? Math.round((totalSaved / s.total_original_size) * 100) : 0;

                    var formatBytes = function(b) {
                        if (!b) return '0 B';
                        var k = 1024, u = ['B','KB','MB','GB'];
                        var i = Math.floor(Math.log(b) / Math.log(k));
                        return parseFloat((b / Math.pow(k, i)).toFixed(1)) + ' ' + u[i];
                    };

                    var html = '<div id="mpio-celebration" style="position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:100000;display:flex;align-items:center;justify-content:center;padding:20px">'
                        + '<div style="background:#fff;border-radius:12px;padding:32px;max-width:420px;width:100%;text-align:center">'
                        + '<div style="font-size:48px;margin-bottom:12px">&#9889;</div>'
                        + '<h2 style="font-size:20px;font-weight:700;color:#111;margin:0 0 8px">Optimization Complete!</h2>'
                        + '<p style="color:#6b7280;font-size:14px;margin:0 0 20px">' + success + ' images optimized in ' + timeStr + (errors > 0 ? ' (' + errors + ' errors)' : '') + '</p>'
                        + '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:20px">'
                        + '<div style="background:#f0fdf4;border-radius:8px;padding:14px"><div style="font-size:24px;font-weight:700;color:#10b981">' + formatBytes(totalSaved) + '</div><div style="font-size:11px;color:#6b7280">Total Saved</div></div>'
                        + '<div style="background:#eff6ff;border-radius:8px;padding:14px"><div style="font-size:24px;font-weight:700;color:#3b82f6">' + pct + '%</div><div style="font-size:11px;color:#6b7280">Avg Compression</div></div>'
                        + '</div>'
                        + '<button onclick="document.getElementById(\'mpio-celebration\').remove()" style="background:#4f46e5;color:#fff;border:none;padding:10px 32px;border-radius:6px;font-size:14px;font-weight:500;cursor:pointer">Done</button>'
                        + '</div></div>';

                    $('body').append(html);

                    $('#mpio-celebration').on('click', function(e) {
                        if (e.target === this) $(this).remove();
                    });
                    $(document).one('keydown', function(e) {
                        if (e.key === 'Escape') $('#mpio-celebration').remove();
                    });
                }
            });
        }
    };

    $(document).ready(function() {
        BulkOptimizer.init();
    });

})(jQuery);
