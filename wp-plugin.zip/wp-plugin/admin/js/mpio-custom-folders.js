/**
 * Mpire Image Optimizer — Custom Folders JS
 */
(function($) {
    'use strict';

    var CustomFolders = {
        init: function() {
            $('#mpio-add-folder-btn').on('click', this.addFolder.bind(this));
            $(document).on('click', '.mpio-remove-folder', this.removeFolder.bind(this));
            $(document).on('click', '.mpio-sync-folder', this.syncFolder.bind(this));
            $(document).on('click', '.mpio-optimize-folder', this.optimizeFolder.bind(this));

            // Enter key on input.
            $('#mpio-folder-path').on('keypress', function(e) {
                if (e.which === 13) {
                    e.preventDefault();
                    $('#mpio-add-folder-btn').click();
                }
            });
        },

        showMessage: function(msg, type) {
            var $el = $('#mpio-folder-message');
            $el.removeClass('mpio-message-success mpio-message-error')
               .addClass('mpio-message-' + type)
               .text(msg)
               .show();

            setTimeout(function() { $el.fadeOut(); }, 5000);
        },

        addFolder: function() {
            var path = $.trim($('#mpio-folder-path').val());
            if (!path) {
                this.showMessage('Please enter a folder path.', 'error');
                return;
            }

            var self = this;
            var $btn = $('#mpio-add-folder-btn');
            $btn.prop('disabled', true).text('Adding...');

            $.ajax({
                url: mpioFolders.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_add_folder',
                    nonce: mpioFolders.nonce,
                    folder_path: path
                },
                success: function(response) {
                    if (response.success) {
                        self.showMessage('Folder added with ' + response.data.file_count + ' images found.', 'success');
                        setTimeout(function() { location.reload(); }, 1500);
                    } else {
                        self.showMessage(response.data.message || 'Failed to add folder.', 'error');
                    }
                },
                error: function() {
                    self.showMessage('Request failed.', 'error');
                },
                complete: function() {
                    $btn.prop('disabled', false).text('Add Folder');
                }
            });
        },

        removeFolder: function(e) {
            var folder = $(e.currentTarget).data('folder');
            if (!confirm('Remove "' + folder + '" from tracking? Files will not be deleted.')) return;

            $.ajax({
                url: mpioFolders.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_remove_folder',
                    nonce: mpioFolders.nonce,
                    folder_path: folder
                },
                success: function(response) {
                    if (response.success) {
                        $('tr[data-folder="' + folder + '"]').fadeOut(function() { $(this).remove(); });
                    }
                }
            });
        },

        syncFolder: function(e) {
            var $btn = $(e.currentTarget);
            var folder = $btn.data('folder');
            $btn.prop('disabled', true).text('Syncing...');

            $.ajax({
                url: mpioFolders.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_scan_folder',
                    nonce: mpioFolders.nonce,
                    folder_path: folder
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    }
                },
                complete: function() {
                    $btn.prop('disabled', false).text('Sync');
                }
            });
        },

        optimizeFolder: function(e) {
            var $btn = $(e.currentTarget);
            var folder = $btn.data('folder');
            $btn.prop('disabled', true).text('Optimizing...');

            $.ajax({
                url: mpioFolders.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'mpio_optimize_custom_folder',
                    nonce: mpioFolders.nonce,
                    folder_path: folder
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    }
                },
                complete: function() {
                    $btn.prop('disabled', false).text('Optimize');
                }
            });
        }
    };

    $(document).ready(function() {
        CustomFolders.init();
    });

})(jQuery);
