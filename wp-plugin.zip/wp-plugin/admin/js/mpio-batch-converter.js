const {
  useState,
  useRef,
  useCallback,
  useEffect,
  useMemo
} = React;

// ─── Constants ────────────────────────────────────────────────────────────────
const SUPPORTED_EXTENSIONS = [".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".tif", ".svg", ".webp", ".avif"];
const OUTPUT_FORMATS = [{
  value: "image/webp",
  label: "WebP",
  ext: ".webp"
}, {
  value: "image/avif",
  label: "AVIF",
  ext: ".avif"
}, {
  value: "image/png",
  label: "PNG",
  ext: ".png"
}, {
  value: "image/jpeg",
  label: "JPG",
  ext: ".jpg"
}];
const QUALITY_PRESETS = [{
  label: "Low",
  value: 60
}, {
  label: "Good",
  value: 75
}, {
  label: "Best",
  value: 80
}, {
  label: "High",
  value: 90
}, {
  label: "Max",
  value: 100
}];
const DEFAULT_SETTINGS = {
  quality: 80,
  resizeMode: "none",
  resizeWidth: 1920,
  resizeHeight: 1080,
  resizePercent: 50,
  maintainAspect: true,
  chunkSize: 25,
  outputFormat: "image/webp",
  slugify: false,
  stripExif: true,
  maxSizeEnabled: false,
  maxSizeKB: 200,
  theme: "dark",
  watermarkEnabled: false,
  watermarkText: "",
  watermarkPosition: "bottom-right",
  watermarkOpacity: 40,
  watermarkSize: 16
};
const SORT_OPTIONS = [{
  value: "added",
  label: "Added order"
}, {
  value: "name-asc",
  label: "Name A→Z"
}, {
  value: "name-desc",
  label: "Name Z→A"
}, {
  value: "size-asc",
  label: "Size ↑"
}, {
  value: "size-desc",
  label: "Size ↓"
}, {
  value: "status",
  label: "Status"
}];
const STATUS_ORDER = {
  error: 0,
  pending: 1,
  converting: 2,
  done: 3
};
const INFO_BATCH = 10; // parallel thumbnail workers
const ITEM_H = 55; // px per row (52 + 3 gap) — used for virtual list
const LIST_VH = 560; // visible height of the file list container
const BUF = 6; // rows to render above/below the viewport

// ─── Helpers ──────────────────────────────────────────────────────────────────
const fmt = b => {
  if (!b) return "0 B";
  const k = 1024,
    s = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(b) / Math.log(k));
  return parseFloat((b / k ** i).toFixed(1)) + " " + s[i];
};
const noExt = n => n.replace(/\.[^/.]+$/, "");
const slugifyName = n => noExt(n).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const getFormatExt = m => OUTPUT_FORMATS.find(f => f.value === m)?.ext || ".webp";

// ╔══════════════════════════════════════════════════════════════════════════════╗
// ║  FIX 1 — ZERO-DECODE FILE LOADING                                           ║
// ║  The original stored blob URLs (15 GB RAM for 500×30MB files).              ║
// ║  Previous fix drew a canvas thumbnail — still required full image decode,   ║
// ║  causing the "Reading image info…" spinner to hang on large files.          ║
// ║  New approach: skip ALL decoding at load time. Return a placeholder SVG     ║
// ║  instantly. Dimensions are shown as "–" until after conversion, when the    ║
// ║  canvas gives us w/h for free with zero extra cost.                         ║
// ╚══════════════════════════════════════════════════════════════════════════════╝
const PLACEHOLDER_SVG = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='34' height='34' viewBox='0 0 34 34'%3E%3Crect width='34' height='34' rx='4' fill='%2327272a'/%3E%3Cpath d='M9 24l6-7 4 5 3-3 6 8H6z' fill='%2352525b'/%3E%3Ccircle cx='22' cy='12' r='3' fill='%2352525b'/%3E%3C/svg%3E";
function getImageInfoBatch(files) {
  // Synchronous — no decoding, no blob URLs, returns instantly
  return Promise.resolve(files.map(() => ({
    w: 0,
    h: 0,
    thumb: PLACEHOLDER_SVG
  })));
}

// ─── Utilities ────────────────────────────────────────────────────────────────
async function loadScript(url, global) {
  if (window[global]) return window[global];
  return new Promise((res, rej) => {
    const s = document.createElement("script");
    s.src = url;
    s.onload = () => res(window[global]);
    s.onerror = rej;
    document.head.appendChild(s);
  });
}
const loadJSZip = () => loadScript("https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js", "JSZip");
const loadPiexif = () => loadScript("https://cdnjs.cloudflare.com/ajax/libs/piexifjs/1.0.6/piexif.min.js", "piexif");
function fileToDataUrl(f) {
  return new Promise(r => {
    const fr = new FileReader();
    fr.onload = () => r(fr.result);
    fr.onerror = () => r(null);
    fr.readAsDataURL(f);
  });
}
function blobToDataUrl(b) {
  return new Promise(r => {
    const fr = new FileReader();
    fr.onload = () => r(fr.result);
    fr.onerror = () => r(null);
    fr.readAsDataURL(b);
  });
}
function dataUrlToBlob(d) {
  const [h, data] = d.split(",");
  const m = h.match(/:(.*?);/)[1];
  const b = atob(data);
  const a = new Uint8Array(b.length);
  for (let i = 0; i < b.length; i++) a[i] = b.charCodeAt(i);
  return new Blob([a], {
    type: m
  });
}

// ─── WASM Codecs (MozJPEG / libwebp / libaom / OxiPNG via @jsquash) ──────────
// Lazy-loaded per format, cached after first load. Falls back to canvas.toBlob.
const _wasmCache = {};
const CODEC_NAMES = {
  'image/jpeg': 'MozJPEG',
  'image/webp': 'libwebp',
  'image/avif': 'libaom AVIF',
  'image/png': 'OxiPNG'
};
const CODEC_CDN = {
  'image/jpeg': 'https://esm.sh/@jsquash/jpeg',
  'image/webp': 'https://esm.sh/@jsquash/webp',
  'image/avif': 'https://esm.sh/@jsquash/avif',
  'image/png': 'https://esm.sh/@jsquash/png'
};
async function loadWasmCodec(format) {
  if (_wasmCache[format] !== undefined) return _wasmCache[format];
  _wasmCache[format] = null; // mark as attempted so we don't double-load
  try {
    const mod = await import(CODEC_CDN[format]);
    _wasmCache[format] = mod;
    return mod;
  } catch (e) {
    console.warn('[jsquash] codec unavailable:', format, e);
    return null;
  }
}
async function wasmEncodeBytes(mod, imageData, format, quality) {
  if (format === 'image/jpeg') return mod.encode(imageData, {
    quality
  });
  if (format === 'image/webp') return mod.encode(imageData, {
    quality
  });
  if (format === 'image/avif') return mod.encode(imageData, {
    quality,
    qualityAlpha: -1,
    decodingSpeed: 3
  });
  if (format === 'image/png') return mod.encode(imageData); // lossless — no quality param
  return null;
}
async function preserveExif(piexif, entry, resultBlob, fmt) {
  if (!piexif || !resultBlob) return resultBlob;
  if (!(entry.file.type === "image/jpeg" || /\.jpe?g$/i.test(entry.name)) || fmt !== "image/jpeg") return resultBlob;
  try {
    const od = await fileToDataUrl(entry.file);
    if (!od) return resultBlob;
    const exif = piexif.dump(piexif.load(od));
    const cd = await blobToDataUrl(resultBlob);
    if (!cd) return resultBlob;
    return dataUrlToBlob(piexif.insert(exif, cd));
  } catch (e) {
    return resultBlob;
  }
}
async function readDirectory(dirEntry, path = "") {
  return new Promise(resolve => {
    const reader = dirEntry.createReader();
    const results = [];
    const readBatch = () => {
      reader.readEntries(entries => {
        if (!entries.length) {
          resolve(results);
          return;
        }
        let p = entries.length;
        entries.forEach(e => {
          if (e.isFile) {
            e.file(f => {
              results.push({
                file: f,
                relativePath: path ? path + "/" + f.name : f.name
              });
              if (! --p) readBatch();
            });
          } else if (e.isDirectory) {
            readDirectory(e, path ? path + "/" + e.name : e.name).then(s => {
              results.push(...s);
              if (! --p) readBatch();
            });
          } else {
            if (! --p) readBatch();
          }
        });
      });
    };
    readBatch();
  });
}
function useEscapeKey(cb) {
  useEffect(() => {
    const h = e => {
      if (e.key === "Escape") cb();
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [cb]);
}

// ─── StatusIcon ───────────────────────────────────────────────────────────────
const StatusIcon = ({
  status
}) => {
  if (status === "done") return /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 18 18",
    fill: "none"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "9",
    r: "9",
    fill: "var(--success)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M5 9.5l2.5 2.5L13 6",
    stroke: "#fff",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }));
  if (status === "converting") return /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 18 18",
    className: "spin"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "9",
    r: "7",
    stroke: "var(--accent)",
    strokeWidth: "2",
    fill: "none",
    strokeDasharray: "30 14"
  }));
  if (status === "error") return /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 18 18",
    fill: "none"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "9",
    r: "9",
    fill: "var(--error)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M6 6l6 6M12 6l-6 6",
    stroke: "#fff",
    strokeWidth: "2",
    strokeLinecap: "round"
  }));
  return /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 18 18",
    fill: "none"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "9",
    r: "8",
    stroke: "var(--muted)",
    strokeWidth: "1.5",
    strokeDasharray: "3 3"
  }));
};
function Toggle({
  on,
  onToggle,
  label,
  desc
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: onToggle,
    style: {
      width: 36,
      height: 20,
      borderRadius: 10,
      cursor: "pointer",
      transition: "background .2s",
      position: "relative",
      background: on ? "var(--accent)" : "var(--input-border)",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 16,
      height: 16,
      borderRadius: "50%",
      background: "#fff",
      position: "absolute",
      top: 2,
      left: on ? 18 : 2,
      transition: "left .2s"
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: on ? "var(--text)" : "var(--muted)"
    }
  }, label), desc && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: "var(--dimmed)"
    }
  }, desc)));
}

// ╔══════════════════════════════════════════════════════════════════════════════╗
// ║  FIX 2 — PREVIEW MODAL LOADS ORIGINAL ON DEMAND                             ║
// ║  The before/after comparison now creates a temporary blob URL from           ║
// ║  entry.file only while the modal is open, then revokes it on close.          ║
// ║  No full-res image data sits in memory between comparisons.                  ║
// ╚══════════════════════════════════════════════════════════════════════════════╝
function PreviewModal({
  entry,
  onClose
}) {
  const [pos, setPos] = useState(50);
  const ref = useRef(null);
  const [convertedUrl, setConvertedUrl] = useState(null);
  const [originalUrl, setOriginalUrl] = useState(null);
  useEffect(() => {
    if (entry?.convertedBlob) {
      const u = URL.createObjectURL(entry.convertedBlob);
      setConvertedUrl(u);
      return () => URL.revokeObjectURL(u);
    }
  }, [entry]);
  useEffect(() => {
    if (entry?.file) {
      const u = URL.createObjectURL(entry.file);
      setOriginalUrl(u);
      return () => URL.revokeObjectURL(u);
    }
  }, [entry]);
  useEscapeKey(onClose);
  if (!entry?.convertedBlob || !convertedUrl) return null;
  const handleMove = e => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const x = (e.clientX ?? e.touches?.[0]?.clientX ?? 0) - r.left;
    setPos(Math.max(1, Math.min(99, x / r.width * 100)));
  };
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(0,0,0,.85)",
      zIndex: 9999,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: "var(--card)",
      borderRadius: 12,
      padding: 20,
      maxWidth: 820,
      width: "100%",
      maxHeight: "90vh",
      overflow: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text)",
      fontFamily: "var(--font-display)"
    }
  }, "Before / After"), entry.width > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "var(--muted)"
    }
  }, entry.width, "\xD7", entry.height, "px")), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      background: "none",
      border: "none",
      color: "var(--muted)",
      fontSize: 20,
      cursor: "pointer"
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    ref: ref,
    onMouseMove: handleMove,
    onTouchMove: handleMove,
    style: {
      position: "relative",
      width: "100%",
      aspectRatio: "16/10",
      borderRadius: 8,
      overflow: "hidden",
      cursor: "col-resize",
      background: "#000"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: originalUrl || entry.preview,
    alt: "",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      objectFit: "contain"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      width: `${pos}%`,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: convertedUrl,
    alt: "",
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      width: `${100 / (pos / 100)}%`,
      height: "100%",
      objectFit: "contain",
      maxWidth: "none"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 0,
      bottom: 0,
      left: `${pos}%`,
      width: 2,
      background: "var(--accent)",
      transform: "translateX(-1px)",
      pointerEvents: "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%,-50%)",
      width: 28,
      height: 28,
      borderRadius: "50%",
      background: "var(--accent)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 12,
      color: "#000",
      fontWeight: 700
    }
  }, "\u21D4")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 8,
      left: 8,
      background: "rgba(0,0,0,.7)",
      color: "#fff",
      padding: "3px 8px",
      borderRadius: 4,
      fontSize: 10
    }
  }, "Converted \xB7 ", fmt(entry.convertedSize)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 8,
      right: 8,
      background: "rgba(0,0,0,.7)",
      color: "#fff",
      padding: "3px 8px",
      borderRadius: 4,
      fontSize: 10
    }
  }, "Original \xB7 ", fmt(entry.originalSize)))));
}
function SummaryModal({
  files,
  onClose,
  outputFormat,
  doSlugify
}) {
  const [copied, setCopied] = useState(false);
  useEscapeKey(onClose);
  const done = files.filter(f => f.status === "done"),
    errors = files.filter(f => f.status === "error");
  const tO = done.reduce((a, f) => a + f.originalSize, 0),
    tC = done.reduce((a, f) => a + (f.convertedSize || 0), 0);
  const saved = tO - tC,
    avg = tO > 0 ? (saved / tO * 100).toFixed(1) : "0";
  const ext = getFormatExt(outputFormat);
  const copyNames = () => {
    navigator.clipboard.writeText(done.map(f => (doSlugify ? f.slugName : noExt(f.name)) + ext).join("\n")).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  const stats = [{
    l: "Converted",
    v: done.length,
    c: "var(--success)"
  }, {
    l: "Errors",
    v: errors.length,
    c: errors.length ? "var(--error)" : "var(--muted)"
  }, {
    l: "Original size",
    v: fmt(tO),
    c: "var(--text-secondary)"
  }, {
    l: "Converted size",
    v: fmt(tC),
    c: "var(--accent)"
  }, {
    l: "Total saved",
    v: fmt(saved),
    c: "var(--success)"
  }, {
    l: "Avg compression",
    v: avg + "%",
    c: "var(--success)"
  }];
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(0,0,0,.85)",
      zIndex: 9999,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: "var(--card)",
      borderRadius: 12,
      padding: 24,
      maxWidth: 460,
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 15,
      fontWeight: 700,
      color: "var(--text)",
      fontFamily: "var(--font-display)"
    }
  }, "Conversion Summary"), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      background: "none",
      border: "none",
      color: "var(--muted)",
      fontSize: 20,
      cursor: "pointer"
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 10,
      marginBottom: 18
    }
  }, stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: "var(--bg)",
      borderRadius: 8,
      padding: 12,
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 700,
      color: s.c,
      fontFamily: "var(--font-display)"
    }
  }, s.v), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: "var(--muted)",
      marginTop: 3
    }
  }, s.l)))), /*#__PURE__*/React.createElement("button", {
    onClick: copyNames,
    className: "btn btn-secondary",
    style: {
      width: "100%",
      justifyContent: "center",
      fontSize: 12
    }
  }, copied ? "✓ Copied!" : "📋 Copy all filenames")));
}
function DupeModal({
  dupes,
  onKeep,
  onSkip
}) {
  useEscapeKey(onSkip);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onSkip,
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(0,0,0,.85)",
      zIndex: 9999,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: "var(--card)",
      borderRadius: 12,
      padding: 24,
      maxWidth: 440,
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: "var(--text)",
      fontFamily: "var(--font-display)",
      marginBottom: 12
    }
  }, "Duplicates Detected"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "var(--muted)",
      marginBottom: 14
    }
  }, dupes.length, " file", dupes.length !== 1 ? "s" : "", " already in your queue:"), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 180,
      overflow: "auto",
      marginBottom: 16
    }
  }, dupes.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      fontSize: 11,
      color: "var(--text-secondary)",
      padding: "4px 0",
      borderBottom: "1px solid var(--card-border)"
    }
  }, d.name, " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--dimmed)"
    }
  }, "(", fmt(d.originalSize), ")")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary btn-sm",
    onClick: onSkip,
    style: {
      flex: 1,
      justifyContent: "center"
    }
  }, "Skip duplicates"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary btn-sm",
    onClick: onKeep,
    style: {
      flex: 1,
      justifyContent: "center"
    }
  }, "Add anyway"))));
}

// ─── Main Component ───────────────────────────────────────────────────────────
function WebPConverter() {
  const [files, setFiles] = useState([]);
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [isConverting, setIsConverting] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [progress, setProgress] = useState({
    done: 0,
    total: 0,
    chunk: 0,
    totalChunks: 0
  });
  const [previewEntry, setPreviewEntry] = useState(null);
  const [showSummary, setShowSummary] = useState(false);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [dragOverId, setDragOverId] = useState(null);
  const [sortBy, setSortBy] = useState("added");
  const [pendingDupes, setPendingDupes] = useState(null);
  const [pendingNewEntries, setPendingNewEntries] = useState(null);
  const [showWatermark, setShowWatermark] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState(false);
  // FIX 4 — virtual list scroll position
  const [listScrollTop, setListScrollTop] = useState(0);
  // WASM codec status for the current output format
  const [wasmStatus, setWasmStatus] = useState('loading'); // 'loading'|'ready'|'unavailable'

  const dragItemRef = useRef(null);
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);
  const dropRef = useRef(null);
  const abortRef = useRef(false);
  const pauseRef = useRef(false);
  const set = (k, v) => setSettings(p => ({
    ...p,
    [k]: v
  }));
  const {
    quality,
    resizeMode,
    resizeWidth,
    resizeHeight,
    resizePercent,
    maintainAspect,
    chunkSize,
    outputFormat,
    slugify: doSlugify,
    stripExif,
    maxSizeEnabled,
    maxSizeKB,
    theme,
    watermarkEnabled,
    watermarkText,
    watermarkPosition,
    watermarkOpacity,
    watermarkSize
  } = settings;

  // ─── Persist settings ─────────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      try {
        const r = {
          value: localStorage.getItem("converter-settings")
        };
        if (r?.value) setSettings(p => ({
          ...p,
          ...JSON.parse(r.value)
        }));
      } catch (e) {}
      setSettingsLoaded(true);
    })();
  }, []);
  useEffect(() => {
    if (!settingsLoaded) return;
    const t = setTimeout(() => {
      try {
        localStorage.setItem("converter-settings", JSON.stringify(settings));
      } catch (e) {}
    }, 500);
    return () => clearTimeout(t);
  }, [settings, settingsLoaded]);

  // ─── Pre-warm WASM codec when format changes ──────────────────────────────
  useEffect(() => {
    setWasmStatus('loading');
    loadWasmCodec(outputFormat).then(mod => setWasmStatus(mod ? 'ready' : 'unavailable'));
  }, [outputFormat]);

  // ─── File loading ─────────────────────────────────────────────────────────
  const addFiles = useCallback(async (newFiles, relativePaths) => {
    const raw = Array.from(newFiles);
    const valid = [],
      paths = [];
    for (let i = 0; i < raw.length; i++) {
      const ext = "." + raw[i].name.split(".").pop().toLowerCase();
      if (SUPPORTED_EXTENSIONS.includes(ext)) {
        valid.push(raw[i]);
        paths.push(relativePaths?.[i] || raw[i].name);
      }
    }
    if (!valid.length) return;
    setIsLoadingFiles(true);
    // FIX 1 in action: getImageInfoBatch returns { w, h, thumb } where
    // thumb is a ~2 KB data URL. No full-res blob URL is retained.
    const infos = await getImageInfoBatch(valid);
    const entries = valid.map((f, i) => ({
      id: crypto.randomUUID(),
      file: f,
      name: f.name,
      relativePath: paths[i],
      slugName: slugifyName(f.name),
      originalSize: f.size,
      width: infos[i].w,
      height: infos[i].h,
      status: "pending",
      convertedBlob: null,
      convertedSize: null,
      preview: infos[i].thumb,
      // ← tiny data URL, NOT a blob URL
      addedAt: Date.now()
    }));
    setIsLoadingFiles(false);
    setFiles(cur => {
      const dupes = entries.filter(e => cur.some(f => f.name === e.name && f.originalSize === e.originalSize));
      if (dupes.length > 0) {
        setPendingDupes(dupes);
        setPendingNewEntries(entries);
        return cur;
      }
      return [...cur, ...entries];
    });
  }, []);
  const handleDupeKeep = () => {
    if (pendingNewEntries) setFiles(p => [...p, ...pendingNewEntries]);
    setPendingDupes(null);
    setPendingNewEntries(null);
  };
  const handleDupeSkip = () => {
    if (pendingNewEntries && pendingDupes) {
      const dk = new Set(pendingDupes.map(d => d.name + "|" + d.originalSize));
      const f = pendingNewEntries.filter(e => !dk.has(e.name + "|" + e.originalSize));
      if (f.length) setFiles(p => [...p, ...f]);
    }
    setPendingDupes(null);
    setPendingNewEntries(null);
  };
  const handleDrop = useCallback(async e => {
    e.preventDefault();
    setIsDragging(false);
    const items = e.dataTransfer.items;
    if (!items) {
      addFiles(e.dataTransfer.files);
      return;
    }
    const all = [],
      promises = [];
    for (let i = 0; i < items.length; i++) {
      const en = items[i].webkitGetAsEntry?.();
      if (en?.isDirectory) promises.push(readDirectory(en, en.name));else if (en?.isFile) promises.push(new Promise(r => en.file(f => r([{
        file: f,
        relativePath: f.name
      }]))));
    }
    (await Promise.all(promises)).flat().forEach(r => all.push(r));
    if (all.length) addFiles(all.map(r => r.file), all.map(r => r.relativePath));
  }, [addFiles]);
  const handleDragOver = useCallback(e => {
    e.preventDefault();
    setIsDragging(true);
  }, []);
  const handleDragLeave = useCallback(e => {
    e.preventDefault();
    if (dropRef.current && !dropRef.current.contains(e.relatedTarget)) setIsDragging(false);
  }, []);
  const removeFile = id => setFiles(p => p.filter(f => f.id !== id));

  // FIX: clearAll no longer needs to revoke preview URLs — they're data URLs now
  const clearAll = () => {
    setFiles([]);
    setProgress({
      done: 0,
      total: 0,
      chunk: 0,
      totalChunks: 0
    });
  };

  // ─── Sorting + virtual list ───────────────────────────────────────────────
  const sortedFiles = useMemo(() => {
    return [...files].sort((a, b) => {
      if (sortBy === "name-asc") return a.name.localeCompare(b.name);
      if (sortBy === "name-desc") return b.name.localeCompare(a.name);
      if (sortBy === "size-asc") return a.originalSize - b.originalSize;
      if (sortBy === "size-desc") return b.originalSize - a.originalSize;
      if (sortBy === "status") return (STATUS_ORDER[a.status] || 1) - (STATUS_ORDER[b.status] || 1);
      return a.addedAt - b.addedAt;
    });
  }, [files, sortBy]);

  // FIX 4 — Only render rows visible in the scroll window + buffer.
  // 500 rows → at most ~20 DOM nodes rendered at any time.
  const {
    vStart,
    vEnd
  } = useMemo(() => {
    const s = Math.max(0, Math.floor(listScrollTop / ITEM_H) - BUF);
    const e = Math.min(sortedFiles.length, Math.ceil((listScrollTop + LIST_VH) / ITEM_H) + BUF);
    return {
      vStart: s,
      vEnd: e
    };
  }, [listScrollTop, sortedFiles.length]);

  // ─── Drag reorder ─────────────────────────────────────────────────────────
  const handleRowDragStart = (e, id) => {
    dragItemRef.current = id;
    e.dataTransfer.effectAllowed = "move";
  };
  const handleRowDragOver = (e, id) => {
    e.preventDefault();
    setDragOverId(id);
  };
  const handleRowDrop = (e, tid) => {
    e.preventDefault();
    setDragOverId(null);
    const sid = dragItemRef.current;
    if (!sid || sid === tid) return;
    setSortBy("added");
    setFiles(p => {
      const a = [...p],
        si = a.findIndex(f => f.id === sid),
        ti = a.findIndex(f => f.id === tid),
        [m] = a.splice(si, 1);
      a.splice(ti, 0, m);
      return a;
    });
  };

  // ─── Conversion engine ────────────────────────────────────────────────────
  const convertSingle = useCallback((url, q, rMode, rW, rH, rP, asp, fmt, maxOn, maxKB, wmOn, wmTxt, wmPos, wmAlpha, wmSz) => {
    return new Promise(resolve => {
      const img = new Image();
      img.onload = async () => {
        let w = img.naturalWidth,
          h = img.naturalHeight;
        if (rMode === "dimensions") {
          if (asp) {
            const r = Math.min(rW / w, rH / h);
            if (r < 1) {
              w = Math.round(w * r);
              h = Math.round(h * r);
            }
          } else {
            w = rW;
            h = rH;
          }
        } else if (rMode === "percent") {
          const s = rP / 100;
          w = Math.round(w * s);
          h = Math.round(h * s);
        }
        const cv = document.createElement("canvas");
        cv.width = w;
        cv.height = h;
        const ctx = cv.getContext("2d");
        ctx.drawImage(img, 0, 0, w, h);
        if (wmOn && wmTxt) {
          ctx.save();
          ctx.globalAlpha = wmAlpha / 100;
          const fs = Math.max(12, Math.round(wmSz * (w / 1000)));
          ctx.font = `600 ${fs}px sans-serif`;
          ctx.fillStyle = "#fff";
          ctx.strokeStyle = "rgba(0,0,0,.5)";
          ctx.lineWidth = fs / 8;
          const mx = ctx.measureText(wmTxt),
            pad = fs;
          let x, y;
          if (wmPos.includes("left")) x = pad;else if (wmPos.includes("right")) x = w - mx.width - pad;else x = (w - mx.width) / 2;
          if (wmPos.includes("top")) y = pad + fs;else if (wmPos.includes("bottom")) y = h - pad;else y = (h + fs) / 2;
          ctx.strokeText(wmTxt, x, y);
          ctx.fillText(wmTxt, x, y);
          ctx.restore();
        }

        // ── WASM path (MozJPEG / libwebp / libaom / OxiPNG) ─────────────────
        const wasmMod = await loadWasmCodec(fmt);
        if (wasmMod) {
          try {
            const imageData = ctx.getImageData(0, 0, w, h);
            const isPng = fmt === 'image/png';
            const tryWasm = async tryQ => {
              const bytes = await wasmEncodeBytes(wasmMod, imageData, fmt, tryQ);
              if (!bytes) return null;
              const blob = new Blob([bytes], {
                type: fmt
              });
              if (!isPng && maxOn && blob.size > maxKB * 1024 && tryQ > 10) return tryWasm(Math.max(10, tryQ - 8));
              return blob;
            };
            const blob = await tryWasm(q);
            if (blob) {
              resolve({
                blob,
                size: blob.size,
                w,
                h,
                codec: 'wasm'
              });
              return;
            }
          } catch (e) {
            console.warn('[jsquash] encode failed, falling back:', e);
          }
        }

        // ── Canvas fallback ───────────────────────────────────────────────────
        const sq = fmt === "image/webp" || fmt === "image/jpeg" || fmt === "image/avif";
        const tryQ = q => {
          cv.toBlob(b => {
            if (!b) {
              resolve({
                blob: null,
                size: 0,
                w: 0,
                h: 0,
                codec: 'canvas'
              });
              return;
            }
            if (maxOn && b.size > maxKB * 1024 && q > 10 && sq) tryQ(Math.max(10, q - 8));else resolve({
              blob: b,
              size: b.size,
              w,
              h,
              codec: 'canvas'
            });
          }, fmt, sq ? q / 100 : undefined);
        };
        tryQ(q);
      };
      img.onerror = () => resolve({
        blob: null,
        size: 0,
        w: 0,
        h: 0,
        codec: null
      });
      img.src = url;
    });
  }, []);
  const waitWhilePaused = () => new Promise(r => {
    const c = () => {
      if (!pauseRef.current || abortRef.current) r();else setTimeout(c, 200);
    };
    c();
  });
  const runConversion = async (entry, piexif) => {
    const url = URL.createObjectURL(entry.file);
    let res = await convertSingle(url, quality, resizeMode, resizeWidth, resizeHeight, resizePercent, maintainAspect, outputFormat, maxSizeEnabled, maxSizeKB, watermarkEnabled, watermarkText, watermarkPosition, watermarkOpacity, watermarkSize);
    URL.revokeObjectURL(url);
    if (res.blob && piexif) {
      const p = await preserveExif(piexif, entry, res.blob, outputFormat);
      if (p !== res.blob) res = {
        ...res,
        blob: p,
        size: p.size
      };
    }
    return res; // includes w, h from canvas
  };
  const retrySingle = async id => {
    const entry = files.find(f => f.id === id);
    if (!entry) return;
    setFiles(p => p.map(f => f.id === id ? {
      ...f,
      status: "converting"
    } : f));
    let piexif = null;
    if (!stripExif) {
      try {
        piexif = await loadPiexif();
      } catch (e) {}
    }
    const res = await runConversion(entry, piexif);
    setFiles(p => p.map(f => f.id === id ? {
      ...f,
      status: res.blob ? "done" : "error",
      convertedBlob: res.blob,
      convertedSize: res.size,
      width: res.w || f.width,
      height: res.h || f.height
    } : f));
  };

  // ─── Output name helpers ──────────────────────────────────────────────────
  const ext = getFormatExt(outputFormat);
  const getOutputName = useCallback(e => (doSlugify ? e.slugName : noExt(e.name)) + ext, [doSlugify, ext]);

  // ╔══════════════════════════════════════════════════════════════════════════╗
  // ║  FIX 3 — ZIP HELPER: never holds >1 chunk of blobs in memory at once    ║
  // ╚══════════════════════════════════════════════════════════════════════════╝
  const buildAndDownloadZip = useCallback(async (entries, zipName) => {
    const JSZip = await loadJSZip();
    const zip = new JSZip();
    entries.forEach(f => {
      if (!f.convertedBlob) return;
      const p = f.relativePath && f.relativePath.includes("/") ? noExt(f.relativePath).split("/").map(s => doSlugify ? s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") : s).join("/") + ext : getOutputName(f);
      zip.file(p, f.convertedBlob);
    });
    const blob = await zip.generateAsync({
      type: "blob",
      compression: "DEFLATE",
      compressionOptions: {
        level: 1
      }
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = zipName;
    a.click();
    URL.revokeObjectURL(a.href);
  }, [doSlugify, ext, getOutputName]);

  // ╔══════════════════════════════════════════════════════════════════════════╗
  // ║  FIX 3 — convertAll: auto-download each chunk + immediately release     ║
  // ║  converted blobs so peak RAM = ~1 chunk, not all 500 files.             ║
  // ╚══════════════════════════════════════════════════════════════════════════╝
  const convertAll = async () => {
    const pending = files.filter(f => f.status !== "done");
    if (!pending.length) return;
    abortRef.current = false;
    pauseRef.current = false;
    setIsConverting(true);
    setIsPaused(false);
    let piexif = null;
    if (!stripExif) {
      try {
        piexif = await loadPiexif();
      } catch (e) {}
    }
    const tc = Math.ceil(pending.length / chunkSize);
    const isLarge = pending.length > 50; // auto-release mode for large batches
    setProgress({
      done: 0,
      total: pending.length,
      chunk: 1,
      totalChunks: tc
    });
    let processed = 0;
    for (let c = 0; c < tc; c++) {
      if (abortRef.current) break;
      const chunk = pending.slice(c * chunkSize, (c + 1) * chunkSize);
      const chunkIds = new Set(chunk.map(e => e.id));
      setProgress(p => ({
        ...p,
        chunk: c + 1
      }));
      const chunkBlobs = []; // local accumulator — not in React state

      for (const entry of chunk) {
        if (abortRef.current) break;
        if (pauseRef.current) await waitWhilePaused();
        if (abortRef.current) break;
        setFiles(p => p.map(f => f.id === entry.id ? {
          ...f,
          status: "converting"
        } : f));
        const res = await runConversion(entry, piexif);
        setFiles(p => p.map(f => f.id === entry.id ? {
          ...f,
          status: res.blob ? "done" : "error",
          convertedBlob: res.blob,
          convertedSize: res.size,
          width: res.w || f.width,
          height: res.h || f.height
        } : f));
        if (res.blob) chunkBlobs.push({
          ...entry,
          convertedBlob: res.blob,
          convertedSize: res.size
        });
        processed++;
        setProgress(p => ({
          ...p,
          done: processed
        }));
      }

      // For large batches: download this chunk ZIP immediately, then null the blobs.
      // This keeps peak memory to ~1 chunk at a time instead of all 500 blobs.
      if (isLarge && chunkBlobs.length > 0 && !abortRef.current) {
        const zipName = tc > 1 ? `converted-part-${c + 1}-of-${tc}.zip` : `converted-images.zip`;
        await buildAndDownloadZip(chunkBlobs, zipName);
        setFiles(p => p.map(f => chunkIds.has(f.id) ? {
          ...f,
          convertedBlob: null
        } : f));
      }
      if (c < tc - 1 && !abortRef.current) await new Promise(r => setTimeout(r, 300));
    }
    setIsConverting(false);
    setIsPaused(false);
    if (!abortRef.current) setShowSummary(true);
  };
  const cancelConvert = () => {
    abortRef.current = true;
    pauseRef.current = false;
  };
  const togglePause = () => {
    const n = !pauseRef.current;
    pauseRef.current = n;
    setIsPaused(n);
  };

  // ─── Downloads ────────────────────────────────────────────────────────────
  const downloadSingle = e => {
    if (!e.convertedBlob) return;
    const a = document.createElement("a");
    a.href = URL.createObjectURL(e.convertedBlob);
    a.download = getOutputName(e);
    a.click();
    URL.revokeObjectURL(a.href);
  };

  // ╔══════════════════════════════════════════════════════════════════════════╗
  // ║  FIX 5 — downloadAll releases all blobs after the ZIP is saved.         ║
  // ║  User already has the file; no reason to keep ~2 GB in browser RAM.     ║
  // ╚══════════════════════════════════════════════════════════════════════════╝
  const downloadAll = async () => {
    const done = files.filter(f => f.status === "done" && f.convertedBlob);
    if (!done.length) return;
    if (done.length === 1) {
      downloadSingle(done[0]);
      return;
    }
    await buildAndDownloadZip(done, "converted-images.zip");
    // Release blobs — user has the download, no need to keep them in RAM
    setFiles(p => p.map(f => f.status === "done" ? {
      ...f,
      convertedBlob: null
    } : f));
  };
  const copyNames = () => {
    navigator.clipboard.writeText(files.filter(f => f.status === "done").map(f => getOutputName(f)).join("\n")).then(() => {
      setCopyFeedback(true);
      setTimeout(() => setCopyFeedback(false), 2000);
    });
  };

  // ─── Computed stats ───────────────────────────────────────────────────────
  const {
    doneCount,
    errorCount,
    totalSavings,
    totalInputSize
  } = useMemo(() => {
    let dc = 0,
      ec = 0,
      ts = 0,
      ti = 0;
    for (const f of files) {
      ti += f.originalSize;
      if (f.status === "done") {
        dc++;
        ts += f.originalSize - (f.convertedSize || 0);
      } else if (f.status === "error") ec++;
    }
    return {
      doneCount: dc,
      errorCount: ec,
      totalSavings: ts,
      totalInputSize: ti
    };
  }, [files]);
  const isLargeBatch = totalInputSize > 500 * 1024 * 1024;
  const tc = Math.ceil(files.filter(f => f.status !== "done").length / chunkSize);

  // ─── Quality label ────────────────────────────────────────────────────────
  const qLabel = quality <= 60 ? {
    t: "⚡ Aggressive — thumbnails, backgrounds",
    c: "var(--accent)"
  } : quality <= 75 ? {
    t: "✓ Good — web images, blog posts",
    c: "var(--text-secondary)"
  } : quality <= 85 ? {
    t: "★ Recommended — best quality/size balance",
    c: "var(--success)"
  } : quality <= 95 ? {
    t: "◆ High — photography, hero images",
    c: "#60a5fa"
  } : {
    t: "◇ Near-lossless — archival, print",
    c: "#c084fc"
  };

  // ─── Theme ────────────────────────────────────────────────────────────────
  const darkV = {
    "--bg": "#0c0c0f",
    "--card": "#18181b",
    "--card-border": "#27272a",
    "--input-bg": "#18181b",
    "--input-border": "#3f3f46",
    "--text": "#fafafa",
    "--text-secondary": "#a1a1aa",
    "--muted": "#71717a",
    "--dimmed": "#52525b",
    "--accent": "#f59e0b",
    "--accent-hover": "#fbbf24",
    "--accent-bg": "rgba(245,158,11,.12)",
    "--success": "#22c55e",
    "--success-bg": "rgba(34,197,94,.1)",
    "--error": "#ef4444",
    "--hover-bg": "#27272a",
    "--drop-bg": "#111114"
  };
  const lightV = {
    "--bg": "#f8f9fa",
    "--card": "#ffffff",
    "--card-border": "#e2e8f0",
    "--input-bg": "#f1f5f9",
    "--input-border": "#cbd5e1",
    "--text": "#0f172a",
    "--text-secondary": "#475569",
    "--muted": "#94a3b8",
    "--dimmed": "#cbd5e1",
    "--accent": "#d97706",
    "--accent-hover": "#b45309",
    "--accent-bg": "rgba(217,119,6,.1)",
    "--success": "#16a34a",
    "--success-bg": "rgba(22,163,74,.08)",
    "--error": "#dc2626",
    "--hover-bg": "#f1f5f9",
    "--drop-bg": "#f1f5f9"
  };
  const vars = theme === "light" ? lightV : darkV;

  // ─── Render ───────────────────────────────────────────────────────────────
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      background: "var(--bg)",
      color: "var(--text-secondary)",
      fontFamily: "'JetBrains Mono','SF Mono','Fira Code',monospace",
      ...vars
    }
  }, /*#__PURE__*/React.createElement("style", null, `
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
        :root{--font-display:'Plus Jakarta Sans',sans-serif}*{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:var(--dimmed);border-radius:3px}
        .spin{animation:spin 1s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.6}}
        .fade-up{animation:fadeUp .25s ease}.pulse{animation:pulse 2s ease-in-out infinite}
        .drop-zone{transition:all .2s ease}.drop-zone:hover{border-color:var(--accent)!important}.drop-zone.active{border-color:var(--accent)!important;background:var(--accent-bg)!important}
        .btn{border:none;cursor:pointer;font-family:inherit;font-size:13px;font-weight:500;padding:9px 18px;border-radius:6px;transition:all .15s;display:inline-flex;align-items:center;gap:5px}
        .btn:disabled{opacity:.35;cursor:not-allowed}
        .btn-primary{background:var(--accent);color:var(--bg)}.btn-primary:hover:not(:disabled){background:var(--accent-hover)}
        .btn-secondary{background:var(--hover-bg);color:var(--text-secondary);border:1px solid var(--card-border)}.btn-secondary:hover:not(:disabled){background:var(--input-border);color:var(--text)}
        .btn-sm{padding:6px 12px;font-size:12px}.btn-xs{padding:4px 10px;font-size:11px}
        input[type=range]{-webkit-appearance:none;width:100%;height:4px;background:var(--input-border);border-radius:2px;outline:none}
        input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;background:var(--accent);border-radius:50%;cursor:pointer}
        .field{background:var(--input-bg);border:1px solid var(--input-border);color:var(--text);padding:8px 12px;border-radius:6px;font-family:inherit;font-size:13px;outline:none;width:100%}.field:focus{border-color:var(--accent)}select.field{cursor:pointer}
        .drag-over{border-color:var(--accent)!important;background:var(--accent-bg)!important}
        .file-row{cursor:grab;user-select:none}.file-row:active{cursor:grabbing}
      `), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1000,
      margin: "0 auto",
      padding: "28px 20px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 34,
      height: 34,
      background: "var(--accent)",
      borderRadius: 8,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--bg)",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M14.5 4h-5L7 7H4a2 2 0 00-2 2v9a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2h-3l-2.5-3z"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "13",
    r: "3"
  }))), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 22,
      fontWeight: 800,
      color: "var(--text)",
      letterSpacing: "-0.5px"
    }
  }, "Mpire Image Batch Converter")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "var(--muted)",
      marginLeft: 46
    }
  }, "Drop images \u2192 adjust \u2192 download. 100% browser-side.", stripExif ? " EXIF auto-stripped." : "")), /*#__PURE__*/React.createElement("button", {
    onClick: () => set("theme", theme === "dark" ? "light" : "dark"),
    style: {
      background: "var(--card)",
      border: "1px solid var(--card-border)",
      borderRadius: 8,
      padding: "7px 14px",
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      gap: 6,
      color: "var(--text-secondary)",
      fontSize: 12,
      fontFamily: "inherit"
    }
  }, theme === "dark" ? "☀ Light" : "🌙 Dark")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--card)",
      border: "1px solid var(--card-border)",
      borderRadius: 10,
      padding: 22,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "2fr 1fr 1fr",
      gap: 22,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 11,
      color: "var(--muted)",
      marginBottom: 8,
      textTransform: "uppercase",
      letterSpacing: "0.5px"
    }
  }, /*#__PURE__*/React.createElement("span", null, "Quality"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)",
      fontWeight: 600,
      fontSize: 13
    }
  }, quality, "%")), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: 1,
    max: 100,
    value: quality,
    onChange: e => set("quality", +e.target.value)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: qLabel.c,
      marginTop: 7,
      lineHeight: 1.3
    }
  }, qLabel.t), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4,
      marginTop: 8
    }
  }, QUALITY_PRESETS.map(p => /*#__PURE__*/React.createElement("button", {
    key: p.value,
    onClick: () => set("quality", p.value),
    style: {
      flex: 1,
      padding: "4px 0",
      fontSize: 11,
      fontFamily: "inherit",
      borderRadius: 4,
      cursor: "pointer",
      transition: "all .15s",
      border: quality === p.value ? "1px solid var(--accent)" : "1px solid var(--input-border)",
      background: quality === p.value ? "var(--accent-bg)" : "var(--hover-bg)",
      color: quality === p.value ? "var(--accent)" : "var(--muted)"
    }
  }, p.label)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 11,
      color: "var(--muted)",
      marginBottom: 8,
      display: "block",
      textTransform: "uppercase",
      letterSpacing: "0.5px"
    }
  }, "Output Format"), /*#__PURE__*/React.createElement("select", {
    className: "field",
    value: outputFormat,
    onChange: e => set("outputFormat", e.target.value)
  }, OUTPUT_FORMATS.map(f => /*#__PURE__*/React.createElement("option", {
    key: f.value,
    value: f.value
  }, f.label, " (", f.ext, ")"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 7,
      display: "flex",
      alignItems: "center",
      gap: 5,
      fontSize: 10
    }
  }, wasmStatus === 'loading' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "spin",
    style: {
      display: "inline-block"
    }
  }, "\u2699"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--muted)"
    }
  }, "Loading ", CODEC_NAMES[outputFormat], "\u2026")), wasmStatus === 'ready' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--success)"
    }
  }, "\u26A1"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--success)",
      fontWeight: 600
    }
  }, CODEC_NAMES[outputFormat]), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--dimmed)"
    }
  }, "WASM active")), wasmStatus === 'unavailable' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--dimmed)"
    }
  }, "\u26A0 Browser codec (WASM unavailable)")))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 11,
      color: "var(--muted)",
      marginBottom: 8,
      textTransform: "uppercase",
      letterSpacing: "0.5px"
    }
  }, /*#__PURE__*/React.createElement("span", null, "Batch Size"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)",
      fontWeight: 600
    }
  }, chunkSize)), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: 5,
    max: 100,
    step: 5,
    value: chunkSize,
    onChange: e => set("chunkSize", +e.target.value)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 10,
      color: "var(--dimmed)",
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("span", null, "Low RAM"), /*#__PURE__*/React.createElement("span", null, "Faster")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gap: 22,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 11,
      color: "var(--muted)",
      marginBottom: 8,
      display: "block",
      textTransform: "uppercase",
      letterSpacing: "0.5px"
    }
  }, "Resize"), /*#__PURE__*/React.createElement("select", {
    className: "field",
    value: resizeMode,
    onChange: e => set("resizeMode", e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: "none"
  }, "No resize (original)"), /*#__PURE__*/React.createElement("option", {
    value: "dimensions"
  }, "Max dimensions (px)"), /*#__PURE__*/React.createElement("option", {
    value: "percent"
  }, "Scale by percent")), resizeMode === "dimensions" && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      display: "flex",
      gap: 6,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: "field",
    type: "number",
    min: 1,
    value: resizeWidth,
    onChange: e => set("resizeWidth", +e.target.value),
    style: {
      width: "48%"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--dimmed)",
      fontSize: 12
    }
  }, "\xD7"), /*#__PURE__*/React.createElement("input", {
    className: "field",
    type: "number",
    min: 1,
    value: resizeHeight,
    onChange: e => set("resizeHeight", +e.target.value),
    style: {
      width: "48%"
    }
  })), /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      marginTop: 6,
      cursor: "pointer",
      fontSize: 11,
      color: "var(--muted)"
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: maintainAspect,
    onChange: e => set("maintainAspect", e.target.checked),
    style: {
      accentColor: "var(--accent)"
    }
  }), " Keep aspect ratio")), resizeMode === "percent" && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 11,
      color: "var(--muted)",
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", null, "Scale"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, resizePercent, "%")), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: 5,
    max: 200,
    value: resizePercent,
    onChange: e => set("resizePercent", +e.target.value)
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 11,
      color: "var(--muted)",
      marginBottom: 8,
      display: "block",
      textTransform: "uppercase",
      letterSpacing: "0.5px"
    }
  }, "Max File Size"), /*#__PURE__*/React.createElement(Toggle, {
    on: maxSizeEnabled,
    onToggle: () => set("maxSizeEnabled", !maxSizeEnabled),
    label: maxSizeEnabled ? "Enabled" : "Disabled"
  }), maxSizeEnabled && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: "field",
    type: "number",
    min: 10,
    max: 10000,
    value: maxSizeKB,
    onChange: e => set("maxSizeKB", +e.target.value)
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--muted)",
      whiteSpace: "nowrap"
    }
  }, "KB")), maxSizeEnabled && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: "var(--dimmed)",
      marginTop: 5
    }
  }, "Auto-reduces quality to hit target")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 11,
      color: "var(--muted)",
      marginBottom: 8,
      display: "block",
      textTransform: "uppercase",
      letterSpacing: "0.5px"
    }
  }, "Options"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Toggle, {
    on: doSlugify,
    onToggle: () => set("slugify", !doSlugify),
    label: "SEO-friendly names",
    desc: "IMG_2026 \u2192 img-2026"
  }), /*#__PURE__*/React.createElement(Toggle, {
    on: stripExif,
    onToggle: () => set("stripExif", !stripExif),
    label: "Strip EXIF metadata",
    desc: stripExif ? "GPS, camera data removed" : outputFormat === "image/jpeg" ? "EXIF preserved in JPG output" : "EXIF only preserved in JPG output"
  }), /*#__PURE__*/React.createElement(Toggle, {
    on: watermarkEnabled,
    onToggle: () => {
      set("watermarkEnabled", !watermarkEnabled);
      if (!watermarkEnabled) setShowWatermark(true);
    },
    label: "Watermark",
    desc: watermarkEnabled && watermarkText ? `"${watermarkText}"` : "Text overlay on images"
  })))), watermarkEnabled && (showWatermark || watermarkText) && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      padding: 14,
      background: "var(--bg)",
      borderRadius: 8,
      border: "1px solid var(--card-border)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text)",
      fontWeight: 500
    }
  }, "Watermark Settings"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setShowWatermark(false),
    style: {
      background: "none",
      border: "none",
      color: "var(--dimmed)",
      cursor: "pointer",
      fontSize: 12
    }
  }, "Hide")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 10,
      color: "var(--dimmed)",
      display: "block",
      marginBottom: 4
    }
  }, "Text"), /*#__PURE__*/React.createElement("input", {
    className: "field",
    value: watermarkText,
    onChange: e => set("watermarkText", e.target.value),
    placeholder: "Your watermark text",
    style: {
      fontSize: 12
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 10,
      color: "var(--dimmed)",
      display: "block",
      marginBottom: 4
    }
  }, "Position"), /*#__PURE__*/React.createElement("select", {
    className: "field",
    value: watermarkPosition,
    onChange: e => set("watermarkPosition", e.target.value),
    style: {
      fontSize: 12
    }
  }, ["top-left", "top-center", "top-right", "center", "bottom-left", "bottom-center", "bottom-right"].map(p => /*#__PURE__*/React.createElement("option", {
    key: p,
    value: p
  }, p)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 10,
      color: "var(--dimmed)",
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", null, "Opacity"), /*#__PURE__*/React.createElement("span", null, watermarkOpacity, "%")), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: 5,
    max: 100,
    value: watermarkOpacity,
    onChange: e => set("watermarkOpacity", +e.target.value)
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 10,
      color: "var(--dimmed)",
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", null, "Size"), /*#__PURE__*/React.createElement("span", null, watermarkSize, "px")), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: 8,
    max: 72,
    value: watermarkSize,
    onChange: e => set("watermarkSize", +e.target.value)
  }))))), isLargeBatch && files.length > 0 && !isConverting && /*#__PURE__*/React.createElement("div", {
    style: {
      background: "rgba(245,158,11,.08)",
      border: "1px solid rgba(245,158,11,.3)",
      borderRadius: 8,
      padding: "10px 14px",
      marginBottom: 14,
      display: "flex",
      gap: 10,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16
    }
  }, "\u26A1"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--accent)",
      fontWeight: 600,
      marginBottom: 2
    }
  }, "Large batch detected \u2014 memory-safe mode active"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: "var(--muted)"
    }
  }, fmt(totalInputSize), " total \xB7 ", tc, " chunk", tc !== 1 ? "s" : "", " of ", chunkSize, " images each.", " ", "Each chunk will auto-download as a separate ZIP and its blobs will be released from memory immediately.", " ", "Lower the Batch Size slider above to reduce peak RAM usage."))), /*#__PURE__*/React.createElement("div", {
    ref: dropRef,
    className: `drop-zone ${isDragging ? "active" : ""}`,
    onDrop: handleDrop,
    onDragOver: handleDragOver,
    onDragLeave: handleDragLeave,
    onClick: () => fileInputRef.current?.click(),
    style: {
      border: "2px dashed var(--input-border)",
      borderRadius: 10,
      padding: files.length === 0 ? "44px 24px" : "18px",
      textAlign: "center",
      cursor: "pointer",
      background: "var(--drop-bg)",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("input", {
    ref: fileInputRef,
    type: "file",
    multiple: true,
    accept: SUPPORTED_EXTENSIONS.join(","),
    style: {
      display: "none"
    },
    onChange: e => {
      addFiles(e.target.files);
      e.target.value = "";
    }
  }), /*#__PURE__*/React.createElement("input", {
    ref: folderInputRef,
    type: "file",
    webkitdirectory: "",
    style: {
      display: "none"
    },
    onChange: e => {
      const fl = e.target.files;
      addFiles(fl, Array.from(fl).map(f => f.webkitRelativePath || f.name));
      e.target.value = "";
    }
  }), isLoadingFiles ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "spin",
    style: {
      display: "inline-block",
      fontSize: 26,
      marginBottom: 4
    }
  }, "\u23F3"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: "var(--accent)"
    }
  }, "Reading image info\u2026")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 26,
      marginBottom: 4
    }
  }, isDragging ? "⬇" : "🖼"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: "var(--text-secondary)",
      marginBottom: 3
    }
  }, isDragging ? "Drop images or folders here" : "Drag & drop images or click to browse"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: "var(--dimmed)"
    }
  }, "PNG, JPG, GIF, BMP, TIFF, SVG, AVIF \xB7 memory-safe for 500+ large files"), files.length === 0 && /*#__PURE__*/React.createElement("button", {
    onClick: e => {
      e.stopPropagation();
      folderInputRef.current?.click();
    },
    className: "btn btn-secondary btn-sm",
    style: {
      marginTop: 10
    }
  }, "\uD83D\uDCC1 Select a folder"))), files.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 10,
      flexWrap: "wrap",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--muted)"
    }
  }, files.length, " image", files.length !== 1 ? "s" : ""), doneCount > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "var(--success)",
      background: "var(--success-bg)",
      padding: "2px 10px",
      borderRadius: 20,
      fontWeight: 500
    }
  }, doneCount, " done \xB7 saved ", fmt(totalSavings)), errorCount > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "var(--error)",
      background: "rgba(239,68,68,.1)",
      padding: "2px 10px",
      borderRadius: 20,
      fontWeight: 500
    }
  }, errorCount, " error", errorCount !== 1 ? "s" : ""), /*#__PURE__*/React.createElement("select", {
    className: "field",
    value: sortBy,
    onChange: e => setSortBy(e.target.value),
    style: {
      width: "auto",
      padding: "4px 8px",
      fontSize: 11
    }
  }, SORT_OPTIONS.map(s => /*#__PURE__*/React.createElement("option", {
    key: s.value,
    value: s.value
  }, s.label)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 5,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary btn-xs",
    onClick: clearAll,
    disabled: isConverting
  }, "Clear"), doneCount > 0 && /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary btn-xs",
    onClick: copyNames
  }, copyFeedback ? "✓ Copied" : "📋 Names"), doneCount > 0 && /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary btn-xs",
    onClick: () => setShowSummary(true)
  }, "\uD83D\uDCCA Summary"), doneCount > 0 && files.some(f => f.convertedBlob) && /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary btn-xs",
    onClick: downloadAll
  }, "\u2193 ", doneCount === 1 ? ext : "ZIP"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary btn-sm",
    onClick: convertAll,
    disabled: isConverting || files.every(f => f.status === "done")
  }, isConverting ? `${progress.done}/${progress.total}` : files.some(f => f.status === "done") && files.some(f => f.status !== "done") ? "Convert remaining" : "Convert all"))), isConverting && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "var(--text-secondary)"
    }
  }, progress.done, "/", progress.total, progress.totalChunks > 1 && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--muted)"
    }
  }, " \xB7 batch ", progress.chunk, "/", progress.totalChunks), isPaused && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)",
      marginLeft: 6
    }
  }, "\u23F8 Paused")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary btn-xs",
    onClick: togglePause
  }, isPaused ? "▶ Resume" : "⏸ Pause"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary btn-xs",
    onClick: cancelConvert
  }, "\u2715 Cancel"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--hover-bg)",
      borderRadius: 3,
      height: 5,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: isPaused ? "" : "pulse",
    style: {
      height: "100%",
      width: `${progress.done / progress.total * 100}%`,
      background: isPaused ? "var(--muted)" : "linear-gradient(90deg,var(--accent),var(--accent-hover))",
      borderRadius: 3,
      transition: "width .3s ease"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    onScroll: e => setListScrollTop(e.currentTarget.scrollTop),
    style: {
      maxHeight: LIST_VH,
      overflowY: "auto",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: vStart * ITEM_H,
      flexShrink: 0
    }
  }), sortedFiles.slice(vStart, vEnd).map(entry => {
    const sav = entry.status === "done" ? entry.originalSize - (entry.convertedSize || 0) : null;
    const pct = sav !== null ? (sav / entry.originalSize * 100).toFixed(0) : null;
    const dName = doSlugify ? entry.slugName : noExt(entry.name);
    return /*#__PURE__*/React.createElement("div", {
      key: entry.id,
      draggable: !isConverting && sortBy === "added",
      onDragStart: e => handleRowDragStart(e, entry.id),
      onDragOver: e => handleRowDragOver(e, entry.id),
      onDrop: e => handleRowDrop(e, entry.id),
      onDragEnd: () => setDragOverId(null),
      className: `fade-up file-row ${dragOverId === entry.id ? "drag-over" : ""}`,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 9,
        background: "var(--card)",
        border: "1px solid var(--card-border)",
        borderRadius: 7,
        padding: "7px 12px",
        transition: "border-color .15s, background .15s",
        marginBottom: 3,
        flexShrink: 0
      }
    }, sortBy === "added" && /*#__PURE__*/React.createElement("div", {
      style: {
        color: "var(--dimmed)",
        fontSize: 12,
        cursor: isConverting ? "default" : "grab",
        flexShrink: 0
      }
    }, "\u283F"), /*#__PURE__*/React.createElement("img", {
      src: entry.preview,
      alt: "",
      style: {
        width: 34,
        height: 34,
        objectFit: "cover",
        borderRadius: 4,
        flexShrink: 0,
        background: "var(--hover-bg)"
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        fontWeight: 500,
        color: "var(--text)",
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis"
      }
    }, dName, /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--dimmed)"
      }
    }, ext)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: "var(--muted)",
        marginTop: 1,
        display: "flex",
        alignItems: "center",
        gap: 6,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("span", null, fmt(entry.originalSize)), entry.width > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--dimmed)"
      }
    }, entry.width, "\xD7", entry.height), entry.status === "done" && entry.convertedSize != null && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", null, "\u2192"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--success)"
      }
    }, fmt(entry.convertedSize)), sav > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--success)"
      }
    }, "\u2212", pct, "%"), sav < 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--error)"
      }
    }, "+", Math.abs(pct), "%")), entry.relativePath?.includes("/") && /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--dimmed)"
      }
    }, "\uD83D\uDCC1 ", entry.relativePath.substring(0, entry.relativePath.lastIndexOf("/"))))), /*#__PURE__*/React.createElement(StatusIcon, {
      status: entry.status
    }), entry.status === "error" && !isConverting && /*#__PURE__*/React.createElement("button", {
      className: "btn btn-secondary btn-xs",
      onClick: () => retrySingle(entry.id),
      title: "Retry"
    }, "\u21BB"), entry.status === "done" && entry.convertedBlob && /*#__PURE__*/React.createElement("button", {
      className: "btn btn-secondary btn-xs",
      onClick: () => setPreviewEntry(entry),
      title: "Compare"
    }, "\uD83D\uDC41"), entry.status === "done" && entry.convertedBlob && /*#__PURE__*/React.createElement("button", {
      className: "btn btn-secondary btn-xs",
      onClick: () => downloadSingle(entry),
      title: "Download"
    }, "\u2193"), /*#__PURE__*/React.createElement("button", {
      onClick: () => removeFile(entry.id),
      disabled: isConverting,
      style: {
        background: "none",
        border: "none",
        color: "var(--dimmed)",
        cursor: isConverting ? "not-allowed" : "pointer",
        fontSize: 14,
        padding: "2px 4px"
      }
    }, "\xD7"));
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: (sortedFiles.length - vEnd) * ITEM_H,
      flexShrink: 0
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      marginTop: 32,
      fontSize: 10,
      color: "var(--dimmed)"
    }
  }, "100% browser-side \xB7 no uploads \xB7 no subscriptions", stripExif ? " · EXIF stripped" : "", " \xB7 saves to your Downloads folder")), previewEntry && /*#__PURE__*/React.createElement(PreviewModal, {
    entry: previewEntry,
    onClose: () => setPreviewEntry(null)
  }), showSummary && /*#__PURE__*/React.createElement(SummaryModal, {
    files: files,
    onClose: () => setShowSummary(false),
    outputFormat: outputFormat,
    doSlugify: doSlugify
  }), pendingDupes && /*#__PURE__*/React.createElement(DupeModal, {
    dupes: pendingDupes,
    onKeep: handleDupeKeep,
    onSkip: handleDupeSkip
  }));
}
ReactDOM.createRoot(document.getElementById("mpio-batch-converter-root")).render(/*#__PURE__*/React.createElement(WebPConverter, null));
