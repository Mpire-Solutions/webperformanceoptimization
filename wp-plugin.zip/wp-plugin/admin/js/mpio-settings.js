/**
 * Mpire Image Optimizer — Settings Page JS
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        var $quality = $('#mpio-quality');
        var $qualityVal = $('#mpio-quality-value');

        // Quality slider value display.
        if ($quality.length) {
            $quality.on('input', function() {
                $qualityVal.text(this.value);
            });
        }

        // Watermark opacity slider.
        var $opacity = $('#mpio-watermark-opacity');
        var $opacityVal = $('#mpio-opacity-value');
        if ($opacity.length) {
            $opacity.on('input', function() {
                $opacityVal.text(this.value);
            });
        }

        // Radio card active state + auto-set quality from preset.
        $('.mpio-radio-card input[type="radio"]').on('change', function() {
            var $group = $(this).closest('.mpio-radio-group');
            $group.find('.mpio-radio-card').removeClass('active');
            $(this).closest('.mpio-radio-card').addClass('active');

            // Auto-set quality slider from preset.
            var presetQuality = $(this).data('quality');
            if (presetQuality && $quality.length) {
                $quality.val(presetQuality).trigger('input');
            }
        });

        // Tooltips: toggle on click.
        $(document).on('click', '.mpio-help-tip', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $tooltip = $(this).find('.mpio-tooltip');
            $('.mpio-tooltip').not($tooltip).hide();
            $tooltip.toggle();
        });

        // Close tooltips when clicking elsewhere.
        $(document).on('click', function() {
            $('.mpio-tooltip').hide();
        });
    });

})(jQuery);
