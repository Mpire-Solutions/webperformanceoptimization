<?php
/**
 * Admin pages and menus for Mpire Image Optimizer.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

class MPIO_Admin {

    private static ?MPIO_Admin $instance = null;

    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu', [ $this, 'register_menus' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_init', [ $this, 'maybe_redirect_after_activation' ] );
    }

    /**
     * Redirect to settings page after activation.
     */
    public function maybe_redirect_after_activation(): void {
        if ( get_transient( 'mpio_activation_redirect' ) ) {
            delete_transient( 'mpio_activation_redirect' );

            if ( ! wp_doing_ajax() && ! isset( $_GET['activate-multi'] ) ) {
                wp_safe_redirect( admin_url( 'options-general.php?page=mpio-getting-started' ) );
                exit;
            }
        }
    }

    /**
     * Register admin menu pages.
     */
    public function register_menus(): void {
        // Main settings page under Settings.
        add_options_page(
            __( 'Mpire Image Optimizer', 'mpire-image-optimizer' ),
            __( 'Mpire Optimizer', 'mpire-image-optimizer' ),
            'manage_options',
            'mpio-settings',
            [ $this, 'render_settings_page' ]
        );

        // Bulk Optimizer under Media.
        add_media_page(
            __( 'Bulk Optimization', 'mpire-image-optimizer' ),
            __( 'Bulk Optimize', 'mpire-image-optimizer' ),
            'upload_files',
            'mpio-bulk-optimizer',
            [ $this, 'render_bulk_page' ]
        );

        // Batch Converter (client-side React app) under Media.
        add_media_page(
            __( 'Batch Converter', 'mpire-image-optimizer' ),
            __( 'Batch Converter', 'mpire-image-optimizer' ),
            'upload_files',
            'mpio-batch-converter',
            [ $this, 'render_batch_converter_page' ]
        );

        // Custom Folders under Media.
        add_media_page(
            __( 'Custom Folders', 'mpire-image-optimizer' ),
            __( 'Custom Folders', 'mpire-image-optimizer' ),
            'manage_options',
            'mpio-custom-folders',
            [ $this, 'render_custom_folders_page' ]
        );

        // Health Check under Media.
        add_media_page(
            __( 'Health Check', 'mpire-image-optimizer' ),
            __( 'Health Check', 'mpire-image-optimizer' ),
            'manage_options',
            'mpio-health-check',
            [ $this, 'render_health_check_page' ]
        );

        // Getting Started under Settings (hidden from menu).
        add_options_page(
            __( 'Getting Started - Mpire Image Optimizer', 'mpire-image-optimizer' ),
            __( 'Getting Started', 'mpire-image-optimizer' ),
            'manage_options',
            'mpio-getting-started',
            [ $this, 'render_getting_started_page' ]
        );
    }

    /**
     * Render the Getting Started page.
     */
    public function render_getting_started_page(): void {
        require_once MPIO_PATH . 'admin/views/getting-started.php';
    }

    /**
     * Enqueue admin CSS and JS on our pages.
     */
    public function enqueue_assets( string $hook ): void {
        // Global: media library column styles.
        if ( 'upload.php' === $hook || 'post.php' === $hook ) {
            wp_enqueue_style(
                'mpio-media-library',
                MPIO_ADMIN_URL . 'css/mpio-media-library.css',
                [],
                MPIO_VERSION . '.' . filemtime( MPIO_PATH . 'admin/css/mpio-media-library.css' )
            );
            wp_enqueue_script(
                'mpio-media-library',
                MPIO_ADMIN_URL . 'js/mpio-media-library.js',
                [ 'jquery' ],
                MPIO_VERSION . '.' . filemtime( MPIO_PATH . 'admin/js/mpio-media-library.js' ),
                true
            );
            wp_localize_script( 'mpio-media-library', 'mpioMedia', [
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'mpio_nonce' ),
                'i18n'    => [
                    'optimizing' => __( 'Optimizing...', 'mpire-image-optimizer' ),
                    'restoring'  => __( 'Restoring...', 'mpire-image-optimizer' ),
                    'error'      => __( 'Error', 'mpire-image-optimizer' ),
                ],
            ] );
        }

        // Our admin pages only.
        $our_pages = [
            'settings_page_mpio-settings',
            'settings_page_mpio-getting-started',
            'media_page_mpio-bulk-optimizer',
            'media_page_mpio-batch-converter',
            'media_page_mpio-custom-folders',
            'media_page_mpio-health-check',
        ];

        if ( ! in_array( $hook, $our_pages, true ) ) {
            return;
        }

        // Common admin styles.
        wp_enqueue_style(
            'mpio-admin',
            MPIO_ADMIN_URL . 'css/mpio-admin.css',
            [],
            MPIO_VERSION . '.' . filemtime( MPIO_PATH . 'admin/css/mpio-admin.css' )
        );

        // Settings page.
        if ( 'settings_page_mpio-settings' === $hook ) {
            wp_enqueue_script(
                'mpio-settings',
                MPIO_ADMIN_URL . 'js/mpio-settings.js',
                [ 'jquery' ],
                MPIO_VERSION . '.' . filemtime( MPIO_PATH . 'admin/js/mpio-settings.js' ),
                true
            );
            wp_localize_script( 'mpio-settings', 'mpioSettings', [
                'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'mpio_nonce' ),
                'settings' => get_option( 'mpio_settings', mpio_get_default_settings() ),
            ] );
        }

        // Bulk optimizer page.
        if ( 'media_page_mpio-bulk-optimizer' === $hook ) {
            wp_enqueue_script(
                'mpio-bulk',
                MPIO_ADMIN_URL . 'js/mpio-bulk-optimizer.js',
                [ 'jquery' ],
                MPIO_VERSION . '.' . filemtime( MPIO_PATH . 'admin/js/mpio-bulk-optimizer.js' ),
                true
            );
            wp_localize_script( 'mpio-bulk', 'mpioBulk', [
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'mpio_nonce' ),
                'i18n'    => [
                    'starting'   => __( 'Starting bulk optimization...', 'mpire-image-optimizer' ),
                    'processing' => __( 'Processing...', 'mpire-image-optimizer' ),
                    'complete'   => __( 'Bulk optimization complete!', 'mpire-image-optimizer' ),
                    'stopped'    => __( 'Bulk optimization stopped.', 'mpire-image-optimizer' ),
                    'error'      => __( 'An error occurred.', 'mpire-image-optimizer' ),
                ],
            ] );
        }

        // Batch converter page — the React app.
        if ( 'media_page_mpio-batch-converter' === $hook ) {
            wp_enqueue_script(
                'react',
                'https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js',
                [],
                '18.3.1',
                true
            );
            wp_enqueue_script(
                'react-dom',
                'https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js',
                [ 'react' ],
                '18.3.1',
                true
            );
            wp_enqueue_script(
                'mpio-batch-converter',
                MPIO_ADMIN_URL . 'js/mpio-batch-converter.js',
                [ 'react', 'react-dom' ],
                MPIO_VERSION . '.' . filemtime( MPIO_PATH . 'admin/js/mpio-batch-converter.js' ),
                true
            );
        }

        // Custom folders page.
        if ( 'media_page_mpio-custom-folders' === $hook ) {
            wp_enqueue_script(
                'mpio-custom-folders',
                MPIO_ADMIN_URL . 'js/mpio-custom-folders.js',
                [ 'jquery' ],
                MPIO_VERSION . '.' . filemtime( MPIO_PATH . 'admin/js/mpio-custom-folders.js' ),
                true
            );
            wp_localize_script( 'mpio-custom-folders', 'mpioFolders', [
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'mpio_nonce' ),
                'abspath' => ABSPATH,
            ] );
        }
    }

    /**
     * Render the settings page.
     */
    public function render_settings_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        include MPIO_PATH . 'admin/views/settings-page.php';
    }

    /**
     * Render the bulk optimizer page.
     */
    public function render_bulk_page(): void {
        if ( ! current_user_can( 'upload_files' ) ) {
            return;
        }
        include MPIO_PATH . 'admin/views/bulk-optimizer.php';
    }

    /**
     * Render the batch converter page (client-side React app).
     */
    public function render_batch_converter_page(): void {
        if ( ! current_user_can( 'upload_files' ) ) {
            return;
        }
        include MPIO_PATH . 'admin/views/batch-converter.php';
    }

    /**
     * Render the custom folders page.
     */
    public function render_custom_folders_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        include MPIO_PATH . 'admin/views/custom-folders.php';
    }

    /**
     * Render the health check / diagnostics page.
     */
    public function render_health_check_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        include MPIO_PATH . 'admin/views/health-check.php';
    }

    /**
     * Get engine status information.
     */
    public static function get_engine_info(): array {
        $info = [
            'current_engine'    => mpio_get_engine(),
            'gd_available'      => extension_loaded( 'gd' ),
            'imagick_available' => extension_loaded( 'imagick' ),
            'gd_formats'        => [],
            'imagick_formats'   => [],
            'php_version'       => PHP_VERSION,
            'memory_limit'      => ini_get( 'memory_limit' ),
            'max_upload'        => wp_max_upload_size(),
        ];

        if ( $info['gd_available'] ) {
            $gd = gd_info();
            $info['gd_formats'] = [
                'jpeg' => true,
                'png'  => true,
                'gif'  => true,
                'webp' => ! empty( $gd['WebP Support'] ),
                'avif' => function_exists( 'imageavif' ),
            ];
        }

        if ( $info['imagick_available'] ) {
            $formats = \Imagick::queryFormats();
            $info['imagick_formats'] = [
                'jpeg' => in_array( 'JPEG', $formats, true ),
                'png'  => in_array( 'PNG', $formats, true ),
                'gif'  => in_array( 'GIF', $formats, true ),
                'webp' => in_array( 'WEBP', $formats, true ),
                'avif' => in_array( 'AVIF', $formats, true ),
            ];
        }

        return $info;
    }
}
