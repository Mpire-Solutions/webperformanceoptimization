<?php
/**
 * Bulk optimization handler for Mpire Image Optimizer.
 *
 * Uses WP Cron for background processing of existing media library images.
 *
 * @package Mpire_Image_Optimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MPIO_Bulk_Optimizer
 *
 * Handles bulk optimization of existing media library images
 * using WP Cron for background processing.
 */
class MPIO_Bulk_Optimizer {

	/**
	 * Single instance of this class.
	 *
	 * @var MPIO_Bulk_Optimizer|null
	 */
	private static $instance = null;

	/**
	 * Transient key for the bulk queue (array of attachment IDs).
	 *
	 * @var string
	 */
	const QUEUE_TRANSIENT = 'mpio_bulk_queue';

	/**
	 * Transient key for the running flag.
	 *
	 * @var string
	 */
	const RUNNING_TRANSIENT = 'mpio_bulk_running';

	/**
	 * Transient key for progress data.
	 *
	 * @var string
	 */
	const PROGRESS_TRANSIENT = 'mpio_bulk_progress';

	/**
	 * Cron action name (legacy, kept for cleanup).
	 *
	 * @var string
	 */
	const CRON_HOOK = 'mpio_bulk_optimization_cron';

	/**
	 * Return the single instance of this class.
	 *
	 * @return MPIO_Bulk_Optimizer
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor. Hooks into WordPress.
	 */
	private function __construct() {
		add_action( 'wp_ajax_mpio_bulk_start', array( $this, 'ajax_start_bulk' ) );
		add_action( 'wp_ajax_mpio_bulk_stop', array( $this, 'ajax_stop_bulk' ) );
		add_action( 'wp_ajax_mpio_bulk_status', array( $this, 'ajax_get_status' ) );
		add_action( 'wp_ajax_mpio_bulk_process_batch', array( $this, 'ajax_process_batch' ) );
		add_action( 'wp_ajax_mpio_bulk_restore_all', array( $this, 'ajax_restore_all' ) );

		// Clean up any leftover legacy cron events.
		if ( wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
		}
	}

	/**
	 * Get attachment IDs that have not been optimized.
	 *
	 * @param string $context The context for the query. Default 'wp'.
	 * @return array Array of attachment IDs.
	 */
	public function get_unoptimized_ids( string $context = 'wp' ): array {
		$supported_types = array(
			'image/jpeg',
			'image/png',
			'image/gif',
			'image/webp',
			'image/avif',
			'image/bmp',
			'image/tiff',
		);

		$args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => $supported_types,
			'post_status'    => 'inherit',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
			'meta_query'     => array(
				'relation' => 'AND',
				array(
					'relation' => 'OR',
					array(
						'key'     => '_mpio_status',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => '_mpio_status',
						'value'   => array( 'optimized', 'skipped' ),
						'compare' => 'NOT IN',
					),
				),
				array(
					'relation' => 'OR',
					array(
						'key'     => '_mpio_excluded',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => '_mpio_excluded',
						'value'   => '1',
						'compare' => '!=',
					),
				),
			),
		);

		/**
		 * Filters the query arguments for retrieving unoptimized attachment IDs.
		 *
		 * @param array  $args    WP_Query arguments.
		 * @param string $context The context for the query.
		 */
		$args = apply_filters( 'mpio_unoptimized_query_args', $args, $context );

		$query = new WP_Query( $args );

		return $query->posts;
	}

	/**
	 * Get bulk optimization statistics.
	 *
	 * @return array {
	 *     @type int $total_images       Total number of images in the library.
	 *     @type int $optimized          Number of optimized images.
	 *     @type int $unoptimized        Number of unoptimized images.
	 *     @type int $errors             Number of images with errors.
	 *     @type int $total_original_size  Total original file size in bytes.
	 *     @type int $total_optimized_size Total optimized file size in bytes.
	 *     @type int $total_savings        Total bytes saved.
	 * }
	 */
	public function get_stats(): array {
		global $wpdb;

		$supported_types = array(
			'image/jpeg',
			'image/png',
			'image/gif',
			'image/webp',
			'image/avif',
			'image/bmp',
			'image/tiff',
		);

		$placeholders = implode( ', ', array_fill( 0, count( $supported_types ), '%s' ) );

		// Total images in the media library.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total_images = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type IN ($placeholders)",
				...$supported_types
			)
		);

		// Optimized count.
		$optimized = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
				WHERE p.post_type = 'attachment'
				AND p.post_mime_type IN ($placeholders)
				AND pm.meta_key = '_mpio_status'
				AND pm.meta_value = 'optimized'",
				...$supported_types
			)
		);

		// Error count.
		$errors = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
				WHERE p.post_type = 'attachment'
				AND p.post_mime_type IN ($placeholders)
				AND pm.meta_key = '_mpio_status'
				AND pm.meta_value = 'error'",
				...$supported_types
			)
		);

		$unoptimized = $total_images - $optimized - $errors;

		// Size totals — stored in serialized _mpio_data, so we must extract in PHP.
		$all_data = $wpdb->get_col(
			"SELECT pm.meta_value FROM {$wpdb->postmeta} pm
			 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			 WHERE pm.meta_key = '_mpio_data'
			 AND p.post_type = 'attachment'"
		);

		$total_original_size  = 0;
		$total_optimized_size = 0;

		foreach ( $all_data as $raw ) {
			$data = maybe_unserialize( $raw );
			if ( is_array( $data ) ) {
				$total_original_size  += (int) ( $data['original_size'] ?? 0 );
				$total_optimized_size += (int) ( $data['optimized_size'] ?? 0 );
			}
		}

		$total_savings = $total_original_size - $total_optimized_size;

		return array(
			'total_images'        => $total_images,
			'optimized'           => $optimized,
			'unoptimized'         => max( 0, $unoptimized ),
			'errors'              => $errors,
			'total_original_size' => $total_original_size,
			'total_optimized_size' => $total_optimized_size,
			'total_savings'       => max( 0, $total_savings ),
		);
	}

	/**
	 * AJAX handler to start bulk optimization.
	 *
	 * @return void
	 */
	public function ajax_start_bulk(): void {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to perform this action.', 'mpire-image-optimizer' ) ),
				403
			);
		}

		// Prevent starting if already running.
		if ( $this->is_running() ) {
			wp_send_json_error(
				array( 'message' => __( 'Bulk optimization is already running.', 'mpire-image-optimizer' ) )
			);
		}

		$ids = $this->get_unoptimized_ids();

		if ( empty( $ids ) ) {
			wp_send_json_success(
				array(
					'message' => __( 'All images are already optimized.', 'mpire-image-optimizer' ),
					'total'   => 0,
				)
			);
		}

		$total = count( $ids );

		// Store the queue and progress data.
		set_transient( self::QUEUE_TRANSIENT, $ids, DAY_IN_SECONDS );
		set_transient( self::RUNNING_TRANSIENT, true, DAY_IN_SECONDS );
		set_transient(
			self::PROGRESS_TRANSIENT,
			array(
				'total'      => $total,
				'processed'  => 0,
				'success'    => 0,
				'errors'     => 0,
				'started_at' => time(),
			),
			DAY_IN_SECONDS
		);

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %d: Number of images to optimize */
					__( 'Bulk optimization started for %d images.', 'mpire-image-optimizer' ),
					$total
				),
				'total'   => $total,
			)
		);
	}

	/**
	 * AJAX handler to process the next batch of images.
	 *
	 * Called repeatedly by the JS until the queue is empty.
	 *
	 * @return void
	 */
	public function ajax_process_batch(): void {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to perform this action.', 'mpire-image-optimizer' ) ),
				403
			);
		}

		if ( ! $this->is_running() ) {
			wp_send_json_success( array(
				'is_running' => false,
				'message'    => __( 'Bulk optimization is not running.', 'mpire-image-optimizer' ),
			) );
			return;
		}

		$queue = get_transient( self::QUEUE_TRANSIENT );

		if ( empty( $queue ) || ! is_array( $queue ) ) {
			$this->complete_bulk();
			$progress               = get_transient( self::PROGRESS_TRANSIENT );
			$progress['is_running'] = false;
			wp_send_json_success( $progress );
			return;
		}

		$chunk_size = (int) mpio_get_setting( 'bulk_chunk_size', 1 );
		$batch      = array_splice( $queue, 0, $chunk_size );
		$progress   = get_transient( self::PROGRESS_TRANSIENT );

		if ( ! is_array( $progress ) ) {
			$progress = array(
				'total'      => count( $batch ) + count( $queue ),
				'processed'  => 0,
				'success'    => 0,
				'errors'     => 0,
				'started_at' => time(),
			);
		}

		$optimizer = MPIO_Optimizer::get_instance();
		$backup    = MPIO_Backup::get_instance();

		foreach ( $batch as $attachment_id ) {
			// Bail early if bulk was stopped.
			if ( ! $this->is_running() ) {
				$progress['is_running'] = false;
				wp_send_json_success( $progress );
				return;
			}

			$progress['processed']++;

			// Create backup before optimizing.
			if ( mpio_get_setting( 'keep_backup', true ) ) {
				$file_path = get_attached_file( $attachment_id );
				if ( $file_path && file_exists( $file_path ) ) {
					$backup->backup( $attachment_id, $file_path );
				}
			}

			// Optimize the image.
			$result = $optimizer->optimize( $attachment_id );

			if ( empty( $result['success'] ) ) {
				$progress['errors']++;
			} else {
				$progress['success']++;
			}

			// Update progress transient.
			set_transient( self::PROGRESS_TRANSIENT, $progress, DAY_IN_SECONDS );
		}

		// Update the queue.
		set_transient( self::QUEUE_TRANSIENT, $queue, DAY_IN_SECONDS );

		// Check if done.
		if ( empty( $queue ) ) {
			$this->complete_bulk();
			$progress['is_running'] = false;
		} else {
			$progress['is_running'] = true;
			$progress['remaining']  = count( $queue );
		}

		wp_send_json_success( $progress );
	}

	/**
	 * Mark bulk optimization as complete.
	 *
	 * @return void
	 */
	private function complete_bulk(): void {
		set_transient( self::RUNNING_TRANSIENT, false, DAY_IN_SECONDS );
		delete_transient( self::QUEUE_TRANSIENT );

		/**
		 * Fires when bulk optimization has completed.
		 */
		do_action( 'mpio_bulk_complete' );
	}

	/**
	 * AJAX handler to stop bulk optimization.
	 *
	 * @return void
	 */
	public function ajax_stop_bulk(): void {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to perform this action.', 'mpire-image-optimizer' ) ),
				403
			);
		}

		// Clear the queue and stop processing.
		delete_transient( self::QUEUE_TRANSIENT );
		set_transient( self::RUNNING_TRANSIENT, false, DAY_IN_SECONDS );

		// Clear any scheduled cron events.
		wp_clear_scheduled_hook( self::CRON_HOOK );

		wp_send_json_success(
			array(
				'message' => __( 'Bulk optimization stopped.', 'mpire-image-optimizer' ),
			)
		);
	}

	/**
	 * AJAX handler to get current bulk optimization status.
	 *
	 * @return void
	 */
	public function ajax_get_status(): void {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to perform this action.', 'mpire-image-optimizer' ) ),
				403
			);
		}

		$progress = get_transient( self::PROGRESS_TRANSIENT );

		if ( ! is_array( $progress ) ) {
			$progress = array(
				'total'      => 0,
				'processed'  => 0,
				'success'    => 0,
				'errors'     => 0,
				'started_at' => 0,
			);
		}

		$progress['is_running'] = $this->is_running();
		$progress['stats']      = $this->get_stats();

		wp_send_json_success( $progress );
	}

	/**
	 * Check whether bulk optimization is currently running.
	 *
	 * @return bool
	 */
	public function is_running(): bool {
		return (bool) get_transient( self::RUNNING_TRANSIENT );
	}

	/**
	 * Start bulk optimization (non-AJAX).
	 *
	 * @return array { total: int, message: string }
	 */
	public function start(): array {
		$ids = $this->get_unoptimized_ids();

		if ( empty( $ids ) ) {
			return array(
				'total'   => 0,
				'message' => __( 'All images are already optimized.', 'mpire-image-optimizer' ),
			);
		}

		$total = count( $ids );

		set_transient( self::QUEUE_TRANSIENT, $ids, DAY_IN_SECONDS );
		set_transient( self::RUNNING_TRANSIENT, true, DAY_IN_SECONDS );
		set_transient(
			self::PROGRESS_TRANSIENT,
			array(
				'total'      => $total,
				'processed'  => 0,
				'success'    => 0,
				'errors'     => 0,
				'started_at' => time(),
			),
			DAY_IN_SECONDS
		);

		return array(
			'total'   => $total,
			'message' => sprintf(
				__( 'Bulk optimization started for %d images.', 'mpire-image-optimizer' ),
				$total
			),
		);
	}

	/**
	 * Stop bulk optimization (non-AJAX).
	 *
	 * @return void
	 */
	public function stop(): void {
		delete_transient( self::QUEUE_TRANSIENT );
		set_transient( self::RUNNING_TRANSIENT, false, DAY_IN_SECONDS );
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	/**
	 * Get current bulk optimization progress (non-AJAX).
	 *
	 * @return array
	 */
	public function get_progress(): array {
		$progress = get_transient( self::PROGRESS_TRANSIENT );

		if ( ! is_array( $progress ) ) {
			$progress = array(
				'total'      => 0,
				'processed'  => 0,
				'success'    => 0,
				'errors'     => 0,
				'started_at' => 0,
			);
		}

		$progress['is_running'] = $this->is_running();

		return $progress;
	}

	/**
	 * AJAX: Restore all optimized images to originals.
	 */
	public function ajax_restore_all() {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'mpire-image-optimizer' ) ] );
		}

		global $wpdb;

		$ids = $wpdb->get_col(
			"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_mpio_backup_path'"
		);

		if ( empty( $ids ) ) {
			wp_send_json_error( [ 'message' => __( 'No backups found to restore.', 'mpire-image-optimizer' ) ] );
		}

		$backup  = MPIO_Backup::get_instance();
		$success = 0;
		$errors  = 0;

		foreach ( $ids as $id ) {
			if ( $backup->restore( (int) $id ) ) {
				$success++;
			} else {
				$errors++;
			}
		}

		mpio_log( 'Bulk restore all completed', 'info', [
			'restored' => $success,
			'errors'   => $errors,
		] );

		wp_send_json_success( [
			'message'  => sprintf(
				/* translators: 1: restored count, 2: error count */
				__( '%1$d images restored, %2$d errors.', 'mpire-image-optimizer' ),
				$success,
				$errors
			),
			'restored' => $success,
			'errors'   => $errors,
		] );
	}
}
