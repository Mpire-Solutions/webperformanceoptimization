<?php
/**
 * Settings registration and sanitization for Mpire Image Optimizer.
 *
 * @package Mpire_Image_Optimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MPIO_Settings
 *
 * Handles registration and sanitization of all plugin settings
 * via the WordPress Settings API. Does NOT render the settings page.
 */
class MPIO_Settings {

	/**
	 * Single instance of this class.
	 *
	 * @var MPIO_Settings|null
	 */
	private static $instance = null;

	/**
	 * Option name used to store all settings.
	 *
	 * @var string
	 */
	const OPTION_NAME = 'mpio_settings';

	/**
	 * Settings page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'mpio-settings';

	/**
	 * Return the single instance of this class.
	 *
	 * @return MPIO_Settings
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor. Hooks into WordPress.
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'update_option_' . self::OPTION_NAME, array( $this, 'on_settings_update' ), 10, 2 );
	}

	/**
	 * When exclude patterns change, delete WebP/AVIF companions for newly-excluded images.
	 *
	 * @param mixed $old_value Previous settings array.
	 * @param mixed $new_value Updated settings array.
	 */
	public function on_settings_update( $old_value, $new_value ): void {
		$old_patterns = $old_value['exclude_patterns'] ?? '';
		$new_patterns = $new_value['exclude_patterns'] ?? '';

		if ( $old_patterns === $new_patterns ) {
			return;
		}

		// Schedule cleanup so it doesn't block the settings save.
		if ( ! wp_next_scheduled( 'mpio_cleanup_excluded_companions' ) ) {
			wp_schedule_single_event( time(), 'mpio_cleanup_excluded_companions' );
		}
	}

	/**
	 * Register the single option and all sections/fields with the Settings API.
	 */
	public function register_settings() {

		register_setting(
			self::PAGE_SLUG,
			self::OPTION_NAME,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize_settings' ),
				'default'           => mpio_get_default_settings(),
			)
		);

		// --- General section ---------------------------------------------------
		add_settings_section(
			'mpio_general',
			__( 'General', 'mpire-image-optimizer' ),
			'__return_null',
			self::PAGE_SLUG
		);

		$general_fields = array(
			'auto_optimize'      => __( 'Auto Optimize', 'mpire-image-optimizer' ),
			'optimization_level' => __( 'Optimization Level', 'mpire-image-optimizer' ),
			'output_format'      => __( 'Output Format', 'mpire-image-optimizer' ),
			'quality'            => __( 'Quality', 'mpire-image-optimizer' ),
			'strip_exif'         => __( 'Strip EXIF Data', 'mpire-image-optimizer' ),
			'keep_backup'        => __( 'Keep Backup', 'mpire-image-optimizer' ),
			'backup_days'        => __( 'Backup Retention (days)', 'mpire-image-optimizer' ),
		);

		foreach ( $general_fields as $id => $label ) {
			add_settings_field(
				$id,
				$label,
				'__return_null', // Rendering handled by admin class.
				self::PAGE_SLUG,
				'mpio_general',
				array( 'label_for' => 'mpio_' . $id )
			);
		}

		// --- Resize section ----------------------------------------------------
		add_settings_section(
			'mpio_resize',
			__( 'Resize', 'mpire-image-optimizer' ),
			'__return_null',
			self::PAGE_SLUG
		);

		$resize_fields = array(
			'resize_enabled'    => __( 'Enable Resizing', 'mpire-image-optimizer' ),
			'resize_max_width'  => __( 'Max Width (px)', 'mpire-image-optimizer' ),
			'resize_max_height' => __( 'Max Height (px)', 'mpire-image-optimizer' ),
		);

		foreach ( $resize_fields as $id => $label ) {
			add_settings_field(
				$id,
				$label,
				'__return_null',
				self::PAGE_SLUG,
				'mpio_resize',
				array( 'label_for' => 'mpio_' . $id )
			);
		}

		// --- Conversion section ------------------------------------------------
		add_settings_section(
			'mpio_conversion',
			__( 'Conversion', 'mpire-image-optimizer' ),
			'__return_null',
			self::PAGE_SLUG
		);

		$conversion_fields = array(
			'convert_to_webp'  => __( 'Convert to WebP', 'mpire-image-optimizer' ),
			'convert_to_avif'  => __( 'Convert to AVIF', 'mpire-image-optimizer' ),
			'delete_original'  => __( 'Delete Original', 'mpire-image-optimizer' ),
		);

		foreach ( $conversion_fields as $id => $label ) {
			add_settings_field(
				$id,
				$label,
				'__return_null',
				self::PAGE_SLUG,
				'mpio_conversion',
				array( 'label_for' => 'mpio_' . $id )
			);
		}

		// --- Watermark section -------------------------------------------------
		add_settings_section(
			'mpio_watermark',
			__( 'Watermark', 'mpire-image-optimizer' ),
			'__return_null',
			self::PAGE_SLUG
		);

		$watermark_fields = array(
			'watermark_enabled'  => __( 'Enable Watermark', 'mpire-image-optimizer' ),
			'watermark_text'     => __( 'Watermark Text', 'mpire-image-optimizer' ),
			'watermark_position' => __( 'Position', 'mpire-image-optimizer' ),
			'watermark_opacity'  => __( 'Opacity', 'mpire-image-optimizer' ),
			'watermark_size'     => __( 'Font Size', 'mpire-image-optimizer' ),
		);

		foreach ( $watermark_fields as $id => $label ) {
			add_settings_field(
				$id,
				$label,
				'__return_null',
				self::PAGE_SLUG,
				'mpio_watermark',
				array( 'label_for' => 'mpio_' . $id )
			);
		}

		// --- Bulk section ------------------------------------------------------
		add_settings_section(
			'mpio_bulk',
			__( 'Bulk', 'mpire-image-optimizer' ),
			'__return_null',
			self::PAGE_SLUG
		);

		$bulk_fields = array(
			'bulk_chunk_size' => __( 'Chunk Size', 'mpire-image-optimizer' ),
			'bulk_thumbnails' => __( 'Include Thumbnails', 'mpire-image-optimizer' ),
		);

		foreach ( $bulk_fields as $id => $label ) {
			add_settings_field(
				$id,
				$label,
				'__return_null',
				self::PAGE_SLUG,
				'mpio_bulk',
				array( 'label_for' => 'mpio_' . $id )
			);
		}

		// --- Advanced section --------------------------------------------------
		add_settings_section(
			'mpio_advanced',
			__( 'Advanced', 'mpire-image-optimizer' ),
			'__return_null',
			self::PAGE_SLUG
		);

		$advanced_fields = array(
			'preferred_engine'  => __( 'Preferred Engine', 'mpire-image-optimizer' ),
			'max_file_size'     => __( 'Max File Size (KB)', 'mpire-image-optimizer' ),
			'slugify_filenames' => __( 'Slugify Filenames', 'mpire-image-optimizer' ),
		);

		foreach ( $advanced_fields as $id => $label ) {
			add_settings_field(
				$id,
				$label,
				'__return_null',
				self::PAGE_SLUG,
				'mpio_advanced',
				array( 'label_for' => 'mpio_' . $id )
			);
		}
	}

	/**
	 * Sanitize and validate all settings before they are saved.
	 *
	 * @param array $input Raw input from the settings form.
	 * @return array Sanitized settings merged with defaults.
	 */
	public function sanitize_settings( $input ) {

		$defaults  = mpio_get_default_settings();
		$sanitized = array();

		// --- General -----------------------------------------------------------

		$sanitized['auto_optimize'] = ! empty( $input['auto_optimize'] );

		$sanitized['optimization_level'] = isset( $input['optimization_level'] ) && in_array(
			$input['optimization_level'],
			array( 'lossless', 'lossy', 'ultra' ),
			true
		) ? $input['optimization_level'] : $defaults['optimization_level'];

		$sanitized['output_format'] = isset( $input['output_format'] ) && in_array(
			$input['output_format'],
			array( 'original', 'webp', 'avif', 'jpeg', 'png' ),
			true
		) ? $input['output_format'] : $defaults['output_format'];

		$sanitized['quality'] = isset( $input['quality'] )
			? (int) min( 100, max( 1, intval( $input['quality'] ) ) )
			: $defaults['quality'];

		$sanitized['strip_exif']  = ! empty( $input['strip_exif'] );
		$sanitized['keep_backup'] = ! empty( $input['keep_backup'] );

		$sanitized['backup_days'] = isset( $input['backup_days'] )
			? absint( $input['backup_days'] )
			: $defaults['backup_days'];

		// --- Resize ------------------------------------------------------------

		$sanitized['resize_enabled'] = ! empty( $input['resize_enabled'] );

		$sanitized['resize_max_width'] = isset( $input['resize_max_width'] )
			? absint( $input['resize_max_width'] )
			: $defaults['resize_max_width'];

		$sanitized['resize_max_height'] = isset( $input['resize_max_height'] )
			? absint( $input['resize_max_height'] )
			: $defaults['resize_max_height'];

		// --- Conversion --------------------------------------------------------

		$sanitized['convert_to_webp'] = ! empty( $input['convert_to_webp'] );
		$sanitized['convert_to_avif'] = ! empty( $input['convert_to_avif'] );
		$sanitized['delete_original'] = ! empty( $input['delete_original'] );

		// --- Watermark ---------------------------------------------------------

		$sanitized['watermark_enabled'] = ! empty( $input['watermark_enabled'] );

		$sanitized['watermark_text'] = isset( $input['watermark_text'] )
			? sanitize_text_field( $input['watermark_text'] )
			: $defaults['watermark_text'];

		$valid_positions = array( 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center' );
		$sanitized['watermark_position'] = isset( $input['watermark_position'] ) && in_array(
			$input['watermark_position'],
			$valid_positions,
			true
		) ? $input['watermark_position'] : $defaults['watermark_position'];

		$sanitized['watermark_opacity'] = isset( $input['watermark_opacity'] )
			? (int) min( 100, max( 1, intval( $input['watermark_opacity'] ) ) )
			: $defaults['watermark_opacity'];

		$sanitized['watermark_size'] = isset( $input['watermark_size'] )
			? (int) min( 72, max( 8, intval( $input['watermark_size'] ) ) )
			: $defaults['watermark_size'];

		// --- Bulk --------------------------------------------------------------

		$sanitized['bulk_chunk_size'] = isset( $input['bulk_chunk_size'] )
			? (int) min( 50, max( 1, intval( $input['bulk_chunk_size'] ) ) )
			: $defaults['bulk_chunk_size'];

		$sanitized['bulk_thumbnails'] = ! empty( $input['bulk_thumbnails'] );

		// --- Advanced ----------------------------------------------------------

		$sanitized['preferred_engine'] = isset( $input['preferred_engine'] ) && in_array(
			$input['preferred_engine'],
			array( 'auto', 'gd', 'imagick' ),
			true
		) ? $input['preferred_engine'] : $defaults['preferred_engine'];

		$sanitized['max_file_size'] = isset( $input['max_file_size'] )
			? absint( $input['max_file_size'] )
			: $defaults['max_file_size'];

		$sanitized['slugify_filenames'] = ! empty( $input['slugify_filenames'] );

		// --- Exclude ---------------------------------------------------------------

		$sanitized['exclude_patterns'] = isset( $input['exclude_patterns'] )
			? sanitize_textarea_field( $input['exclude_patterns'] )
			: $defaults['exclude_patterns'];

		// --- Display / Serving -------------------------------------------------

		$sanitized['display_mode'] = isset( $input['display_mode'] ) && in_array(
			$input['display_mode'],
			array( 'picture', 'rewrite', 'both', 'none' ),
			true
		) ? $input['display_mode'] : $defaults['display_mode'];

		$sanitized['rewrite_rules'] = ! empty( $input['rewrite_rules'] );

		// --- Custom folders (preserved, not user-editable via this form) -------

		$existing = get_option( self::OPTION_NAME, array() );
		$sanitized['custom_folders'] = isset( $existing['custom_folders'] ) && is_array( $existing['custom_folders'] )
			? $existing['custom_folders']
			: array();

		// Merge with defaults so any missing keys are filled in.
		return wp_parse_args( $sanitized, $defaults );
	}
}
