<?php
/**
 * Custom Folders optimization class for Mpire Image Optimizer.
 *
 * Allows users to optimize images in custom directories outside the
 * standard WordPress uploads folder.
 *
 * @package Mpire_Image_Optimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MPIO_Custom_Folders
 *
 * Manages image optimization for user-defined folders outside wp-content/uploads.
 */
class MPIO_Custom_Folders {

	/**
	 * Singleton instance.
	 *
	 * @var MPIO_Custom_Folders|null
	 */
	private static $instance = null;

	/**
	 * Custom files database table name (without prefix).
	 *
	 * @var string
	 */
	private $table_name;

	/**
	 * Returns the singleton instance.
	 *
	 * @return MPIO_Custom_Folders
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor. Hooks AJAX actions for folder management.
	 */
	private function __construct() {
		global $wpdb;
		$this->table_name = $wpdb->prefix . 'mpio_custom_files';

		add_action( 'wp_ajax_mpio_add_folder', array( $this, 'ajax_add_folder' ) );
		add_action( 'wp_ajax_mpio_remove_folder', array( $this, 'ajax_remove_folder' ) );
		add_action( 'wp_ajax_mpio_scan_folder', array( $this, 'ajax_scan_folder' ) );
		add_action( 'wp_ajax_mpio_optimize_custom', array( $this, 'ajax_optimize_custom' ) );
		add_action( 'wp_ajax_mpio_optimize_custom_folder', array( $this, 'ajax_optimize_custom_folder' ) );

		// Scheduled scan for custom folders.
		add_action( 'mpio_custom_folder_scan_cron', array( $this, 'scheduled_scan' ) );
		$this->maybe_schedule_scan();
	}

	/**
	 * Returns the list of supported image file extensions.
	 *
	 * @return array
	 */
	public function get_supported_extensions() {
		return array( '.jpg', '.jpeg', '.png', '.gif', '.webp', '.avif', '.bmp', '.tiff' );
	}

	/**
	 * Validates that a given path is within ABSPATH.
	 *
	 * @param string $path Absolute path to validate.
	 * @return bool
	 */
	public function is_valid_folder( $path ) {
		$real_path    = realpath( $path );
		$real_abspath = realpath( ABSPATH );

		if ( false === $real_path || false === $real_abspath ) {
			return false;
		}

		// Must be within ABSPATH.
		if ( 0 !== strpos( $real_path, $real_abspath ) ) {
			return false;
		}

		// Block sensitive directories.
		$blocked = [
			$real_abspath . 'wp-admin',
			$real_abspath . 'wp-includes',
			realpath( MPIO_PATH ) ?: '', // our own plugin directory
		];

		foreach ( $blocked as $blocked_dir ) {
			if ( $blocked_dir && 0 === strpos( $real_path, $blocked_dir ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Adds a custom folder for optimization.
	 *
	 * Validates the path, prevents adding wp-content/uploads, scans for images,
	 * and inserts discovered files into the custom files table.
	 *
	 * @param string $folder_path Absolute path to the folder.
	 * @return array {
	 *     @type bool   $success     Whether the folder was added.
	 *     @type string $folder_path The normalized folder path.
	 *     @type int    $file_count  Number of image files discovered.
	 *     @type string $message     Status message.
	 * }
	 */
	public function add_folder( $folder_path ) {
		$folder_path = wp_normalize_path( untrailingslashit( $folder_path ) );

		if ( ! is_dir( $folder_path ) ) {
			return array(
				'success'     => false,
				'folder_path' => $folder_path,
				'file_count'  => 0,
				'message'     => __( 'The specified folder does not exist.', 'mpire-image-optimizer' ),
			);
		}

		if ( ! $this->is_valid_folder( $folder_path ) ) {
			return array(
				'success'     => false,
				'folder_path' => $folder_path,
				'file_count'  => 0,
				'message'     => __( 'The folder must be within the WordPress installation directory.', 'mpire-image-optimizer' ),
			);
		}

		// Prevent adding the uploads directory.
		$uploads_dir = wp_normalize_path( untrailingslashit( wp_upload_dir()['basedir'] ) );
		if ( 0 === strpos( $folder_path, $uploads_dir ) || 0 === strpos( $uploads_dir, $folder_path ) ) {
			return array(
				'success'     => false,
				'folder_path' => $folder_path,
				'file_count'  => 0,
				'message'     => __( 'The uploads directory is handled by the media library optimizer.', 'mpire-image-optimizer' ),
			);
		}

		// Check if folder is already added.
		$folders = $this->get_folders();
		if ( in_array( $folder_path, $folders, true ) ) {
			return array(
				'success'     => false,
				'folder_path' => $folder_path,
				'file_count'  => 0,
				'message'     => __( 'This folder has already been added.', 'mpire-image-optimizer' ),
			);
		}

		// Add folder to settings.
		$folders[] = $folder_path;
		$settings = get_option( 'mpio_settings', array() );
		$settings['custom_folders'] = $folders;
		update_option( 'mpio_settings', $settings );

		// Scan and insert files.
		$files = $this->scan_folder( $folder_path );
		$this->insert_files_to_db( $folder_path, $files );

		return array(
			'success'     => true,
			'folder_path' => $folder_path,
			'file_count'  => count( $files ),
			'message'     => sprintf(
				/* translators: %d: number of images found */
				__( 'Folder added successfully. %d image(s) found.', 'mpire-image-optimizer' ),
				count( $files )
			),
		);
	}

	/**
	 * Removes a custom folder and its database records.
	 *
	 * @param string $folder_path Absolute path to the folder.
	 * @return bool True on success.
	 */
	public function remove_folder( $folder_path ) {
		global $wpdb;

		$folder_path = wp_normalize_path( untrailingslashit( $folder_path ) );
		$folders     = $this->get_folders();
		$key         = array_search( $folder_path, $folders, true );

		if ( false === $key ) {
			return false;
		}

		unset( $folders[ $key ] );
		$folders = array_values( $folders );
		$settings = get_option( 'mpio_settings', array() );
		$settings['custom_folders'] = $folders;
		update_option( 'mpio_settings', $settings );

		// Remove file records from the database.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$this->table_name} WHERE folder_path = %s",
				$folder_path
			)
		);

		return true;
	}

	/**
	 * Recursively scans a folder for supported image files.
	 *
	 * @param string $folder_path Absolute path to the folder.
	 * @return array Array of associative arrays with file_path, file_size, mime_type.
	 */
	public function scan_folder( $folder_path ) {
		$folder_path  = wp_normalize_path( untrailingslashit( $folder_path ) );
		$images       = array();
		$extensions   = $this->get_supported_extensions();

		if ( ! is_dir( $folder_path ) || ! $this->is_valid_folder( $folder_path ) ) {
			return $images;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $folder_path, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::SELF_FIRST
		);

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) {
				continue;
			}

			$ext = strtolower( '.' . $file->getExtension() );
			if ( ! in_array( $ext, $extensions, true ) ) {
				continue;
			}

			$file_path = wp_normalize_path( $file->getPathname() );
			$mime_type = wp_check_filetype( $file_path )['type'];

			if ( empty( $mime_type ) ) {
				$mime_type = mime_content_type( $file_path );
			}

			$images[] = array(
				'file_path' => $file_path,
				'file_size' => $file->getSize(),
				'mime_type' => $mime_type ? $mime_type : '',
			);
		}

		return $images;
	}

	/**
	 * Syncs a folder by comparing files on disk with database records.
	 *
	 * Adds new files and removes records for deleted files.
	 *
	 * @param string $folder_path Absolute path to the folder.
	 * @return array {
	 *     @type int $added     Number of new files added.
	 *     @type int $removed   Number of deleted file records removed.
	 *     @type int $unchanged Number of files that remained the same.
	 * }
	 */
	public function sync_folder( $folder_path ) {
		global $wpdb;

		$folder_path = wp_normalize_path( untrailingslashit( $folder_path ) );

		// Get files currently on disk.
		$disk_files = $this->scan_folder( $folder_path );
		$disk_paths = wp_list_pluck( $disk_files, 'file_path' );

		// Get files currently in the database.
		$db_records = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, file_path FROM {$this->table_name} WHERE folder_path = %s",
				$folder_path
			)
		);
		$db_paths = wp_list_pluck( $db_records, 'file_path' );

		// Determine new, removed, and unchanged.
		$new_paths     = array_diff( $disk_paths, $db_paths );
		$removed_paths = array_diff( $db_paths, $disk_paths );
		$unchanged     = count( array_intersect( $disk_paths, $db_paths ) );

		// Insert new files.
		$new_files = array_filter( $disk_files, function ( $file ) use ( $new_paths ) {
			return in_array( $file['file_path'], $new_paths, true );
		} );
		$this->insert_files_to_db( $folder_path, $new_files );

		// Remove deleted file records.
		if ( ! empty( $removed_paths ) ) {
			$placeholders = implode( ',', array_fill( 0, count( $removed_paths ), '%s' ) );
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$this->table_name} WHERE file_path IN ($placeholders)",
					$removed_paths
				)
			);
		}

		return array(
			'added'     => count( $new_paths ),
			'removed'   => count( $removed_paths ),
			'unchanged' => $unchanged,
		);
	}

	/**
	 * Retrieves file records for a given folder from the database.
	 *
	 * @param string $folder_path Absolute path to the folder.
	 * @param string $status      Optional. Filter by status: 'unoptimized', 'optimized', 'error'. Default empty (all).
	 * @return array Array of file record objects.
	 */
	public function get_folder_files( $folder_path, $status = '' ) {
		global $wpdb;

		$folder_path = wp_normalize_path( untrailingslashit( $folder_path ) );

		$query = "SELECT * FROM {$this->table_name} WHERE folder_path = %s";
		$args  = array( $folder_path );

		if ( ! empty( $status ) && in_array( $status, array( 'unoptimized', 'optimized', 'error' ), true ) ) {
			$query .= ' AND status = %s';
			$args[] = $status;
		}

		$query .= ' ORDER BY file_path ASC';

		return $wpdb->get_results( $wpdb->prepare( $query, $args ) );
	}

	/**
	 * Optimizes a single custom folder file by its database ID.
	 *
	 * @param int $file_id The file record ID from the custom files table.
	 * @return array {
	 *     @type bool   $success        Whether optimization succeeded.
	 *     @type string $file_path      Path to the optimized file.
	 *     @type int    $original_size  Original file size in bytes.
	 *     @type int    $optimized_size Optimized file size in bytes.
	 *     @type float  $savings_pct    Percentage saved.
	 *     @type string $message        Status message.
	 * }
	 */
	public function optimize_custom_file( $file_id ) {
		global $wpdb;

		$file_id = absint( $file_id );
		$record  = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->table_name} WHERE id = %d",
				$file_id
			)
		);

		if ( ! $record ) {
			return array(
				'success' => false,
				'message' => __( 'File record not found.', 'mpire-image-optimizer' ),
			);
		}

		if ( ! file_exists( $record->file_path ) ) {
			$wpdb->update(
				$this->table_name,
				array( 'status' => 'error' ),
				array( 'id' => $file_id ),
				array( '%s' ),
				array( '%d' )
			);

			return array(
				'success' => false,
				'message' => __( 'File no longer exists on disk.', 'mpire-image-optimizer' ),
			);
		}

		// Create a backup before optimizing (custom folder files have no attachment ID).
		$backup = MPIO_Backup::get_instance();
		$backup_dir = $backup->get_backup_dir() . '/custom-folders';
		if ( wp_mkdir_p( $backup_dir ) ) {
			@copy( $record->file_path, $backup_dir . '/' . wp_basename( $record->file_path ) );
		}

		$original_size = filesize( $record->file_path );

		// Run the optimization.
		$optimizer = MPIO_Optimizer::get_instance();
		$result    = $optimizer->optimize_file( $record->file_path );

		if ( ! $result || ! isset( $result['success'] ) || ! $result['success'] ) {
			$wpdb->update(
				$this->table_name,
				array( 'status' => 'error' ),
				array( 'id' => $file_id ),
				array( '%s' ),
				array( '%d' )
			);

			return array(
				'success'   => false,
				'file_path' => $record->file_path,
				'message'   => isset( $result['message'] ) ? $result['message'] : __( 'Optimization failed.', 'mpire-image-optimizer' ),
			);
		}

		$optimized_size = filesize( $record->file_path );
		$savings_pct    = $original_size > 0 ? round( ( 1 - $optimized_size / $original_size ) * 100, 2 ) : 0;

		// Update the database record.
		$wpdb->update(
			$this->table_name,
			array(
				'status'         => 'optimized',
				'original_size'  => $original_size,
				'optimized_size' => $optimized_size,
				'updated_at'     => current_time( 'mysql' ),
			),
			array( 'id' => $file_id ),
			array( '%s', '%d', '%d', '%s' ),
			array( '%d' )
		);

		return array(
			'success'        => true,
			'file_path'      => $record->file_path,
			'original_size'  => $original_size,
			'optimized_size' => $optimized_size,
			'savings_pct'    => $savings_pct,
			'message'        => __( 'File optimized successfully.', 'mpire-image-optimizer' ),
		);
	}

	/**
	 * Returns aggregate statistics for all custom folder files.
	 *
	 * @return array {
	 *     @type int   $total_files   Total number of custom files.
	 *     @type int   $optimized     Number of optimized files.
	 *     @type int   $unoptimized   Number of unoptimized files.
	 *     @type int   $errors        Number of files with errors.
	 *     @type int   $total_savings Total bytes saved across all optimized files.
	 * }
	 */
	public function get_custom_stats() {
		global $wpdb;

		$total_files = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table_name}" );
		$optimized   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->table_name} WHERE status = %s", 'optimized' ) );
		$unoptimized = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->table_name} WHERE status = %s", 'unoptimized' ) );
		$errors      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->table_name} WHERE status = %s", 'error' ) );

		$total_savings = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COALESCE(SUM(original_size - optimized_size), 0) FROM {$this->table_name} WHERE status = %s",
				'optimized'
			)
		);

		return array(
			'total_files'   => $total_files,
			'optimized'     => $optimized,
			'unoptimized'   => $unoptimized,
			'errors'        => $errors,
			'total_savings' => $total_savings,
		);
	}

	/**
	 * Returns the list of configured custom folders.
	 *
	 * @return array Array of folder path strings.
	 */
	public function get_folders() {
		$folders = mpio_get_setting( 'custom_folders', array() );
		return is_array( $folders ) ? $folders : array();
	}

	/**
	 * AJAX handler: Add a custom folder.
	 *
	 * @return void
	 */
	public function ajax_add_folder() {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mpire-image-optimizer' ) ) );
		}

		$folder_input = isset( $_POST['folder_path'] ) ? sanitize_text_field( wp_unslash( $_POST['folder_path'] ) ) : '';

		if ( empty( $folder_input ) ) {
			wp_send_json_error( array( 'message' => __( 'No folder path provided.', 'mpire-image-optimizer' ) ) );
		}

		// Prepend ABSPATH if a relative path is given.
		$folder_path = $folder_input;
		if ( 0 !== strpos( $folder_path, ABSPATH ) && 0 !== strpos( $folder_path, '/' ) ) {
			$folder_path = ABSPATH . ltrim( $folder_path, '/' );
		}

		$result = $this->add_folder( $folder_path );

		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}

	/**
	 * AJAX handler: Remove a custom folder.
	 *
	 * @return void
	 */
	public function ajax_remove_folder() {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mpire-image-optimizer' ) ) );
		}

		$folder_path = isset( $_POST['folder_path'] ) ? sanitize_text_field( wp_unslash( $_POST['folder_path'] ) ) : '';

		if ( empty( $folder_path ) ) {
			wp_send_json_error( array( 'message' => __( 'No folder path provided.', 'mpire-image-optimizer' ) ) );
		}

		$removed = $this->remove_folder( $folder_path );

		if ( $removed ) {
			wp_send_json_success( array( 'message' => __( 'Folder removed successfully.', 'mpire-image-optimizer' ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Folder not found in settings.', 'mpire-image-optimizer' ) ) );
		}
	}

	/**
	 * AJAX handler: Scan/sync a custom folder.
	 *
	 * @return void
	 */
	public function ajax_scan_folder() {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mpire-image-optimizer' ) ) );
		}

		$folder_path = isset( $_POST['folder_path'] ) ? sanitize_text_field( wp_unslash( $_POST['folder_path'] ) ) : '';

		if ( empty( $folder_path ) ) {
			wp_send_json_error( array( 'message' => __( 'No folder path provided.', 'mpire-image-optimizer' ) ) );
		}

		$result = $this->sync_folder( $folder_path );

		wp_send_json_success( array(
			'message' => sprintf(
				/* translators: 1: added count, 2: removed count, 3: unchanged count */
				__( 'Sync complete. Added: %1$d, Removed: %2$d, Unchanged: %3$d.', 'mpire-image-optimizer' ),
				$result['added'],
				$result['removed'],
				$result['unchanged']
			),
			'added'     => $result['added'],
			'removed'   => $result['removed'],
			'unchanged' => $result['unchanged'],
		) );
	}

	/**
	 * AJAX handler: Optimize a custom folder file.
	 *
	 * @return void
	 */
	public function ajax_optimize_custom() {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mpire-image-optimizer' ) ) );
		}

		$file_id = isset( $_POST['file_id'] ) ? absint( $_POST['file_id'] ) : 0;

		if ( ! $file_id ) {
			wp_send_json_error( array( 'message' => __( 'No file ID provided.', 'mpire-image-optimizer' ) ) );
		}

		$result = $this->optimize_custom_file( $file_id );

		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}

	/**
	 * AJAX handler: Optimize all unoptimized files in a custom folder.
	 *
	 * @return void
	 */
	public function ajax_optimize_custom_folder() {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mpire-image-optimizer' ) ) );
		}

		$folder_path = isset( $_POST['folder_path'] ) ? sanitize_text_field( wp_unslash( $_POST['folder_path'] ) ) : '';

		if ( empty( $folder_path ) ) {
			wp_send_json_error( array( 'message' => __( 'No folder path provided.', 'mpire-image-optimizer' ) ) );
		}

		$files   = $this->get_folder_files( $folder_path, 'unoptimized' );
		$success = 0;
		$errors  = 0;

		foreach ( $files as $file ) {
			$result = $this->optimize_custom_file( $file->id );
			if ( ! empty( $result['success'] ) ) {
				$success++;
			} else {
				$errors++;
			}
		}

		wp_send_json_success( array(
			'message'  => sprintf(
				__( 'Optimized %1$d files, %2$d errors.', 'mpire-image-optimizer' ),
				$success,
				$errors
			),
			'success_count' => $success,
			'error_count'   => $errors,
		) );
	}

	/**
	 * Inserts scanned image files into the custom files database table.
	 *
	 * @param string $folder_path The parent folder path.
	 * @param array  $files       Array of file arrays with file_path, file_size, mime_type.
	 * @return void
	 */
	private function insert_files_to_db( $folder_path, $files ) {
		global $wpdb;

		foreach ( $files as $file ) {
			$exists = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$this->table_name} WHERE file_path = %s",
					$file['file_path']
				)
			);

			if ( $exists ) {
				continue;
			}

			$wpdb->insert(
				$this->table_name,
				array(
					'folder_path'   => $folder_path,
					'file_path'     => $file['file_path'],
					'file_hash'     => md5_file( $file['file_path'] ) ?: '',
					'original_size' => $file['file_size'],
					'status'        => 'unoptimized',
					'created_at'    => current_time( 'mysql' ),
				),
				array( '%s', '%s', '%s', '%d', '%s', '%s' )
			);
		}
	}

	/**
	 * Schedule the custom folder scan cron if folders are configured.
	 */
	private function maybe_schedule_scan() {
		$folders = $this->get_folders();

		if ( empty( $folders ) ) {
			wp_clear_scheduled_hook( 'mpio_custom_folder_scan_cron' );
			return;
		}

		if ( ! wp_next_scheduled( 'mpio_custom_folder_scan_cron' ) ) {
			wp_schedule_event( time(), 'twicedaily', 'mpio_custom_folder_scan_cron' );
		}
	}

	/**
	 * Cron callback: scan all custom folders for new/deleted files.
	 */
	public function scheduled_scan() {
		$folders = $this->get_folders();

		if ( empty( $folders ) ) {
			return;
		}

		foreach ( $folders as $folder ) {
			if ( ! is_dir( $folder ) ) {
				continue;
			}

			$result = $this->sync_folder( $folder );

			if ( $result['added'] > 0 || $result['removed'] > 0 ) {
				mpio_log( 'Custom folder scan', 'info', [
					'folder'  => $folder,
					'added'   => $result['added'],
					'removed' => $result['removed'],
				] );
			}
		}
	}
}
