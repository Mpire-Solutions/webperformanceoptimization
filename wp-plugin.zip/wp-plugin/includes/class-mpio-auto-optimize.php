<?php
/**
 * Auto-optimize images on upload.
 *
 * Hooks into the WordPress upload process to automatically optimize
 * images when they are uploaded to the media library.
 *
 * @package Mpire_Image_Optimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MPIO_Auto_Optimize
 *
 * Automatically optimizes images during the WordPress upload process.
 */
class MPIO_Auto_Optimize {

	/**
	 * Singleton instance.
	 *
	 * @var MPIO_Auto_Optimize|null
	 */
	private static $instance = null;

	/**
	 * Tracked upload attachment IDs.
	 *
	 * @var int[]
	 */
	private static $upload_ids = array();

	/**
	 * Get the singleton instance.
	 *
	 * @return MPIO_Auto_Optimize
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * Registers hooks for auto-optimization if the setting is enabled.
	 */
	private function __construct() {
		if ( ! mpio_get_setting( 'auto_optimize' ) ) {
			return;
		}

		add_filter( 'wp_generate_attachment_metadata', array( $this, 'optimize_on_upload' ), 10, 2 );
		add_action( 'add_attachment', array( $this, 'track_upload' ) );
	}

	/**
	 * Track a freshly uploaded attachment.
	 *
	 * Hooked to 'add_attachment'. Stores the attachment ID so we can
	 * identify it as a new upload later in the metadata generation filter.
	 *
	 * @param int $attachment_id The attachment post ID.
	 * @return void
	 */
	public function track_upload( $attachment_id ) {
		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return;
		}

		self::$upload_ids[] = $attachment_id;
	}

	/**
	 * Optimize an image after its attachment metadata has been generated.
	 *
	 * Hooked to 'wp_generate_attachment_metadata'. Runs the optimizer
	 * on freshly uploaded images that pass all eligibility checks.
	 *
	 * @param array $metadata      The attachment metadata array.
	 * @param int   $attachment_id The attachment post ID.
	 * @return array The unmodified metadata array.
	 */
	public function optimize_on_upload( $metadata, $attachment_id ) {
		// Only process fresh uploads.
		if ( ! in_array( $attachment_id, self::$upload_ids, true ) ) {
			return $metadata;
		}

		// Only process supported image MIME types.
		$mime_type = get_post_mime_type( $attachment_id );
		if ( ! mpio_is_supported_mime( $mime_type ) ) {
			return $metadata;
		}

		// Verify the image should be optimized.
		if ( ! $this->should_optimize( $attachment_id ) ) {
			return $metadata;
		}

		// Resolve the full file path from metadata.
		$upload_dir = wp_upload_dir();
		$file_path  = trailingslashit( $upload_dir['basedir'] ) . $metadata['file'];

		// Warn about very large uploads (>10MB).
		$file_size = file_exists( $file_path ) ? filesize( $file_path ) : 0;
		if ( $file_size > 10 * 1024 * 1024 ) {
			set_transient( 'mpio_large_upload_warning', [
				'name' => basename( $file_path ),
				'size' => $file_size,
			], 60 );
			mpio_log( 'Large image uploaded: ' . basename( $file_path ), 'warning', [
				'size' => $file_size,
				'id'   => $attachment_id,
			] );
		}

		// Create a backup before optimization.
		MPIO_Backup::get_instance()->backup( $attachment_id, $file_path );

		// Run the optimizer.
		$result = MPIO_Optimizer::get_instance()->optimize( $attachment_id );

		if ( $result['success'] ) {
			mpio_log( 'Auto-optimized on upload', 'info', [
				'id'      => $attachment_id,
				'savings' => $result['savings_percent'] . '%',
			] );

			// Set toast notification for the uploading user.
			$user_id = get_current_user_id();
			if ( $user_id ) {
				set_transient( 'mpio_optimize_toast_' . $user_id, [
					'name'            => basename( $file_path ),
					'savings_percent' => $result['savings_percent'],
					'saved_bytes'     => $result['original_size'] - $result['optimized_size'],
				], 60 );
			}
		} else {
			mpio_log( 'Auto-optimize failed', 'error', [
				'id'   => $attachment_id,
				'file' => basename( $file_path ),
			] );
		}

		/**
		 * Fires after an image has been auto-optimized on upload.
		 *
		 * @param int   $attachment_id The attachment post ID.
		 * @param mixed $result        The optimization result.
		 */
		do_action( 'mpio_after_auto_optimize', $attachment_id, $result );

		return $metadata;
	}

	/**
	 * Determine whether an attachment should be auto-optimized.
	 *
	 * Runs a series of checks including optimization status, MIME type
	 * support, file existence, and file size limits.
	 *
	 * @param int $attachment_id The attachment post ID.
	 * @return bool True if the image should be optimized, false otherwise.
	 */
	public function should_optimize( $attachment_id ) {
		// Skip if manually excluded.
		if ( get_post_meta( $attachment_id, '_mpio_excluded', true ) ) {
			return false;
		}

		// Skip if already optimized.
		$status = get_post_meta( $attachment_id, '_mpio_status', true );
		if ( ! empty( $status ) ) {
			return false;
		}

		// Skip if MIME type is not supported.
		$mime_type = get_post_mime_type( $attachment_id );
		if ( ! mpio_is_supported_mime( $mime_type ) ) {
			return false;
		}

		// Skip if the file does not exist.
		$file_path = get_attached_file( $attachment_id );
		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return false;
		}

		// Skip if file exceeds the maximum allowed size.
		$max_file_size = (int) mpio_get_setting( 'max_file_size' );
		if ( $max_file_size > 0 && filesize( $file_path ) > ( $max_file_size * 1024 ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Check whether auto-optimize is enabled in settings.
	 *
	 * @return bool True if auto-optimize is enabled, false otherwise.
	 */
	public function is_enabled() {
		return (bool) mpio_get_setting( 'auto_optimize' );
	}
}
