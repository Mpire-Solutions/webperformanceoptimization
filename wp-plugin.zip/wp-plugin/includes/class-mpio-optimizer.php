<?php
/**
 * Core image optimization class for Mpire Image Optimizer.
 *
 * Handles image optimization, resizing, format conversion, and watermarking
 * using either GD or Imagick as the processing engine.
 *
 * @package Mpire_Image_Optimizer
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class MPIO_Optimizer
 *
 * Singleton class responsible for all server-side image optimization operations.
 */
class MPIO_Optimizer {

    /**
     * Singleton instance.
     *
     * @var MPIO_Optimizer|null
     */
    private static $instance = null;

    /**
     * Current processing engine: 'gd' or 'imagick'.
     *
     * @var string
     */
    private $engine;

    /**
     * Get the singleton instance.
     *
     * @return MPIO_Optimizer
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to enforce singleton pattern.
     */
    private function __construct() {
        $this->engine = function_exists( 'mpio_get_engine' ) ? mpio_get_engine() : 'gd';
    }

    /**
     * Prevent cloning.
     */
    private function __clone() {}

    /**
     * Prevent unserialization.
     */
    public function __wakeup() {
        throw new \Exception( __( 'Cannot unserialize a singleton.', 'mpire-image-optimizer' ) );
    }

    // =========================================================================
    // Public API
    // =========================================================================

    /**
     * Optimize a WordPress media attachment by ID.
     *
     * @param int   $attachment_id The attachment post ID.
     * @param array $args {
     *     Optional overrides.
     *     @type int    $quality        Image quality 1-100.
     *     @type string $output_format  Target format: jpg, png, webp, avif.
     *     @type array  $resize         { max_width, max_height }.
     *     @type array  $watermark      { text, position, opacity, size }.
     * }
     * @return array {
     *     @type bool   $success
     *     @type int    $original_size
     *     @type int    $optimized_size
     *     @type float  $savings_percent
     *     @type string $format
     *     @type array  $sizes_optimized
     * }
     */
    public function optimize( int $attachment_id, array $args = [] ): array {
        $file_path = get_attached_file( $attachment_id );

        if ( ! $file_path || ! file_exists( $file_path ) ) {
            $this->store_status( $attachment_id, 'error' );
            return [
                'success'         => false,
                'original_size'   => 0,
                'optimized_size'  => 0,
                'savings_percent' => 0.0,
                'format'          => '',
                'sizes_optimized' => [],
            ];
        }

        // Check exclude list.
        if ( function_exists( 'mpio_is_excluded' ) && mpio_is_excluded( $file_path, $attachment_id ) ) {
            $this->store_status( $attachment_id, 'skipped' );
            return [
                'success'         => false,
                'original_size'   => 0,
                'optimized_size'  => 0,
                'savings_percent' => 0.0,
                'format'          => '',
                'sizes_optimized' => [],
            ];
        }

        $mime = get_post_mime_type( $attachment_id );
        if ( ! $this->supports_format( $mime ) ) {
            $this->store_status( $attachment_id, 'skipped' );
            return [
                'success'         => false,
                'original_size'   => 0,
                'optimized_size'  => 0,
                'savings_percent' => 0.0,
                'format'          => $mime,
                'sizes_optimized' => [],
            ];
        }

        // Optimize the main/full image.
        $result = $this->optimize_file( $file_path, $args );

        if ( ! $result['success'] ) {
            $this->store_status( $attachment_id, 'error' );
            return [
                'success'         => false,
                'original_size'   => $result['original_size'],
                'optimized_size'  => $result['optimized_size'],
                'savings_percent' => 0.0,
                'format'          => '',
                'sizes_optimized' => [],
            ];
        }

        $total_original  = $result['original_size'];
        $total_optimized = $result['optimized_size'];
        $sizes_optimized = [];

        // Optimize thumbnails when the bulk_thumbnails setting is enabled.
        $bulk_thumbnails = apply_filters( 'mpio_bulk_thumbnails', (bool) mpio_get_setting( 'bulk_thumbnails', true ) );

        if ( $bulk_thumbnails ) {
            $metadata = wp_get_attachment_metadata( $attachment_id );

            if ( ! empty( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ) {
                $upload_dir = dirname( $file_path );

                foreach ( $metadata['sizes'] as $size_name => $size_data ) {
                    $thumb_path = trailingslashit( $upload_dir ) . $size_data['file'];

                    if ( ! file_exists( $thumb_path ) ) {
                        continue;
                    }

                    $thumb_result = $this->optimize_file( $thumb_path, $args );

                    if ( $thumb_result['success'] ) {
                        $total_original  += $thumb_result['original_size'];
                        $total_optimized += $thumb_result['optimized_size'];

                        $sizes_optimized[ $size_name ] = [
                            'original_size'  => $thumb_result['original_size'],
                            'optimized_size' => $thumb_result['optimized_size'],
                            'output_path'    => $thumb_result['output_path'],
                        ];
                    }
                }
            }
        }

        // Generate companion WebP/AVIF files for content rewriting and server rules.
        $companions = $this->generate_companion_formats( $file_path, $attachment_id, $args );

        $savings_percent = $total_original > 0
            ? round( ( ( $total_original - $total_optimized ) / $total_original ) * 100, 2 )
            : 0.0;

        $output_format = ! empty( $result['output_path'] )
            ? pathinfo( $result['output_path'], PATHINFO_EXTENSION )
            : pathinfo( $file_path, PATHINFO_EXTENSION );

        $data = [
            'success'         => true,
            'original_size'   => $total_original,
            'optimized_size'  => $total_optimized,
            'savings_percent' => $savings_percent,
            'format'          => $output_format,
            'sizes_optimized' => $sizes_optimized,
            'companions'      => $companions,
            'width'           => $result['width'],
            'height'          => $result['height'],
            'optimized_at'    => current_time( 'mysql' ),
        ];

        update_post_meta( $attachment_id, '_mpio_data', $data );
        $this->store_status( $attachment_id, 'optimized' );

        /**
         * Fires after an image is successfully optimized.
         *
         * @param int   $attachment_id The attachment ID.
         * @param array $data          Optimization result data.
         */
        do_action( 'mpio_after_optimize', $attachment_id, $data );

        return $data;
    }

    /**
     * Generate companion WebP and/or AVIF versions of an image and its thumbnails.
     *
     * Creates files like photo.jpg.webp and photo.jpg.avif alongside the original,
     * so the content rewriter and server rewrite rules can find and serve them.
     *
     * @param string $file_path     Path to the main image file.
     * @param int    $attachment_id Attachment post ID.
     * @param array  $args          Optional overrides (quality).
     * @return array List of generated companion files.
     */
    private function generate_companion_formats( string $file_path, int $attachment_id, array $args = [] ): array {
        $companions = [];
        $quality    = $args['quality'] ?? (int) mpio_get_setting( 'quality', 80 );
        $gen_webp   = mpio_get_setting( 'convert_to_webp', true );
        $gen_avif   = mpio_get_setting( 'convert_to_avif', false );

        if ( ! $gen_webp && ! $gen_avif ) {
            return $companions;
        }

        // Log format support for debugging.
        if ( $gen_webp && ! $this->supports_format( 'image/webp' ) ) {
            mpio_log( 'WebP companion skipped: engine does not support image/webp', 'info', [ 'engine' => $this->engine ] );
        }
        if ( $gen_avif && ! $this->supports_format( 'image/avif' ) ) {
            mpio_log( 'AVIF companion skipped: engine does not support image/avif', 'info', [ 'engine' => $this->engine ] );
        }
        // Collect all image paths: main + thumbnails.
        $all_paths = [ $file_path ];

        $metadata = wp_get_attachment_metadata( $attachment_id );
        if ( ! empty( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ) {
            $upload_dir = dirname( $file_path );
            foreach ( $metadata['sizes'] as $size_data ) {
                $thumb_path = trailingslashit( $upload_dir ) . $size_data['file'];
                if ( file_exists( $thumb_path ) ) {
                    $all_paths[] = $thumb_path;
                }
            }
        }

        mpio_log( 'Companion generation started', 'info', [ 'file' => $file_path, 'paths_count' => count( $all_paths ), 'gen_webp' => $gen_webp, 'gen_avif' => $gen_avif, 'webp_supported' => $this->supports_format( 'image/webp' ) ] );

        // Generate companion files for each path.
        foreach ( $all_paths as $path ) {
            $ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

            // Skip if already a next-gen format.
            if ( in_array( $ext, [ 'webp', 'avif' ], true ) ) {
                continue;
            }

            if ( $gen_webp && $this->supports_format( 'image/webp' ) ) {
                $webp_path_alt = preg_replace( '/\.[^.]+$/', '.webp', $path );

                if ( file_exists( $webp_path_alt ) ) {
                    mpio_log( 'WebP already exists, skipping', 'info', [ 'path' => $webp_path_alt ] );
                } else {
                    $result = $this->convert_format( $path, 'webp', $quality );
                    if ( $result ) {
                        $companions[] = [
                            'format' => 'webp',
                            'path'   => $result,
                            'size'   => filesize( $result ),
                        ];
                        mpio_log( 'WebP companion created', 'info', [ 'path' => $result, 'size' => filesize( $result ) ] );
                    } else {
                        mpio_log( 'WebP companion FAILED to convert', 'error', [ 'source' => $path ] );
                    }
                }
            }

            if ( $gen_avif && $this->supports_format( 'image/avif' ) ) {
                $avif_path_alt = preg_replace( '/\.[^.]+$/', '.avif', $path );

                if ( ! file_exists( $avif_path_alt ) ) {
                    $result = $this->convert_format( $path, 'avif', $quality );
                    if ( $result ) {
                        $companions[] = [
                            'format' => 'avif',
                            'path'   => $result,
                            'size'   => filesize( $result ),
                        ];
                    }
                }
            }
        }

        // Store companion paths in meta for cleanup on restore/delete.
        if ( ! empty( $companions ) ) {
            $existing = get_post_meta( $attachment_id, '_mpio_companions', true );
            if ( ! is_array( $existing ) ) {
                $existing = [];
            }
            $all_companion_paths = array_merge(
                $existing,
                array_column( $companions, 'path' )
            );
            update_post_meta( $attachment_id, '_mpio_companions', array_unique( $all_companion_paths ) );
        }

        return $companions;
    }

    /**
     * Optimize a single image file on disk.
     *
     * @param string $file_path Absolute path to the image file.
     * @param array  $args      Optional overrides (quality, output_format, resize, watermark).
     * @return array {
     *     @type bool   $success
     *     @type int    $original_size
     *     @type int    $optimized_size
     *     @type string $output_path
     *     @type int    $width
     *     @type int    $height
     * }
     */
    public function optimize_file( string $file_path, array $args = [] ): array {
        $original_size = filesize( $file_path );
        $default_result = [
            'success'        => false,
            'original_size'  => $original_size,
            'optimized_size' => $original_size,
            'output_path'    => $file_path,
            'width'          => 0,
            'height'         => 0,
        ];

        // Resolve settings with argument overrides.
        $quality       = isset( $args['quality'] )       ? (int) $args['quality']     : (int) mpio_get_setting( 'quality', 80 );
        $output_format = isset( $args['output_format'] ) ? $args['output_format']     : mpio_get_setting( 'output_format', 'original' );
        $strip_exif    = (bool) mpio_get_setting( 'strip_exif', true );

        // 'original' means keep the current format — don't convert.
        if ( 'original' === $output_format ) {
            $output_format = '';
        }

        $resize = isset( $args['resize'] ) ? $args['resize'] : [];
        if ( empty( $resize ) && mpio_get_setting( 'resize_enabled', false ) ) {
            $max_w = (int) mpio_get_setting( 'resize_max_width', 2560 );
            $max_h = (int) mpio_get_setting( 'resize_max_height', 2560 );
            if ( $max_w || $max_h ) {
                $resize = [
                    'max_width'  => $max_w,
                    'max_height' => $max_h,
                ];
            }
        }

        $watermark = isset( $args['watermark'] ) ? $args['watermark'] : [];
        if ( empty( $watermark ) && mpio_get_setting( 'watermark_enabled', false ) ) {
            $watermark = [
                'text'     => mpio_get_setting( 'watermark_text', '' ),
                'position' => mpio_get_setting( 'watermark_position', 'bottom-right' ),
                'opacity'  => (int) mpio_get_setting( 'watermark_opacity', 40 ),
                'size'     => (int) mpio_get_setting( 'watermark_size', 16 ),
            ];
        }

        // Load the image.
        $image = $this->get_image_editor( $file_path );
        if ( false === $image ) {
            return $default_result;
        }

        // Retrieve current dimensions.
        list( $width, $height ) = $this->get_dimensions( $image );

        // Resize if needed.
        if ( ! empty( $resize ) ) {
            $max_width  = isset( $resize['max_width'] )  ? (int) $resize['max_width']  : 0;
            $max_height = isset( $resize['max_height'] ) ? (int) $resize['max_height'] : 0;

            if ( $max_width || $max_height ) {
                $image = $this->resize_image( $image, $max_width, $max_height );
                list( $width, $height ) = $this->get_dimensions( $image );
            }
        }

        // Apply watermark if configured.
        if ( ! empty( $watermark ) && ! empty( $watermark['text'] ) ) {
            $image = $this->apply_watermark(
                $image,
                $watermark['text'],
                isset( $watermark['position'] ) ? $watermark['position'] : 'bottom-right',
                isset( $watermark['opacity'] )  ? (int) $watermark['opacity']  : 50,
                isset( $watermark['size'] )      ? (int) $watermark['size']      : 16
            );
        }

        // Determine output path and format.
        $target_format = $output_format;
        $output_path   = $file_path;

        if ( $target_format && $target_format !== pathinfo( $file_path, PATHINFO_EXTENSION ) ) {
            $output_path = preg_replace( '/\.[^.]+$/', '.' . $target_format, $file_path );
        }

        // Encode and save.
        $saved = $this->save_image( $image, $output_path, $target_format, $quality, $strip_exif );
        $this->destroy_image( $image );

        if ( ! $saved ) {
            return $default_result;
        }

        $optimized_size = filesize( $output_path );

        // If the optimized file is larger than the original, revert.
        if ( $optimized_size >= $original_size ) {
            // If a format conversion created a new file, remove it.
            if ( $output_path !== $file_path && file_exists( $output_path ) ) {
                wp_delete_file( $output_path );
            }

            return [
                'success'        => true,
                'original_size'  => $original_size,
                'optimized_size' => $original_size,
                'output_path'    => $file_path,
                'width'          => $width,
                'height'         => $height,
            ];
        }

        return [
            'success'        => true,
            'original_size'  => $original_size,
            'optimized_size' => $optimized_size,
            'output_path'    => $output_path,
            'width'          => $width,
            'height'         => $height,
        ];
    }

    /**
     * Resize an image resource while maintaining aspect ratio by default.
     *
     * @param resource|\Imagick $image            GD resource or Imagick instance.
     * @param int               $max_width        Maximum width (0 = unconstrained).
     * @param int               $max_height       Maximum height (0 = unconstrained).
     * @param bool              $maintain_aspect   Whether to maintain the aspect ratio.
     * @return resource|\Imagick The resized image.
     */
    public function resize_image( $image, int $max_width, int $max_height, bool $maintain_aspect = true ) {
        list( $orig_w, $orig_h ) = $this->get_dimensions( $image );

        if ( ! $max_width && ! $max_height ) {
            return $image;
        }

        $new_w = $max_width  ?: $orig_w;
        $new_h = $max_height ?: $orig_h;

        if ( $maintain_aspect ) {
            $ratio_w = $max_width  ? $max_width / $orig_w   : PHP_INT_MAX;
            $ratio_h = $max_height ? $max_height / $orig_h  : PHP_INT_MAX;
            $ratio   = min( $ratio_w, $ratio_h );

            // Only downscale, never upscale.
            if ( $ratio >= 1 ) {
                return $image;
            }

            $new_w = (int) round( $orig_w * $ratio );
            $new_h = (int) round( $orig_h * $ratio );
        }

        if ( 'imagick' === $this->engine && $image instanceof \Imagick ) {
            $image->resizeImage( $new_w, $new_h, \Imagick::FILTER_LANCZOS, 1 );
            return $image;
        }

        // GD path.
        $resized = imagecreatetruecolor( $new_w, $new_h );

        // Preserve transparency for PNG/WebP/AVIF.
        imagealphablending( $resized, false );
        imagesavealpha( $resized, true );

        imagecopyresampled( $resized, $image, 0, 0, 0, 0, $new_w, $new_h, $orig_w, $orig_h );
        imagedestroy( $image );

        return $resized;
    }

    /**
     * Apply a text watermark to the image.
     *
     * @param resource|\Imagick $image    GD resource or Imagick instance.
     * @param string            $text     Watermark text.
     * @param string            $position Position: top-left, top-right, center, bottom-left, bottom-right.
     * @param int               $opacity  Opacity 0-100.
     * @param int               $size     Font size in points.
     * @return resource|\Imagick The watermarked image.
     */
    public function apply_watermark( $image, string $text, string $position, int $opacity, int $size ) {
        if ( empty( $text ) ) {
            return $image;
        }

        if ( 'imagick' === $this->engine && $image instanceof \Imagick ) {
            return $this->apply_watermark_imagick( $image, $text, $position, $opacity, $size );
        }

        return $this->apply_watermark_gd( $image, $text, $position, $opacity, $size );
    }

    /**
     * Convert an image file to a target format.
     *
     * @param string $file_path     Absolute path to the source image.
     * @param string $target_format Target format extension: jpg, png, webp, avif, gif.
     * @param int    $quality       Encoding quality 1-100.
     * @return string|false New file path on success, false on failure.
     */
    public function convert_format( string $file_path, string $target_format, int $quality ) {
        $target_mime = $this->extension_to_mime( $target_format );
        if ( ! $target_mime || ! $this->supports_format( $target_mime ) ) {
            return false;
        }

        $image = $this->get_image_editor( $file_path );
        if ( false === $image ) {
            return false;
        }

        $output_path = preg_replace( '/\.[^.]+$/', '.' . $target_format, $file_path );
        $saved = $this->save_image( $image, $output_path, $target_format, $quality, false );
        $this->destroy_image( $image );

        return $saved ? $output_path : false;
    }

    /**
     * Retrieve stored optimization data for an attachment.
     *
     * @param int $attachment_id Attachment post ID.
     * @return array|null Optimization data or null if not found.
     */
    public function get_optimization_data( int $attachment_id ): ?array {
        $data = get_post_meta( $attachment_id, '_mpio_data', true );
        return is_array( $data ) ? $data : null;
    }

    /**
     * Check whether an attachment has already been optimized.
     *
     * @param int $attachment_id Attachment post ID.
     * @return bool
     */
    public function is_optimized( int $attachment_id ): bool {
        return 'optimized' === get_post_meta( $attachment_id, '_mpio_status', true );
    }

    // =========================================================================
    // Image Editor Helpers
    // =========================================================================

    /**
     * Load an image file and return a GD resource or Imagick instance.
     *
     * @param string $file_path Absolute path to the image.
     * @return resource|\Imagick|false Image resource or false on failure.
     */
    public function get_image_editor( string $file_path ) {
        if ( ! file_exists( $file_path ) ) {
            return false;
        }

        if ( 'imagick' === $this->engine ) {
            return $this->load_imagick( $file_path );
        }

        return $this->load_gd( $file_path );
    }

    /**
     * Destroy/free an image resource.
     *
     * @param resource|\Imagick|null $image The image to destroy.
     */
    public function destroy_image( $image ): void {
        if ( null === $image ) {
            return;
        }

        if ( $image instanceof \Imagick ) {
            $image->clear();
            $image->destroy();
            return;
        }

        if ( is_resource( $image ) || $image instanceof \GdImage ) {
            imagedestroy( $image );
        }
    }

    /**
     * Check whether the current engine supports a given MIME type.
     *
     * @param string $mime MIME type, e.g. 'image/webp'.
     * @return bool
     */
    public function supports_format( string $mime ): bool {
        $supported = $this->get_supported_formats();
        return in_array( $mime, $supported, true );
    }

    /**
     * Get an array of MIME types supported by the current engine.
     *
     * @return string[]
     */
    public function get_supported_formats(): array {
        if ( 'imagick' === $this->engine ) {
            return $this->get_imagick_supported_formats();
        }

        return $this->get_gd_supported_formats();
    }

    // =========================================================================
    // Private: GD Loading & Saving
    // =========================================================================

    /**
     * Load an image via GD.
     *
     * @param string $file_path Absolute path to the image.
     * @return resource|false GD image resource or false.
     */
    private function load_gd( string $file_path ) {
        $mime = $this->get_mime_type( $file_path );

        switch ( $mime ) {
            case 'image/jpeg':
                return @imagecreatefromjpeg( $file_path );

            case 'image/png':
                $img = @imagecreatefrompng( $file_path );
                if ( $img ) {
                    imagealphablending( $img, true );
                    imagesavealpha( $img, true );
                }
                return $img;

            case 'image/gif':
                return @imagecreatefromgif( $file_path );

            case 'image/webp':
                if ( function_exists( 'imagecreatefromwebp' ) ) {
                    return @imagecreatefromwebp( $file_path );
                }
                return false;

            case 'image/avif':
                if ( function_exists( 'imagecreatefromavif' ) ) {
                    return @imagecreatefromavif( $file_path );
                }
                return false;

            default:
                return false;
        }
    }

    /**
     * Load an image via Imagick.
     *
     * @param string $file_path Absolute path to the image.
     * @return \Imagick|false
     */
    private function load_imagick( string $file_path ) {
        try {
            $imagick = new \Imagick();
            $imagick->readImage( $file_path );
            return $imagick;
        } catch ( \ImagickException $e ) {
            return false;
        }
    }

    /**
     * Save an image to disk.
     *
     * @param resource|\Imagick $image       The image to save.
     * @param string            $output_path Target file path.
     * @param string            $format      Target extension (jpg, png, webp, avif, gif) or empty for original.
     * @param int               $quality     Encoding quality.
     * @param bool              $strip_exif  Whether to strip EXIF metadata.
     * @return bool True on success.
     */
    private function save_image( $image, string $output_path, string $format, int $quality, bool $strip_exif ): bool {
        if ( 'imagick' === $this->engine && $image instanceof \Imagick ) {
            return $this->save_imagick( $image, $output_path, $format, $quality, $strip_exif );
        }

        return $this->save_gd( $image, $output_path, $format, $quality );
    }

    /**
     * Save via GD. Recreating the image already strips EXIF by default.
     *
     * @param resource $image       GD image resource.
     * @param string   $output_path Target file path.
     * @param string   $format      Target extension or empty.
     * @param int      $quality     Encoding quality.
     * @return bool
     */
    private function save_gd( $image, string $output_path, string $format, int $quality ): bool {
        if ( empty( $format ) ) {
            $format = pathinfo( $output_path, PATHINFO_EXTENSION );
        }

        $format = strtolower( $format );

        switch ( $format ) {
            case 'jpg':
            case 'jpeg':
                return imagejpeg( $image, $output_path, $quality );

            case 'png':
                // PNG compression: 0 (none) to 9 (max). Map quality 1-100 to 9-0.
                $compression = (int) round( ( 100 - $quality ) * 9 / 100 );
                return imagepng( $image, $output_path, $compression );

            case 'gif':
                return imagegif( $image, $output_path );

            case 'webp':
                if ( function_exists( 'imagewebp' ) ) {
                    return imagewebp( $image, $output_path, $quality );
                }
                return false;

            case 'avif':
                if ( function_exists( 'imageavif' ) ) {
                    return imageavif( $image, $output_path, $quality );
                }
                return false;

            default:
                return false;
        }
    }

    /**
     * Save via Imagick.
     *
     * @param \Imagick $image       Imagick instance.
     * @param string   $output_path Target file path.
     * @param string   $format      Target extension or empty.
     * @param int      $quality     Encoding quality.
     * @param bool     $strip_exif  Whether to strip EXIF.
     * @return bool
     */
    private function save_imagick( \Imagick $image, string $output_path, string $format, int $quality, bool $strip_exif ): bool {
        try {
            if ( $strip_exif ) {
                $image->stripImage();
            }

            if ( ! empty( $format ) ) {
                $imagick_format = $this->extension_to_imagick_format( $format );
                if ( $imagick_format ) {
                    $image->setImageFormat( $imagick_format );
                }
            }

            $image->setImageCompressionQuality( $quality );
            $image->writeImage( $output_path );

            return true;
        } catch ( \ImagickException $e ) {
            return false;
        }
    }

    // =========================================================================
    // Private: Watermark Helpers
    // =========================================================================

    /**
     * Apply text watermark using GD.
     *
     * @param resource $image    GD image resource.
     * @param string   $text     Watermark text.
     * @param string   $position Position identifier.
     * @param int      $opacity  Opacity 0-100.
     * @param int      $size     Font size.
     * @return resource The watermarked GD image.
     */
    private function apply_watermark_gd( $image, string $text, string $position, int $opacity, int $size ) {
        $img_w = imagesx( $image );
        $img_h = imagesy( $image );

        // Convert opacity 0-100 to alpha 0-127 (127 = fully transparent).
        $alpha = (int) round( 127 - ( $opacity / 100 * 127 ) );
        $color = imagecolorallocatealpha( $image, 255, 255, 255, $alpha );

        // Estimate text dimensions using built-in font.
        $font_width  = imagefontwidth( 5 );
        $font_height = imagefontheight( 5 );
        $text_width  = $font_width * strlen( $text );
        $text_height = $font_height;

        $padding = 10;
        list( $x, $y ) = $this->calculate_position(
            $position,
            $img_w,
            $img_h,
            $text_width,
            $text_height,
            $padding
        );

        imagestring( $image, 5, $x, $y, $text, $color );

        return $image;
    }

    /**
     * Apply text watermark using Imagick.
     *
     * @param \Imagick $image    Imagick instance.
     * @param string   $text     Watermark text.
     * @param string   $position Position identifier.
     * @param int      $opacity  Opacity 0-100.
     * @param int      $size     Font size.
     * @return \Imagick The watermarked Imagick instance.
     */
    private function apply_watermark_imagick( \Imagick $image, string $text, string $position, int $opacity, int $size ): \Imagick {
        try {
            $draw = new \ImagickDraw();
            $draw->setFontSize( $size );
            $draw->setFillColor( new \ImagickPixel( 'white' ) );
            $draw->setFillOpacity( $opacity / 100 );

            // Query text metrics to calculate positioning.
            $metrics    = $image->queryFontMetrics( $draw, $text );
            $text_width = (int) $metrics['textWidth'];
            $text_height = (int) $metrics['textHeight'];

            $img_w = $image->getImageWidth();
            $img_h = $image->getImageHeight();

            $padding = 10;
            list( $x, $y ) = $this->calculate_position(
                $position,
                $img_w,
                $img_h,
                $text_width,
                $text_height,
                $padding
            );

            $image->annotateImage( $draw, $x, $y + $text_height, 0, $text );
        } catch ( \ImagickException $e ) {
            // Silently fail; return image without watermark.
        }

        return $image;
    }

    /**
     * Calculate x, y coordinates for watermark placement.
     *
     * @param string $position    Position key.
     * @param int    $img_w       Image width.
     * @param int    $img_h       Image height.
     * @param int    $text_width  Text bounding box width.
     * @param int    $text_height Text bounding box height.
     * @param int    $padding     Padding from edges.
     * @return int[] [ x, y ]
     */
    private function calculate_position( string $position, int $img_w, int $img_h, int $text_width, int $text_height, int $padding ): array {
        switch ( $position ) {
            case 'top-left':
                return [ $padding, $padding ];

            case 'top-right':
                return [ $img_w - $text_width - $padding, $padding ];

            case 'center':
                return [
                    (int) ( ( $img_w - $text_width ) / 2 ),
                    (int) ( ( $img_h - $text_height ) / 2 ),
                ];

            case 'bottom-left':
                return [ $padding, $img_h - $text_height - $padding ];

            case 'bottom-right':
            default:
                return [ $img_w - $text_width - $padding, $img_h - $text_height - $padding ];
        }
    }

    // =========================================================================
    // Private: Format Support
    // =========================================================================

    /**
     * Get MIME types supported by GD.
     *
     * @return string[]
     */
    private function get_gd_supported_formats(): array {
        $formats = [
            'image/jpeg',
            'image/png',
            'image/gif',
        ];

        if ( function_exists( 'imagewebp' ) ) {
            $formats[] = 'image/webp';
        }

        if ( function_exists( 'imageavif' ) ) {
            $formats[] = 'image/avif';
        }

        return $formats;
    }

    /**
     * Get MIME types supported by Imagick.
     *
     * @return string[]
     */
    private function get_imagick_supported_formats(): array {
        if ( ! class_exists( '\\Imagick' ) ) {
            return [];
        }

        $map = [
            'JPEG' => 'image/jpeg',
            'PNG'  => 'image/png',
            'GIF'  => 'image/gif',
            'WEBP' => 'image/webp',
            'AVIF' => 'image/avif',
        ];

        $available = \Imagick::queryFormats();
        $supported = [];

        foreach ( $map as $imagick_name => $mime ) {
            if ( in_array( $imagick_name, $available, true ) ) {
                $supported[] = $mime;
            }
        }

        return $supported;
    }

    // =========================================================================
    // Private: Utility Helpers
    // =========================================================================

    /**
     * Get the dimensions of a GD resource or Imagick instance.
     *
     * @param resource|\Imagick $image Image.
     * @return int[] [ width, height ]
     */
    private function get_dimensions( $image ): array {
        if ( $image instanceof \Imagick ) {
            return [
                $image->getImageWidth(),
                $image->getImageHeight(),
            ];
        }

        return [
            imagesx( $image ),
            imagesy( $image ),
        ];
    }

    /**
     * Detect the MIME type of a file.
     *
     * @param string $file_path Absolute path.
     * @return string MIME type string.
     */
    private function get_mime_type( string $file_path ): string {
        if ( function_exists( 'wp_get_image_mime' ) ) {
            return (string) wp_get_image_mime( $file_path );
        }

        $info = @getimagesize( $file_path );
        return $info ? $info['mime'] : '';
    }

    /**
     * Map a file extension to a MIME type.
     *
     * @param string $ext File extension (no dot).
     * @return string MIME type or empty string.
     */
    private function extension_to_mime( string $ext ): string {
        $map = [
            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png'  => 'image/png',
            'gif'  => 'image/gif',
            'webp' => 'image/webp',
            'avif' => 'image/avif',
        ];

        return $map[ strtolower( $ext ) ] ?? '';
    }

    /**
     * Map a file extension to an Imagick format string.
     *
     * @param string $ext File extension.
     * @return string Imagick format name or empty string.
     */
    private function extension_to_imagick_format( string $ext ): string {
        $map = [
            'jpg'  => 'JPEG',
            'jpeg' => 'JPEG',
            'png'  => 'PNG',
            'gif'  => 'GIF',
            'webp' => 'WEBP',
            'avif' => 'AVIF',
        ];

        return $map[ strtolower( $ext ) ] ?? '';
    }

    /**
     * Store the optimization status for an attachment.
     *
     * @param int    $attachment_id Attachment post ID.
     * @param string $status        One of: optimized, error, skipped.
     */
    private function store_status( int $attachment_id, string $status ): void {
        update_post_meta( $attachment_id, '_mpio_status', $status );
    }
}
