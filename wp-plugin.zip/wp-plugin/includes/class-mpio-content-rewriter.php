<?php
/**
 * Content rewriter for Mpire Image Optimizer.
 *
 * Rewrites <img> tags in page content to <picture> elements with
 * WebP/AVIF <source> tags, and filters WordPress core image functions
 * to output modern formats automatically.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

class MPIO_Content_Rewriter {

    private static ?MPIO_Content_Rewriter $instance = null;

    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Don't run in admin or during AJAX/REST/cron.
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || defined( 'REST_REQUEST' ) ) {
            return;
        }

        $display_mode = mpio_get_setting( 'display_mode', 'picture' );

        mpio_log( 'Content rewriter init', 'info', [
            'display_mode' => $display_mode,
            'is_admin'     => is_admin(),
        ] );

        if ( 'none' === $display_mode ) {
            return;
        }

        if ( 'picture' === $display_mode || 'both' === $display_mode ) {
            // Rewrite <img> to <picture> in post content.
            add_filter( 'the_content', [ $this, 'rewrite_content' ], 999 );

            // Rewrite widget text.
            add_filter( 'widget_text', [ $this, 'rewrite_content' ], 999 );

            // Rewrite post excerpts with images.
            add_filter( 'the_excerpt', [ $this, 'rewrite_content' ], 999 );

            // Filter core wp_get_attachment_image to add <picture> wrapper.
            add_filter( 'wp_get_attachment_image', [ $this, 'rewrite_attachment_image' ], 999, 5 );

            // Filter wp_content_img_tag (WP 6.0+) for individual img tags.
            add_filter( 'wp_content_img_tag', [ $this, 'rewrite_single_img_tag' ], 999, 3 );

            // Rewrite post thumbnails output by themes.
            add_filter( 'post_thumbnail_html', [ $this, 'rewrite_content' ], 999 );

            // Output buffer fallback: catch ALL img tags in the full HTML output.
            // Hook early to run before WP Engine's caching captures the output.
            add_action( 'template_redirect', [ $this, 'start_output_buffer' ], 0 );
        }
    }

    /**
     * Start output buffering to catch all img tags in the full page HTML.
     */
    public function start_output_buffer(): void {
        ob_start( [ $this, 'process_output_buffer' ] );
    }

    /**
     * Process the full page HTML output buffer and rewrite img tags.
     */
    public function process_output_buffer( string $html ): string {
        if ( empty( $html ) ) {
            return $html;
        }

        // Only process HTML responses.
        if ( strpos( $html, '<html' ) === false && strpos( $html, '<!DOCTYPE' ) === false ) {
            return $html;
        }

        $html = $this->rewrite_content( $html );

        // Add marker so we can verify the rewriter ran.
        $html = str_replace( '</body>', '<!-- MPIO Content Rewriter active --></body>', $html );

        return $html;
    }

    /**
     * Rewrite all <img> tags in content to <picture> elements.
     */
    public function rewrite_content( string $content ): string {
        if ( empty( $content ) ) {
            return $content;
        }

        // Match all <img> tags.
        if ( ! preg_match_all( '/<img\s[^>]+>/i', $content, $matches ) ) {
            return $content;
        }

        foreach ( $matches[0] as $img_tag ) {
            $picture_tag = $this->convert_img_to_picture( $img_tag );
            if ( $picture_tag !== $img_tag ) {
                $content = str_replace( $img_tag, $picture_tag, $content );
            }
        }

        return $content;
    }

    /**
     * Filter wp_get_attachment_image output.
     */
    public function rewrite_attachment_image( string $html, int $attachment_id, $size, bool $icon, array $attr ): string {
        if ( empty( $html ) || ! preg_match( '/<img\s/i', $html ) ) {
            return $html;
        }

        // Don't double-wrap if already in a <picture>.
        if ( stripos( $html, '<picture' ) !== false ) {
            return $html;
        }

        return $this->convert_img_to_picture( $html );
    }

    /**
     * Filter individual img tags via wp_content_img_tag (WP 6.0+).
     */
    public function rewrite_single_img_tag( string $filtered_image, string $context, int $attachment_id ): string {
        // Don't wrap if already in a <picture>.
        if ( stripos( $filtered_image, '<picture' ) !== false ) {
            return $filtered_image;
        }

        return $this->convert_img_to_picture( $filtered_image );
    }

    /**
     * Check if an image is excluded by attachment ID from its wp-image-{id} class.
     */
    private function is_excluded_image( string $img_tag, string $src = '' ): bool {
        $attachment_id = 0;
        if ( preg_match( '/\bwp-image-(\d+)\b/', $img_tag, $match ) ) {
            $attachment_id = (int) $match[1];
        }

        // Use the full exclusion check (per-image meta + pattern matching) when possible.
        if ( function_exists( 'mpio_is_excluded' ) ) {
            $file_path = '';
            if ( $attachment_id > 0 ) {
                $file_path = get_attached_file( $attachment_id );
            }
            if ( ! $file_path && $src ) {
                // Convert URL to file path for pattern matching.
                $upload_dir = wp_upload_dir();
                $file_path  = str_replace( $upload_dir['baseurl'], $upload_dir['basedir'], $src );
            }
            if ( $file_path && mpio_is_excluded( $file_path, $attachment_id ) ) {
                return true;
            }
        } elseif ( $attachment_id > 0 && get_post_meta( $attachment_id, '_mpio_excluded', true ) ) {
            return true;
        }

        return false;
    }

    /**
     * Convert a single <img> tag to a <picture> element with WebP/AVIF sources.
     */
    private function convert_img_to_picture( string $img_tag ): string {
        // Extract src attribute.
        if ( ! preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $img_tag, $src_match ) ) {
            return $img_tag;
        }

        $original_src = $src_match[1];

        // Only process local images.
        $upload_dir = wp_upload_dir();
        $upload_url = $upload_dir['baseurl'];

        if ( strpos( $original_src, $upload_url ) === false && strpos( $original_src, '/wp-content/' ) === false ) {
            return $img_tag;
        }

        // Skip if already a WebP or AVIF.
        $ext = strtolower( pathinfo( wp_parse_url( $original_src, PHP_URL_PATH ) ?? '', PATHINFO_EXTENSION ) );
        if ( in_array( $ext, [ 'webp', 'avif' ], true ) ) {
            return $img_tag;
        }

        // Skip if this image is excluded (per-image meta or pattern match).
        if ( $this->is_excluded_image( $img_tag, $original_src ) ) {
            return $img_tag;
        }

        // Find available converted versions.
        $sources = $this->find_converted_sources( $original_src );

        if ( empty( $sources ) ) {
            return $img_tag;
        }

        // Extract srcset if present.
        $srcset_sources = [];
        if ( preg_match( '/\bsrcset=["\']([^"\']+)["\']/i', $img_tag, $srcset_match ) ) {
            $srcset_sources = $this->build_srcset_sources( $srcset_match[1] );
        }

        // Build <picture> element.
        $picture = '<picture>';

        // AVIF source (highest priority — smallest).
        if ( ! empty( $sources['avif'] ) ) {
            $picture .= '<source type="image/avif"';
            if ( ! empty( $srcset_sources['avif'] ) ) {
                $picture .= ' srcset="' . esc_attr( $srcset_sources['avif'] ) . '"';
            } else {
                $picture .= ' srcset="' . esc_attr( $sources['avif'] ) . '"';
            }
            $picture .= $this->extract_sizes_attr( $img_tag );
            $picture .= '>';
        }

        // WebP source.
        if ( ! empty( $sources['webp'] ) ) {
            $picture .= '<source type="image/webp"';
            if ( ! empty( $srcset_sources['webp'] ) ) {
                $picture .= ' srcset="' . esc_attr( $srcset_sources['webp'] ) . '"';
            } else {
                $picture .= ' srcset="' . esc_attr( $sources['webp'] ) . '"';
            }
            $picture .= $this->extract_sizes_attr( $img_tag );
            $picture .= '>';
        }

        // Ensure lazy loading and async decoding on the fallback <img>.
        $img_tag = $this->ensure_lazy_loading( $img_tag );

        // Original <img> as fallback.
        $picture .= $img_tag;
        $picture .= '</picture>';

        return $picture;
    }

    /**
     * Find converted WebP/AVIF versions of an image URL.
     */
    private function find_converted_sources( string $original_url ): array {
        $sources   = [];
        $file_path = $this->url_to_path( $original_url );

        if ( ! $file_path || ! file_exists( $file_path ) ) {
            return $sources;
        }

        $path_no_ext = preg_replace( '/\.[^.]+$/', '', $file_path );
        $url_no_ext  = preg_replace( '/\.[^.]+$/', '', $original_url );

        // Check for WebP version.
        // Convention 1: same name with .webp extension (e.g., photo.webp).
        // Convention 2: appended .webp (e.g., photo.jpg.webp).
        if ( mpio_get_setting( 'convert_to_webp', true ) ) {
            if ( file_exists( $path_no_ext . '.webp' ) ) {
                $sources['webp'] = $url_no_ext . '.webp';
            } elseif ( file_exists( $file_path . '.webp' ) ) {
                $sources['webp'] = $original_url . '.webp';
            }
        }

        // Check for AVIF version.
        if ( mpio_get_setting( 'convert_to_avif', false ) ) {
            if ( file_exists( $path_no_ext . '.avif' ) ) {
                $sources['avif'] = $url_no_ext . '.avif';
            } elseif ( file_exists( $file_path . '.avif' ) ) {
                $sources['avif'] = $original_url . '.avif';
            }
        }

        return $sources;
    }

    /**
     * Build converted srcset values from an original srcset string.
     *
     * Takes "image-300x200.jpg 300w, image-600x400.jpg 600w"
     * and produces WebP/AVIF equivalents for each entry.
     */
    private function build_srcset_sources( string $original_srcset ): array {
        $sources = [ 'webp' => [], 'avif' => [] ];
        $entries = array_map( 'trim', explode( ',', $original_srcset ) );

        foreach ( $entries as $entry ) {
            $parts = preg_split( '/\s+/', trim( $entry ) );
            if ( count( $parts ) < 2 ) {
                continue;
            }

            $url        = $parts[0];
            $descriptor = $parts[1]; // e.g., "300w" or "2x"

            $converted = $this->find_converted_sources( $url );

            if ( ! empty( $converted['webp'] ) ) {
                $sources['webp'][] = $converted['webp'] . ' ' . $descriptor;
            }
            if ( ! empty( $converted['avif'] ) ) {
                $sources['avif'][] = $converted['avif'] . ' ' . $descriptor;
            }
        }

        $result = [];
        if ( ! empty( $sources['webp'] ) ) {
            $result['webp'] = implode( ', ', $sources['webp'] );
        }
        if ( ! empty( $sources['avif'] ) ) {
            $result['avif'] = implode( ', ', $sources['avif'] );
        }

        return $result;
    }

    /**
     * Extract the sizes attribute from an <img> tag.
     */
    private function extract_sizes_attr( string $img_tag ): string {
        if ( preg_match( '/\bsizes=["\']([^"\']+)["\']/i', $img_tag, $match ) ) {
            return ' sizes="' . esc_attr( $match[1] ) . '"';
        }
        return '';
    }

    /**
     * Ensure an <img> tag has loading="lazy" and decoding="async" attributes.
     *
     * Preserves existing values. Does not add loading="lazy" to images that
     * explicitly have loading="eager" (e.g., above-the-fold LCP images).
     */
    private function ensure_lazy_loading( string $img_tag ): string {
        // Add decoding="async" if no decoding attribute present.
        if ( ! preg_match( '/\bdecoding\s*=/i', $img_tag ) ) {
            $img_tag = str_replace( '<img ', '<img decoding="async" ', $img_tag );
        }

        // Add loading="lazy" if no loading attribute present.
        // WordPress 5.5+ adds this natively, but it may be missing on older
        // content or manually inserted <img> tags.
        if ( ! preg_match( '/\bloading\s*=/i', $img_tag ) ) {
            $img_tag = str_replace( '<img ', '<img loading="lazy" ', $img_tag );
        }

        // Add fetchpriority="low" for lazy images to hint the browser.
        // Skip if fetchpriority is already set (e.g., "high" for LCP).
        if ( ! preg_match( '/\bfetchpriority\s*=/i', $img_tag ) ) {
            // Only add low priority if loading="lazy" (not eager).
            if ( preg_match( '/\bloading=["\']lazy["\']/i', $img_tag ) ) {
                $img_tag = str_replace( '<img ', '<img fetchpriority="low" ', $img_tag );
            }
        }

        return $img_tag;
    }

    /**
     * Convert a URL to a filesystem path.
     */
    private function url_to_path( string $url ): ?string {
        $upload_dir = wp_upload_dir();

        // Try upload directory mapping.
        if ( strpos( $url, $upload_dir['baseurl'] ) !== false ) {
            $relative = str_replace( $upload_dir['baseurl'], '', $url );
            $path     = $upload_dir['basedir'] . $relative;
            // Strip query strings.
            $path = preg_replace( '/\?.*$/', '', $path );
            return $path;
        }

        // Try ABSPATH mapping.
        $site_url = site_url();
        if ( strpos( $url, $site_url ) !== false ) {
            $relative = str_replace( $site_url, '', $url );
            $path     = ABSPATH . ltrim( $relative, '/' );
            $path     = preg_replace( '/\?.*$/', '', $path );
            return $path;
        }

        // Relative URL starting with /wp-content/.
        if ( strpos( $url, '/wp-content/' ) === 0 ) {
            $path = ABSPATH . ltrim( $url, '/' );
            $path = preg_replace( '/\?.*$/', '', $path );
            return $path;
        }

        return null;
    }
}
