<?php
/**
 * WP-CLI commands for Mpire Image Optimizer.
 *
 * Usage:
 *   wp mpio stats
 *   wp mpio optimize <id>
 *   wp mpio optimize --all
 *   wp mpio restore <id>
 *   wp mpio restore --all
 *   wp mpio bulk start
 *   wp mpio bulk stop
 *   wp mpio bulk status
 *   wp mpio engine
 *   wp mpio reset <id>
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

class MPIO_CLI {

    /**
     * Show optimization statistics.
     *
     * ## EXAMPLES
     *
     *     wp mpio stats
     *
     * @subcommand stats
     */
    public function stats( $args, $assoc_args ) {
        $stats = MPIO_Bulk_Optimizer::get_instance()->get_stats();

        $savings_pct = $stats['total_original_size'] > 0
            ? round( ( ( $stats['total_original_size'] - $stats['total_optimized_size'] ) / $stats['total_original_size'] ) * 100, 1 )
            : 0;

        WP_CLI::line( '' );
        WP_CLI::line( WP_CLI::colorize( '%BImage Optimization Statistics%n' ) );
        WP_CLI::line( str_repeat( '-', 40 ) );

        $table = [
            [ 'Metric', 'Value' ],
            [ 'Total Images', $stats['total_images'] ],
            [ 'Optimized', $stats['optimized'] ],
            [ 'Unoptimized', $stats['unoptimized'] ],
            [ 'Errors', $stats['errors'] ],
            [ 'Original Size', mpio_format_bytes( $stats['total_original_size'] ) ],
            [ 'Optimized Size', mpio_format_bytes( $stats['total_optimized_size'] ) ],
            [ 'Total Savings', mpio_format_bytes( $stats['total_original_size'] - $stats['total_optimized_size'] ) . " ({$savings_pct}%)" ],
            [ 'Engine', ucfirst( mpio_get_engine() ) ],
        ];

        $formatter = new \WP_CLI\Formatter( $assoc_args, [ 'Metric', 'Value' ] );
        WP_CLI\Utils\format_items( 'table', array_map( function ( $row ) {
            return [ 'Metric' => $row[0], 'Value' => $row[1] ];
        }, array_slice( $table, 1 ) ), [ 'Metric', 'Value' ] );

        // Backup stats.
        $backup_stats = MPIO_Backup::get_instance()->get_backup_stats();
        if ( $backup_stats['total_backups'] > 0 ) {
            WP_CLI::line( '' );
            WP_CLI::line( WP_CLI::colorize( '%BBackup Stats%n' ) );
            WP_CLI::line( "  Backups: {$backup_stats['total_backups']}" );
            WP_CLI::line( '  Size: ' . mpio_format_bytes( $backup_stats['total_size'] ) );
        }
    }

    /**
     * Optimize one or all images.
     *
     * ## OPTIONS
     *
     * [<id>]
     * : Attachment ID to optimize.
     *
     * [--all]
     * : Optimize all unoptimized images.
     *
     * [--force]
     * : Re-optimize already optimized images.
     *
     * [--quality=<quality>]
     * : Override quality (1-100).
     *
     * ## EXAMPLES
     *
     *     wp mpio optimize 123
     *     wp mpio optimize --all
     *     wp mpio optimize --all --quality=85
     *     wp mpio optimize 123 --force
     *
     * @subcommand optimize
     */
    public function optimize( $args, $assoc_args ) {
        $optimizer = MPIO_Optimizer::get_instance();
        $backup    = MPIO_Backup::get_instance();
        $all       = \WP_CLI\Utils\get_flag_value( $assoc_args, 'all', false );
        $force     = \WP_CLI\Utils\get_flag_value( $assoc_args, 'force', false );
        $quality   = isset( $assoc_args['quality'] ) ? (int) $assoc_args['quality'] : null;

        $opt_args = [];
        if ( $quality ) {
            $opt_args['quality'] = max( 1, min( 100, $quality ) );
        }

        if ( $all ) {
            $ids = $force
                ? $this->get_all_image_ids()
                : MPIO_Bulk_Optimizer::get_instance()->get_unoptimized_ids();

            if ( empty( $ids ) ) {
                WP_CLI::success( 'No images to optimize.' );
                return;
            }

            WP_CLI::line( sprintf( 'Optimizing %d images...', count( $ids ) ) );
            $progress = \WP_CLI\Utils\make_progress_bar( 'Optimizing', count( $ids ) );

            $success = 0;
            $errors  = 0;

            foreach ( $ids as $id ) {
                if ( mpio_get_setting( 'keep_backup', true ) ) {
                    $file_path = get_attached_file( $id );
                    if ( $file_path ) {
                        $backup->backup( $id, $file_path );
                    }
                }

                $result = $optimizer->optimize( $id, $opt_args );

                if ( $result['success'] ) {
                    $success++;
                } else {
                    $errors++;
                }

                $progress->tick();
            }

            $progress->finish();
            WP_CLI::success( sprintf( 'Done. %d optimized, %d errors.', $success, $errors ) );

        } elseif ( ! empty( $args[0] ) ) {
            $id = (int) $args[0];

            if ( ! get_post( $id ) || 'attachment' !== get_post_type( $id ) ) {
                WP_CLI::error( "Attachment #{$id} not found." );
            }

            if ( ! $force && $optimizer->is_optimized( $id ) ) {
                WP_CLI::warning( "Attachment #{$id} is already optimized. Use --force to re-optimize." );
                return;
            }

            if ( mpio_get_setting( 'keep_backup', true ) ) {
                $file_path = get_attached_file( $id );
                if ( $file_path ) {
                    $backup->backup( $id, $file_path );
                }
            }

            $result = $optimizer->optimize( $id, $opt_args );

            if ( $result['success'] ) {
                WP_CLI::success( sprintf(
                    'Optimized #%d: %s -> %s (-%s%%)',
                    $id,
                    mpio_format_bytes( $result['original_size'] ),
                    mpio_format_bytes( $result['optimized_size'] ),
                    $result['savings_percent']
                ) );
            } else {
                WP_CLI::error( "Failed to optimize #{$id}." );
            }
        } else {
            WP_CLI::error( 'Provide an attachment ID or use --all.' );
        }
    }

    /**
     * Restore one or all images from backup.
     *
     * ## OPTIONS
     *
     * [<id>]
     * : Attachment ID to restore.
     *
     * [--all]
     * : Restore all backed-up images.
     *
     * ## EXAMPLES
     *
     *     wp mpio restore 123
     *     wp mpio restore --all
     *
     * @subcommand restore
     */
    public function restore( $args, $assoc_args ) {
        $backup = MPIO_Backup::get_instance();
        $all    = \WP_CLI\Utils\get_flag_value( $assoc_args, 'all', false );

        if ( $all ) {
            global $wpdb;
            $ids = $wpdb->get_col(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_mpio_backup_path'"
            );

            if ( empty( $ids ) ) {
                WP_CLI::success( 'No backups to restore.' );
                return;
            }

            WP_CLI::confirm( sprintf( 'Restore %d images to originals?', count( $ids ) ) );

            $progress = \WP_CLI\Utils\make_progress_bar( 'Restoring', count( $ids ) );
            $success  = 0;

            foreach ( $ids as $id ) {
                if ( $backup->restore( (int) $id ) ) {
                    $success++;
                }
                $progress->tick();
            }

            $progress->finish();
            WP_CLI::success( sprintf( 'Restored %d images.', $success ) );

        } elseif ( ! empty( $args[0] ) ) {
            $id = (int) $args[0];

            if ( ! $backup->has_backup( $id ) ) {
                WP_CLI::error( "No backup found for attachment #{$id}." );
            }

            if ( $backup->restore( $id ) ) {
                WP_CLI::success( "Restored attachment #{$id}." );
            } else {
                WP_CLI::error( "Failed to restore #{$id}." );
            }
        } else {
            WP_CLI::error( 'Provide an attachment ID or use --all.' );
        }
    }

    /**
     * Manage bulk optimization.
     *
     * ## OPTIONS
     *
     * <action>
     * : One of: start, stop, status.
     *
     * ## EXAMPLES
     *
     *     wp mpio bulk start
     *     wp mpio bulk stop
     *     wp mpio bulk status
     *
     * @subcommand bulk
     */
    public function bulk( $args, $assoc_args ) {
        $action = $args[0] ?? '';
        $bulk   = MPIO_Bulk_Optimizer::get_instance();

        switch ( $action ) {
            case 'start':
                if ( $bulk->is_running() ) {
                    WP_CLI::warning( 'Bulk optimization is already running.' );
                    return;
                }

                $ids = $bulk->get_unoptimized_ids();
                if ( empty( $ids ) ) {
                    WP_CLI::success( 'No images to optimize.' );
                    return;
                }

                // For CLI, process directly instead of using cron.
                WP_CLI::line( sprintf( 'Processing %d images...', count( $ids ) ) );
                $progress = \WP_CLI\Utils\make_progress_bar( 'Bulk optimizing', count( $ids ) );

                $optimizer = MPIO_Optimizer::get_instance();
                $backup    = MPIO_Backup::get_instance();
                $success   = 0;
                $errors    = 0;

                foreach ( $ids as $id ) {
                    if ( mpio_get_setting( 'keep_backup', true ) ) {
                        $file_path = get_attached_file( $id );
                        if ( $file_path ) {
                            $backup->backup( $id, $file_path );
                        }
                    }

                    $result = $optimizer->optimize( $id );
                    if ( $result['success'] ) {
                        $success++;
                    } else {
                        $errors++;
                    }

                    $progress->tick();
                }

                $progress->finish();
                WP_CLI::success( sprintf( 'Bulk complete. %d optimized, %d errors.', $success, $errors ) );
                break;

            case 'stop':
                // Clear cron-based bulk if running.
                delete_transient( 'mpio_bulk_queue' );
                delete_transient( 'mpio_bulk_running' );
                wp_clear_scheduled_hook( 'mpio_bulk_optimization_cron' );
                WP_CLI::success( 'Bulk optimization stopped.' );
                break;

            case 'status':
                if ( $bulk->is_running() ) {
                    $progress_data = get_transient( 'mpio_bulk_progress' );
                    if ( $progress_data ) {
                        WP_CLI::line( WP_CLI::colorize( '%GBulk optimization is running.%n' ) );
                        WP_CLI::line( sprintf(
                            '  Progress: %d / %d  |  Success: %d  |  Errors: %d',
                            $progress_data['processed'] ?? 0,
                            $progress_data['total'] ?? 0,
                            $progress_data['success'] ?? 0,
                            $progress_data['errors'] ?? 0
                        ) );
                    } else {
                        WP_CLI::line( 'Bulk optimization is running (no progress data).' );
                    }
                } else {
                    WP_CLI::line( 'Bulk optimization is not running.' );
                    $stats = $bulk->get_stats();
                    WP_CLI::line( sprintf( '  Unoptimized: %d', $stats['unoptimized'] ) );
                }
                break;

            default:
                WP_CLI::error( 'Usage: wp mpio bulk <start|stop|status>' );
        }
    }

    /**
     * Show processing engine information.
     *
     * ## EXAMPLES
     *
     *     wp mpio engine
     *
     * @subcommand engine
     */
    public function engine( $args, $assoc_args ) {
        if ( ! class_exists( 'MPIO_Admin' ) ) {
            require_once MPIO_PATH . 'admin/class-mpio-admin.php';
        }
        $info = MPIO_Admin::get_engine_info();

        WP_CLI::line( '' );
        WP_CLI::line( WP_CLI::colorize( '%BEngine Information%n' ) );
        WP_CLI::line( str_repeat( '-', 40 ) );
        WP_CLI::line( '  Active Engine:  ' . ucfirst( $info['current_engine'] ) );
        WP_CLI::line( '  GD Available:   ' . ( $info['gd_available'] ? 'Yes' : 'No' ) );
        WP_CLI::line( '  Imagick:        ' . ( $info['imagick_available'] ? 'Yes' : 'No' ) );
        WP_CLI::line( '  PHP Version:    ' . $info['php_version'] );
        WP_CLI::line( '  Memory Limit:   ' . $info['memory_limit'] );
        WP_CLI::line( '  Max Upload:     ' . mpio_format_bytes( $info['max_upload'] ) );

        $formats = 'imagick' === $info['current_engine'] ? $info['imagick_formats'] : $info['gd_formats'];
        if ( ! empty( $formats ) ) {
            $supported = [];
            foreach ( $formats as $fmt => $ok ) {
                if ( $ok ) {
                    $supported[] = strtoupper( $fmt );
                }
            }
            WP_CLI::line( '  Formats:        ' . implode( ', ', $supported ) );
        }
    }

    /**
     * Reset optimization data for an attachment (does not restore file).
     *
     * ## OPTIONS
     *
     * <id>
     * : Attachment ID.
     *
     * ## EXAMPLES
     *
     *     wp mpio reset 123
     *
     * @subcommand reset
     */
    public function reset( $args, $assoc_args ) {
        $id = (int) $args[0];

        if ( ! get_post( $id ) ) {
            WP_CLI::error( "Attachment #{$id} not found." );
        }

        delete_post_meta( $id, '_mpio_data' );
        delete_post_meta( $id, '_mpio_status' );
        delete_post_meta( $id, '_mpio_companions' );

        WP_CLI::success( "Reset optimization data for #{$id}." );
    }

    /**
     * Get all image attachment IDs.
     */
    private function get_all_image_ids(): array {
        global $wpdb;
        return $wpdb->get_col(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_type = 'attachment'
             AND post_mime_type LIKE 'image/%'
             ORDER BY ID ASC"
        );
    }
}
