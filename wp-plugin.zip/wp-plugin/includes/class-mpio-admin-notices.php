<?php
/**
 * Admin notices for Mpire Image Optimizer.
 *
 * Handles activation welcome notice, image size warnings,
 * and plugin conflict detection notices.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

class MPIO_Admin_Notices {

    private static ?MPIO_Admin_Notices $instance = null;

    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_notices', [ $this, 'display_notices' ] );
        add_action( 'wp_ajax_mpio_dismiss_notice', [ $this, 'ajax_dismiss_notice' ] );
        add_action( 'admin_footer', [ $this, 'dismiss_script' ] );
        add_action( 'admin_bar_menu', [ $this, 'admin_bar_stats' ], 999 );
        add_action( 'admin_notices', [ $this, 'auto_optimize_toast' ] );
    }

    /**
     * Display all applicable admin notices.
     */
    public function display_notices(): void {
        $this->welcome_notice();
        $this->unoptimized_notice();
        $this->conflict_notice();
        $this->large_upload_notice();
    }

    /**
     * Welcome notice shown once after activation.
     */
    private function welcome_notice(): void {
        if ( $this->is_dismissed( 'welcome' ) ) {
            return;
        }

        // Only show if plugin was just activated (within first 7 days).
        $activated = get_option( 'mpio_activated_at', 0 );
        if ( ! $activated ) {
            update_option( 'mpio_activated_at', time(), false );
            $activated = time();
        }

        if ( time() - $activated > 7 * DAY_IN_SECONDS ) {
            return;
        }

        $stats = MPIO_Bulk_Optimizer::get_instance()->get_stats();
        ?>
        <div class="notice notice-info is-dismissible mpio-notice" data-notice="welcome">
            <p>
                <strong><?php esc_html_e( 'Mpire Image Optimizer is active!', 'mpire-image-optimizer' ); ?></strong>
            </p>
            <?php if ( $stats['unoptimized'] > 0 ) : ?>
                <p>
                    <?php
                    printf(
                        /* translators: %d: number of images */
                        esc_html__( 'You have %d unoptimized images in your media library.', 'mpire-image-optimizer' ),
                        $stats['unoptimized']
                    );
                    ?>
                </p>
                <p>
                    <a href="<?php echo esc_url( admin_url( 'upload.php?page=mpio-bulk-optimizer' ) ); ?>" class="button button-primary">
                        <?php esc_html_e( 'Bulk Optimize Now', 'mpire-image-optimizer' ); ?>
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'options-general.php?page=mpio-settings' ) ); ?>" class="button">
                        <?php esc_html_e( 'Settings', 'mpire-image-optimizer' ); ?>
                    </a>
                </p>
            <?php else : ?>
                <p>
                    <?php esc_html_e( 'New images will be automatically optimized on upload.', 'mpire-image-optimizer' ); ?>
                    <a href="<?php echo esc_url( admin_url( 'options-general.php?page=mpio-settings' ) ); ?>"><?php esc_html_e( 'Configure settings', 'mpire-image-optimizer' ); ?></a>
                </p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Periodic reminder about unoptimized images (every 30 days).
     */
    private function unoptimized_notice(): void {
        if ( $this->is_dismissed( 'unoptimized' ) ) {
            return;
        }

        // Don't show alongside welcome notice.
        if ( ! $this->is_dismissed( 'welcome' ) ) {
            return;
        }

        // Only show on relevant pages.
        $screen = get_current_screen();
        if ( ! $screen || ! in_array( $screen->id, [ 'dashboard', 'upload' ], true ) ) {
            return;
        }

        $stats = MPIO_Bulk_Optimizer::get_instance()->get_stats();

        // Only show if >10% unoptimized.
        if ( $stats['total_images'] < 10 || $stats['unoptimized'] < ( $stats['total_images'] * 0.1 ) ) {
            return;
        }

        ?>
        <div class="notice notice-warning is-dismissible mpio-notice" data-notice="unoptimized">
            <p>
                <strong><?php esc_html_e( 'Mpire Image Optimizer:', 'mpire-image-optimizer' ); ?></strong>
                <?php
                printf(
                    /* translators: %d: number of images */
                    esc_html__( '%d images are not yet optimized.', 'mpire-image-optimizer' ),
                    $stats['unoptimized']
                );
                ?>
                <a href="<?php echo esc_url( admin_url( 'upload.php?page=mpio-bulk-optimizer' ) ); ?>"><?php esc_html_e( 'Optimize now', 'mpire-image-optimizer' ); ?></a>
            </p>
        </div>
        <?php
    }

    /**
     * Conflict detection notice for other image optimization plugins.
     */
    private function conflict_notice(): void {
        if ( $this->is_dismissed( 'conflict' ) ) {
            return;
        }

        $conflicts = $this->detect_conflicts();

        if ( empty( $conflicts ) ) {
            return;
        }

        ?>
        <div class="notice notice-warning is-dismissible mpio-notice" data-notice="conflict">
            <p>
                <strong><?php esc_html_e( 'Mpire Image Optimizer:', 'mpire-image-optimizer' ); ?></strong>
                <?php esc_html_e( 'The following image optimization plugins are also active. Running multiple optimizers can cause conflicts:', 'mpire-image-optimizer' ); ?>
            </p>
            <ul style="list-style:disc;margin-left:20px">
                <?php foreach ( $conflicts as $plugin ) : ?>
                    <li><?php echo esc_html( $plugin ); ?></li>
                <?php endforeach; ?>
            </ul>
            <p>
                <em><?php esc_html_e( 'Consider deactivating other image optimizers to avoid double-processing.', 'mpire-image-optimizer' ); ?></em>
            </p>
        </div>
        <?php
    }

    /**
     * Warning after uploading a very large image.
     */
    private function large_upload_notice(): void {
        $large_upload = get_transient( 'mpio_large_upload_warning' );
        if ( ! $large_upload ) {
            return;
        }

        delete_transient( 'mpio_large_upload_warning' );

        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <strong><?php esc_html_e( 'Mpire Image Optimizer:', 'mpire-image-optimizer' ); ?></strong>
                <?php
                printf(
                    /* translators: 1: filename, 2: file size */
                    esc_html__( 'Large image uploaded: %1$s (%2$s). Consider resizing before upload for faster processing.', 'mpire-image-optimizer' ),
                    esc_html( $large_upload['name'] ),
                    esc_html( mpio_format_bytes( $large_upload['size'] ) )
                );
                ?>
            </p>
        </div>
        <?php
    }

    /**
     * Detect conflicting image optimization plugins.
     */
    public function detect_conflicts(): array {
        $conflicts = [];

        $known_plugins = [
            'imagify/imagify.php'                          => 'Imagify',
            'wp-smushit/wp-smush.php'                      => 'Smush',
            'shortpixel-image-optimiser/wp-shortpixel.php' => 'ShortPixel',
            'ewww-image-optimizer/ewww-image-optimizer.php' => 'EWWW Image Optimizer',
            'tiny-compress-images/tiny-compress-images.php' => 'TinyPNG',
            'optimus/optimus.php'                           => 'Optimus',
            'kraken-image-optimizer/kraken.php'             => 'Kraken.io',
            'compress-jpeg-png-images/compress-jpeg-png-images.php' => 'Compress JPEG & PNG',
            'robin-image-optimizer/robin-image-optimizer.php' => 'Robin Image Optimizer',
            'jesuspended-image-optimizer/jesuited-image-optimizer.php' => 'Jesuited Image Optimizer',
        ];

        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        foreach ( $known_plugins as $plugin_file => $plugin_name ) {
            if ( is_plugin_active( $plugin_file ) ) {
                $conflicts[] = $plugin_name;
            }
        }

        return $conflicts;
    }

    /**
     * Check if a notice has been dismissed.
     */
    private function is_dismissed( string $notice_id ): bool {
        $dismissed = get_user_meta( get_current_user_id(), 'mpio_dismissed_notices', true );
        if ( ! is_array( $dismissed ) ) {
            return false;
        }

        // For 'unoptimized', dismiss lasts 30 days.
        if ( 'unoptimized' === $notice_id && isset( $dismissed[ $notice_id ] ) ) {
            return ( time() - $dismissed[ $notice_id ] ) < 30 * DAY_IN_SECONDS;
        }

        return isset( $dismissed[ $notice_id ] );
    }

    /**
     * AJAX handler to dismiss a notice.
     */
    public function ajax_dismiss_notice(): void {
        check_ajax_referer( 'mpio_nonce', 'nonce' );

        $notice_id = sanitize_key( $_POST['notice'] ?? '' );
        if ( ! $notice_id ) {
            wp_send_json_error();
        }

        $dismissed = get_user_meta( get_current_user_id(), 'mpio_dismissed_notices', true );
        if ( ! is_array( $dismissed ) ) {
            $dismissed = [];
        }

        $dismissed[ $notice_id ] = time();
        update_user_meta( get_current_user_id(), 'mpio_dismissed_notices', $dismissed );

        wp_send_json_success();
    }

    /**
     * Print inline JS for dismissing notices via AJAX.
     */
    public function dismiss_script(): void {
        if ( ! current_user_can( 'upload_files' ) ) {
            return;
        }
        ?>
        <script>
        (function() {
            document.addEventListener('click', function(e) {
                var notice = e.target.closest('.mpio-notice');
                if (!notice) return;
                var btn = e.target.closest('.notice-dismiss');
                if (!btn) return;

                var noticeId = notice.getAttribute('data-notice');
                if (!noticeId) return;

                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>');
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.send('action=mpio_dismiss_notice&nonce=<?php echo esc_js( wp_create_nonce( 'mpio_nonce' ) ); ?>&notice=' + noticeId);
            });
        })();
        </script>
        <?php
    }

    /**
     * Add optimization stats to the WordPress admin bar.
     */
    public function admin_bar_stats( $wp_admin_bar ): void {
        if ( ! current_user_can( 'upload_files' ) || ! is_admin() ) {
            return;
        }

        $stats = MPIO_Bulk_Optimizer::get_instance()->get_stats();
        $total_saved = $stats['total_original_size'] - $stats['total_optimized_size'];

        // Parent node.
        $wp_admin_bar->add_node( [
            'id'    => 'mpio-stats',
            'title' => '<span class="ab-icon dashicons dashicons-images-alt2" style="font-family:dashicons;font-size:16px;line-height:1.6;"></span> '
                     . esc_html( mpio_format_bytes( $total_saved ) ) . ' ' . __( 'saved', 'mpire-image-optimizer' ),
            'href'  => admin_url( 'upload.php?page=mpio-bulk-optimizer' ),
            'meta'  => [
                'title' => sprintf(
                    /* translators: 1: optimized count, 2: total count */
                    __( '%1$d of %2$d images optimized', 'mpire-image-optimizer' ),
                    $stats['optimized'],
                    $stats['total_images']
                ),
            ],
        ] );

        // Child: quick stats.
        $wp_admin_bar->add_node( [
            'parent' => 'mpio-stats',
            'id'     => 'mpio-stats-detail',
            'title'  => sprintf( '%d optimized / %d unoptimized', $stats['optimized'], $stats['unoptimized'] ),
            'href'   => admin_url( 'upload.php?page=mpio-bulk-optimizer' ),
        ] );

        if ( $stats['errors'] > 0 ) {
            $wp_admin_bar->add_node( [
                'parent' => 'mpio-stats',
                'id'     => 'mpio-stats-errors',
                'title'  => sprintf( '%d errors', $stats['errors'] ),
                'href'   => admin_url( 'upload.php?mpio_filter=errors' ),
            ] );
        }

        // Child: quick links.
        $wp_admin_bar->add_node( [
            'parent' => 'mpio-stats',
            'id'     => 'mpio-link-bulk',
            'title'  => __( 'Bulk Optimize', 'mpire-image-optimizer' ),
            'href'   => admin_url( 'upload.php?page=mpio-bulk-optimizer' ),
        ] );

        $wp_admin_bar->add_node( [
            'parent' => 'mpio-stats',
            'id'     => 'mpio-link-settings',
            'title'  => __( 'Settings', 'mpire-image-optimizer' ),
            'href'   => admin_url( 'options-general.php?page=mpio-settings' ),
        ] );
    }

    /**
     * Show a success toast after auto-optimization on upload.
     */
    public function auto_optimize_toast(): void {
        $toast = get_transient( 'mpio_optimize_toast_' . get_current_user_id() );
        if ( ! $toast || ! is_array( $toast ) ) {
            return;
        }

        delete_transient( 'mpio_optimize_toast_' . get_current_user_id() );

        ?>
        <div class="notice notice-success is-dismissible" style="border-left-color:#10b981">
            <p>
                <strong><?php esc_html_e( 'Mpire Image Optimizer:', 'mpire-image-optimizer' ); ?></strong>
                <?php
                printf(
                    /* translators: 1: filename, 2: savings percentage, 3: bytes saved */
                    esc_html__( '"%1$s" optimized — %2$s%% smaller (%3$s saved)', 'mpire-image-optimizer' ),
                    esc_html( $toast['name'] ),
                    esc_html( $toast['savings_percent'] ),
                    esc_html( mpio_format_bytes( $toast['saved_bytes'] ) )
                );
                ?>
            </p>
        </div>
        <?php
    }
}
