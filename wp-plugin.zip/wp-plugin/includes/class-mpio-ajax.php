<?php
/**
 * Central AJAX handler for Mpire Image Optimizer.
 *
 * Registers miscellaneous AJAX endpoints not handled by other classes
 * and provides shared AJAX utilities.
 *
 * @package Mpire_Image_Optimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIO_Ajax {

	/**
	 * Singleton instance.
	 *
	 * @var MPIO_Ajax|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return MPIO_Ajax
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor. Registers AJAX actions.
	 */
	private function __construct() {
		add_action( 'wp_ajax_mpio_get_stats', array( $this, 'ajax_get_stats' ) );
		add_action( 'wp_ajax_mpio_get_image_data', array( $this, 'ajax_get_image_data' ) );
		add_action( 'wp_ajax_mpio_save_settings', array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_mpio_check_engine', array( $this, 'ajax_check_engine' ) );
		add_action( 'wp_ajax_mpio_reset_image', array( $this, 'ajax_reset_image' ) );
		add_action( 'wp_ajax_mpio_export_csv', array( $this, 'ajax_export_csv' ) );
	}

	/**
	 * AJAX: Get overall optimization statistics.
	 *
	 * @return void
	 */
	public function ajax_get_stats() {
		self::verify_request( 'upload_files' );

		$stats = MPIO_Bulk_Optimizer::get_instance()->get_stats();

		self::send_success( $stats );
	}

	/**
	 * AJAX: Get optimization data for a single image attachment.
	 *
	 * @return void
	 */
	public function ajax_get_image_data() {
		self::verify_request( 'upload_files' );

		$attachment_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;

		if ( ! $attachment_id ) {
			self::send_error( __( 'Invalid attachment ID.', 'mpire-image-optimizer' ), 400 );
		}

		$mpio_data = get_post_meta( $attachment_id, '_mpio_data', true );
		$file_path = get_attached_file( $attachment_id );

		$data = array(
			'attachment_id'    => $attachment_id,
			'optimization'     => ! empty( $mpio_data ) ? $mpio_data : null,
			'status'           => ! empty( $mpio_data['status'] ) ? $mpio_data['status'] : 'unoptimized',
			'backup_available' => (bool) get_post_meta( $attachment_id, '_mpio_backup_path', true ),
			'file_size'        => $file_path && file_exists( $file_path ) ? filesize( $file_path ) : 0,
			'original_size'    => ! empty( $mpio_data['original_size'] ) ? $mpio_data['original_size'] : 0,
			'format'           => $file_path ? wp_check_filetype( $file_path )['ext'] : '',
		);

		self::send_success( $data );
	}

	/**
	 * AJAX: Save plugin settings.
	 *
	 * @return void
	 */
	public function ajax_save_settings() {
		self::verify_request( 'manage_options' );

		$settings = isset( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : array();

		if ( ! is_array( $settings ) ) {
			self::send_error( __( 'Invalid settings data.', 'mpire-image-optimizer' ), 400 );
		}

		$sanitized = MPIO_Settings::get_instance()->sanitize_settings( $settings );

		update_option( 'mpio_settings', $sanitized );

		self::send_success( $sanitized, __( 'Settings saved successfully.', 'mpire-image-optimizer' ) );
	}

	/**
	 * AJAX: Check available image processing engines.
	 *
	 * @return void
	 */
	public function ajax_check_engine() {
		self::verify_request( 'upload_files' );

		$gd_available      = extension_loaded( 'gd' );
		$imagick_available = extension_loaded( 'imagick' );

		$gd_formats      = array();
		$imagick_formats  = array();

		if ( $gd_available ) {
			$gd_info    = gd_info();
			$format_map = array(
				'JPEG Support' => 'jpeg',
				'PNG Support'  => 'png',
				'GIF Create Support' => 'gif',
				'WebP Support' => 'webp',
				'AVIF Support' => 'avif',
				'BMP Support'  => 'bmp',
			);

			foreach ( $format_map as $key => $format ) {
				if ( ! empty( $gd_info[ $key ] ) ) {
					$gd_formats[] = $format;
				}
			}
		}

		if ( $imagick_available ) {
			try {
				$imagick          = new Imagick();
				$supported        = $imagick->queryFormats();
				$imagick_format_map = array(
					'JPEG' => 'jpeg',
					'PNG'  => 'png',
					'GIF'  => 'gif',
					'WEBP' => 'webp',
					'AVIF' => 'avif',
					'BMP'  => 'bmp',
				);

				foreach ( $imagick_format_map as $key => $format ) {
					if ( in_array( $key, $supported, true ) ) {
						$imagick_formats[] = $format;
					}
				}
			} catch ( Exception $e ) {
				$imagick_formats = array();
			}
		}

		// Determine current engine.
		$current_engine = function_exists( 'mpio_get_engine' ) ? mpio_get_engine() : 'gd';

		$data = array(
			'current_engine'    => $current_engine,
			'gd_available'      => $gd_available,
			'imagick_available' => $imagick_available,
			'supported_formats' => array(
				'gd'      => $gd_formats,
				'imagick' => $imagick_formats,
			),
			'php_version'       => phpversion(),
			'memory_limit'      => ini_get( 'memory_limit' ),
		);

		self::send_success( $data );
	}

	/**
	 * AJAX: Reset optimization data for an image (does not restore backup).
	 *
	 * @return void
	 */
	public function ajax_reset_image() {
		self::verify_request( 'upload_files' );

		$attachment_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;

		if ( ! $attachment_id ) {
			self::send_error( __( 'Invalid attachment ID.', 'mpire-image-optimizer' ), 400 );
		}

		// Delete all _mpio_* meta keys for this attachment.
		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key LIKE %s",
				$attachment_id,
				'_mpio_%'
			)
		);

		self::send_success(
			array( 'attachment_id' => $attachment_id ),
			__( 'Optimization data has been reset.', 'mpire-image-optimizer' )
		);
	}

	/**
	 * Verify an AJAX request by checking nonce and user capability.
	 *
	 * Sends a JSON error and dies if verification fails.
	 *
	 * @param string $capability The capability to check. Default 'upload_files'.
	 * @return bool True if the request is valid.
	 */
	public static function verify_request( $capability = 'upload_files' ) {
		$nonce = '';

		if ( isset( $_POST['nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );
		} elseif ( isset( $_GET['nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_GET['nonce'] ) );
		}

		if ( ! wp_verify_nonce( $nonce, 'mpio_nonce' ) ) {
			self::send_error( __( 'Security check failed.', 'mpire-image-optimizer' ), 403 );
		}

		if ( ! current_user_can( $capability ) ) {
			self::send_error( __( 'You do not have permission to perform this action.', 'mpire-image-optimizer' ), 403 );
		}

		return true;
	}

	/**
	 * Send a successful JSON response.
	 *
	 * @param mixed  $data    Optional response data.
	 * @param string $message Optional success message.
	 * @return void
	 */
	public static function send_success( $data = null, $message = '' ) {
		$response = is_array( $data ) ? $data : array();

		if ( ! empty( $message ) ) {
			$response['message'] = $message;
		}

		wp_send_json_success( $response );
	}

	/**
	 * Send an error JSON response.
	 *
	 * @param string $message Error message.
	 * @param int    $code    HTTP-style error code. Default 400.
	 * @return void
	 */
	public static function send_error( $message, $code = 400 ) {
		wp_send_json_error(
			array(
				'message' => $message,
				'code'    => $code,
			)
		);
	}

	/**
	 * AJAX: Export optimization statistics as CSV.
	 */
	public function ajax_export_csv() {
		check_ajax_referer( 'mpio_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied.' );
		}

		global $wpdb;

		$results = $wpdb->get_results(
			"SELECT p.ID, p.post_title, p.post_mime_type,
			        pm_data.meta_value AS mpio_data,
			        pm_status.meta_value AS mpio_status
			 FROM {$wpdb->posts} p
			 LEFT JOIN {$wpdb->postmeta} pm_data ON p.ID = pm_data.post_id AND pm_data.meta_key = '_mpio_data'
			 LEFT JOIN {$wpdb->postmeta} pm_status ON p.ID = pm_status.post_id AND pm_status.meta_key = '_mpio_status'
			 WHERE p.post_type = 'attachment'
			   AND p.post_mime_type LIKE 'image/%'
			 ORDER BY p.ID ASC"
		);

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=mpio-stats-' . gmdate( 'Y-m-d' ) . '.csv' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		$output = fopen( 'php://output', 'w' );

		// Header row.
		fputcsv( $output, [
			'ID',
			'Title',
			'MIME Type',
			'Status',
			'Original Size (bytes)',
			'Optimized Size (bytes)',
			'Savings (%)',
			'Format',
			'Optimized At',
		] );

		foreach ( $results as $row ) {
			$data          = maybe_unserialize( $row->mpio_data );
			$original_size = 0;
			$opt_size      = 0;
			$savings       = 0;
			$format        = '';
			$optimized_at  = '';

			if ( is_array( $data ) ) {
				$original_size = $data['original_size'] ?? 0;
				$opt_size      = $data['optimized_size'] ?? 0;
				$savings       = $data['savings_percent'] ?? 0;
				$format        = $data['format'] ?? '';
				$optimized_at  = $data['optimized_at'] ?? '';
			}

			fputcsv( $output, [
				$row->ID,
				$row->post_title,
				$row->post_mime_type,
				$row->mpio_status ?: 'unoptimized',
				$original_size,
				$opt_size,
				$savings,
				$format,
				$optimized_at,
			] );
		}

		fclose( $output );
		exit;
	}
}
