<?php
/**
 * Media Library integration for Mpire Image Optimizer.
 *
 * Adds an optimizer column, filter dropdown, attachment fields,
 * and AJAX handlers for single-image optimize/restore actions.
 *
 * @package Mpire_Image_Optimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class MPIO_Media_Library
 *
 * Integrates image optimization status into the WordPress Media Library.
 */
class MPIO_Media_Library {

    /**
     * Singleton instance.
     *
     * @var MPIO_Media_Library|null
     */
    private static $instance = null;

    /**
     * Return the singleton instance.
     *
     * @return MPIO_Media_Library
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor. Register all hooks.
     */
    private function __construct() {
        // Media list table columns.
        add_filter( 'manage_media_columns', array( $this, 'add_media_column' ) );
        add_action( 'manage_media_custom_column', array( $this, 'render_media_column' ), 10, 2 );

        // Filter dropdown in media library.
        add_action( 'restrict_manage_posts', array( $this, 'add_filter_dropdown' ) );
        add_action( 'pre_get_posts', array( $this, 'filter_media_query' ) );

        // Attachment edit modal fields.
        add_filter( 'attachment_fields_to_edit', array( $this, 'add_attachment_fields' ), 10, 2 );

        // Pass optimization data to grid view JS.
        add_filter( 'wp_prepare_attachment_for_js', array( $this, 'add_grid_data' ), 10, 3 );

        // AJAX handlers.
        add_action( 'wp_ajax_mpio_optimize_single', array( $this, 'ajax_optimize_single' ) );
        add_action( 'wp_ajax_mpio_restore_single', array( $this, 'ajax_restore_single' ) );
        add_action( 'wp_ajax_mpio_reoptimize_single', array( $this, 'ajax_reoptimize_single' ) );
        add_action( 'wp_ajax_mpio_exclude_single', array( $this, 'ajax_exclude_single' ) );
        add_action( 'wp_ajax_mpio_include_single', array( $this, 'ajax_include_single' ) );
    }

    /**
     * Add the optimizer status column to the media list table.
     *
     * Inserts the column immediately after the 'title' column.
     *
     * @param array $columns Existing columns.
     * @return array Modified columns.
     */
    public function add_media_column( $columns ) {
        $new_columns = array();

        foreach ( $columns as $key => $value ) {
            $new_columns[ $key ] = $value;

            if ( 'title' === $key ) {
                $new_columns['mpio_status'] = esc_html__( 'Mpire Optimizer', 'mpire-image-optimizer' );
            }
        }

        // Fallback if 'title' column was not found.
        if ( ! isset( $new_columns['mpio_status'] ) ) {
            $new_columns['mpio_status'] = esc_html__( 'Mpire Optimizer', 'mpire-image-optimizer' );
        }

        return $new_columns;
    }

    /**
     * Render the content for the optimizer status column.
     *
     * @param string $column_name The column being rendered.
     * @param int    $post_id     The attachment post ID.
     */
    public function render_media_column( $column_name, $post_id ) {
        if ( 'mpio_status' !== $column_name ) {
            return;
        }

        $status    = get_post_meta( $post_id, '_mpio_status', true );
        $mpio_data = get_post_meta( $post_id, '_mpio_data', true );
        $excluded  = (bool) get_post_meta( $post_id, '_mpio_excluded', true );
        $nonce     = wp_create_nonce( 'mpio_single_action_' . $post_id );

        if ( $excluded ) {
            printf(
                '<span class="mpio-badge mpio-badge-skipped" style="color:#826eb4;">%s</span><br>',
                esc_html__( 'Skipped (excluded)', 'mpire-image-optimizer' )
            );
            printf(
                '<a href="#" class="mpio-include-btn" data-id="%d" data-nonce="%s">%s</a>',
                esc_attr( $post_id ),
                esc_attr( $nonce ),
                esc_html__( 'Remove exclusion', 'mpire-image-optimizer' )
            );
            return;
        }

        if ( 'optimized' === $status ) {
            $savings_pct = is_array( $mpio_data ) && ! empty( $mpio_data['savings_percent'] ) ? floatval( $mpio_data['savings_percent'] ) : 0;
            printf(
                '<span class="mpio-badge mpio-badge-success" style="color:#46b450;">%s</span><br>',
                /* translators: %s: savings percentage */
                sprintf( esc_html__( 'Optimized: %s%% saved', 'mpire-image-optimizer' ), number_format_i18n( $savings_pct, 1 ) )
            );
            printf(
                '<a href="#" class="mpio-restore-btn" data-id="%d" data-nonce="%s">%s</a>',
                esc_attr( $post_id ),
                esc_attr( $nonce ),
                esc_html__( 'Restore', 'mpire-image-optimizer' )
            );
            echo ' | ';
            printf(
                '<a href="#" class="mpio-reoptimize" data-id="%d" data-nonce="%s">%s</a>',
                esc_attr( $post_id ),
                esc_attr( $nonce ),
                esc_html__( 'Re-optimize', 'mpire-image-optimizer' )
            );

            // Before/after compare link (only if backup exists).
            if ( MPIO_Backup::get_instance()->has_backup( $post_id ) ) {
                $backup_path = MPIO_Backup::get_instance()->get_backup_path( $post_id );
                $upload_dir  = wp_upload_dir();
                $backup_url  = str_replace( $upload_dir['basedir'], $upload_dir['baseurl'], $backup_path );
                $current_url = wp_get_attachment_url( $post_id );
                echo ' | ';
                printf(
                    '<a href="#" class="mpio-compare" data-original="%s" data-optimized="%s">%s</a>',
                    esc_attr( $backup_url ),
                    esc_attr( $current_url ),
                    esc_html__( 'Compare', 'mpire-image-optimizer' )
                );
            }
        } elseif ( 'error' === $status ) {
            $error = get_post_meta( $post_id, '_mpio_error', true );
            $error_msg = ! empty( $error ) ? $error : __( 'Unknown error', 'mpire-image-optimizer' );
            printf(
                '<span class="mpio-badge mpio-badge-error" style="color:#dc3232;">%s</span><br>',
                esc_html( $error_msg )
            );
            printf(
                '<a href="#" class="mpio-optimize-btn" data-id="%d" data-nonce="%s">%s</a>',
                esc_attr( $post_id ),
                esc_attr( $nonce ),
                esc_html__( 'Retry', 'mpire-image-optimizer' )
            );
        } elseif ( 'in_progress' === $status ) {
            printf(
                '<span class="spinner is-active" style="float:none;"></span> %s',
                esc_html__( 'Optimizing...', 'mpire-image-optimizer' )
            );
        } else {
            // Unoptimized.
            printf(
                '<button type="button" class="button button-small mpio-optimize-btn" data-id="%d" data-nonce="%s">%s</button>',
                esc_attr( $post_id ),
                esc_attr( $nonce ),
                esc_html__( 'Optimize', 'mpire-image-optimizer' )
            );
            echo ' ';
            printf(
                '<a href="#" class="mpio-exclude-btn" data-id="%d" data-nonce="%s">%s</a>',
                esc_attr( $post_id ),
                esc_attr( $nonce ),
                esc_html__( 'Skip', 'mpire-image-optimizer' )
            );
        }
    }

    /**
     * Add optimization status filter dropdown to the media library.
     *
     * Only displays on the upload.php (Media Library list view) screen.
     */
    public function add_filter_dropdown() {
        $screen = get_current_screen();

        if ( ! $screen || 'upload' !== $screen->base ) {
            return;
        }

        $selected = isset( $_GET['mpio_filter'] ) ? sanitize_text_field( wp_unslash( $_GET['mpio_filter'] ) ) : '';

        $options = array(
            ''            => __( 'All Optimization Statuses', 'mpire-image-optimizer' ),
            'optimized'   => __( 'Optimized', 'mpire-image-optimizer' ),
            'unoptimized' => __( 'Unoptimized', 'mpire-image-optimizer' ),
            'errors'      => __( 'Errors', 'mpire-image-optimizer' ),
            'excluded'    => __( 'Excluded', 'mpire-image-optimizer' ),
        );

        echo '<select name="mpio_filter" id="mpio-filter">';
        foreach ( $options as $value => $label ) {
            printf(
                '<option value="%s"%s>%s</option>',
                esc_attr( $value ),
                selected( $selected, $value, false ),
                esc_html( $label )
            );
        }
        echo '</select>';
    }

    /**
     * Modify the media query based on the optimization status filter.
     *
     * @param WP_Query $query The current query object.
     */
    public function filter_media_query( $query ) {
        if ( ! is_admin() || ! $query->is_main_query() ) {
            return;
        }

        if ( 'attachment' !== $query->get( 'post_type' ) ) {
            return;
        }

        if ( empty( $_GET['mpio_filter'] ) ) {
            return;
        }

        $filter = sanitize_text_field( wp_unslash( $_GET['mpio_filter'] ) );

        switch ( $filter ) {
            case 'optimized':
                $query->set( 'meta_query', array(
                    array(
                        'key'     => '_mpio_status',
                        'value'   => 'optimized',
                        'compare' => '=',
                    ),
                ) );
                break;

            case 'unoptimized':
                $query->set( 'meta_query', array(
                    'relation' => 'OR',
                    array(
                        'key'     => '_mpio_status',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key'     => '_mpio_status',
                        'value'   => '',
                        'compare' => '=',
                    ),
                ) );
                break;

            case 'errors':
                $query->set( 'meta_query', array(
                    array(
                        'key'     => '_mpio_status',
                        'value'   => 'error',
                        'compare' => '=',
                    ),
                ) );
                break;

            case 'excluded':
                $query->set( 'meta_query', array(
                    array(
                        'key'     => '_mpio_excluded',
                        'value'   => '1',
                        'compare' => '=',
                    ),
                ) );
                break;
        }
    }

    /**
     * Add optimization info fields to the attachment edit modal.
     *
     * @param array   $form_fields Existing form fields.
     * @param WP_Post $post        The attachment post object.
     * @return array Modified form fields.
     */
    public function add_attachment_fields( $form_fields, $post ) {
        $status    = get_post_meta( $post->ID, '_mpio_status', true );
        $mpio_data = get_post_meta( $post->ID, '_mpio_data', true );
        $excluded  = (bool) get_post_meta( $post->ID, '_mpio_excluded', true );

        $info_parts = array();

        if ( $excluded ) {
            $info_parts[] = sprintf(
                /* translators: %s: optimization status */
                esc_html__( 'Status: %s', 'mpire-image-optimizer' ),
                '<strong style="color:#826eb4;">' . esc_html__( 'Excluded', 'mpire-image-optimizer' ) . '</strong>'
            );
            $info_parts[] = esc_html__( 'This image is excluded from optimization and WebP conversion.', 'mpire-image-optimizer' );
        } elseif ( 'optimized' === $status ) {
            $info_parts[] = sprintf(
                /* translators: %s: optimization status */
                esc_html__( 'Status: %s', 'mpire-image-optimizer' ),
                '<strong style="color:#46b450;">' . esc_html__( 'Optimized', 'mpire-image-optimizer' ) . '</strong>'
            );

            $savings = is_array( $mpio_data ) && ! empty( $mpio_data['savings_percent'] ) ? $mpio_data['savings_percent'] : 0;
            if ( $savings > 0 ) {
                $info_parts[] = sprintf(
                    /* translators: %s: savings percentage */
                    esc_html__( 'Savings: %s%%', 'mpire-image-optimizer' ),
                    number_format_i18n( floatval( $savings ), 1 )
                );
            }

            $format = is_array( $mpio_data ) && ! empty( $mpio_data['format'] ) ? $mpio_data['format'] : '';
            if ( ! empty( $format ) ) {
                $info_parts[] = sprintf(
                    /* translators: %s: image format */
                    esc_html__( 'Format: %s', 'mpire-image-optimizer' ),
                    esc_html( strtoupper( $format ) )
                );
            }
        } elseif ( 'error' === $status ) {
            $info_parts[] = sprintf(
                /* translators: %s: optimization status */
                esc_html__( 'Status: %s', 'mpire-image-optimizer' ),
                '<strong style="color:#dc3232;">' . esc_html__( 'Error', 'mpire-image-optimizer' ) . '</strong>'
            );

            $error = get_post_meta( $post->ID, '_mpio_error', true );
            if ( ! empty( $error ) ) {
                $info_parts[] = sprintf(
                    /* translators: %s: error message */
                    esc_html__( 'Error: %s', 'mpire-image-optimizer' ),
                    esc_html( $error )
                );
            }
        } elseif ( 'in_progress' === $status ) {
            $info_parts[] = sprintf(
                /* translators: %s: optimization status */
                esc_html__( 'Status: %s', 'mpire-image-optimizer' ),
                '<strong>' . esc_html__( 'In Progress', 'mpire-image-optimizer' ) . '</strong>'
            );
        } else {
            $info_parts[] = sprintf(
                /* translators: %s: optimization status */
                esc_html__( 'Status: %s', 'mpire-image-optimizer' ),
                esc_html__( 'Not Optimized', 'mpire-image-optimizer' )
            );
        }

        $form_fields['mpio_optimization'] = array(
            'label' => __( 'Mpire Optimizer', 'mpire-image-optimizer' ),
            'input' => 'html',
            'html'  => '<div class="mpio-attachment-info">' . implode( '<br>', $info_parts ) . '</div>',
        );

        return $form_fields;
    }

    /**
     * Add optimization data to attachment JS object for grid view badges.
     */
    public function add_grid_data( $response, $attachment, $meta ) {
        $status  = get_post_meta( $attachment->ID, '_mpio_status', true );
        $data    = get_post_meta( $attachment->ID, '_mpio_data', true );
        $savings = 0;

        if ( is_array( $data ) && ! empty( $data['savings_percent'] ) ) {
            $savings = $data['savings_percent'];
        }

        $response['mpio_status']   = $status ?: '';
        $response['mpio_savings']  = $savings;
        $response['mpio_excluded'] = (bool) get_post_meta( $attachment->ID, '_mpio_excluded', true );

        return $response;
    }

    /**
     * AJAX handler to optimize a single image.
     *
     * Expects POST with attachment_id and nonce.
     */
    public function ajax_optimize_single() {
        $attachment_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;

        if ( ! $attachment_id ) {
            wp_send_json_error( array(
                'message' => __( 'Invalid attachment ID.', 'mpire-image-optimizer' ),
            ) );
        }

        check_ajax_referer( 'mpio_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_post', $attachment_id ) ) {
            wp_send_json_error( array(
                'message' => __( 'You do not have permission to optimize this image.', 'mpire-image-optimizer' ),
            ) );
        }

        $result = MPIO_Optimizer::get_instance()->optimize( $attachment_id );

        if ( empty( $result['success'] ) ) {
            wp_send_json_error( array(
                'message' => __( 'Optimization failed.', 'mpire-image-optimizer' ),
            ) );
        }

        wp_send_json_success( array(
            'message'                  => __( 'Image optimized successfully.', 'mpire-image-optimizer' ),
            'savings_percent'          => $result['savings_percent'],
            'original_size_formatted'  => mpio_format_bytes( $result['original_size'] ),
            'optimized_size_formatted' => mpio_format_bytes( $result['optimized_size'] ),
        ) );
    }

    /**
     * AJAX handler to restore a single image to its original.
     *
     * Expects POST with attachment_id and nonce.
     */
    public function ajax_restore_single() {
        $attachment_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;

        if ( ! $attachment_id ) {
            wp_send_json_error( array(
                'message' => __( 'Invalid attachment ID.', 'mpire-image-optimizer' ),
            ) );
        }

        check_ajax_referer( 'mpio_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_post', $attachment_id ) ) {
            wp_send_json_error( array(
                'message' => __( 'You do not have permission to restore this image.', 'mpire-image-optimizer' ),
            ) );
        }

        $result = MPIO_Backup::get_instance()->restore( $attachment_id );

        if ( false === $result ) {
            wp_send_json_error( array(
                'message' => __( 'Failed to restore image from backup.', 'mpire-image-optimizer' ),
            ) );
        }

        wp_send_json_success( array(
            'message' => __( 'Image restored successfully.', 'mpire-image-optimizer' ),
        ) );
    }

    /**
     * AJAX handler to exclude a single image from optimization.
     */
    public function ajax_exclude_single() {
        $attachment_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;

        if ( ! $attachment_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid attachment ID.', 'mpire-image-optimizer' ) ) );
        }

        check_ajax_referer( 'mpio_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_post', $attachment_id ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mpire-image-optimizer' ) ) );
        }

        update_post_meta( $attachment_id, '_mpio_excluded', 1 );

        // Delete existing WebP/AVIF companion files so server rewrite rules stop serving them.
        $file_path = get_attached_file( $attachment_id );
        if ( $file_path ) {
            $backup = MPIO_Backup::get_instance();
            $backup->delete_conversion_files( $file_path );

            // Also delete companions for thumbnails.
            $metadata = wp_get_attachment_metadata( $attachment_id );
            if ( ! empty( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ) {
                $upload_dir = dirname( $file_path );
                foreach ( $metadata['sizes'] as $size_data ) {
                    $thumb_path = trailingslashit( $upload_dir ) . $size_data['file'];
                    if ( file_exists( $thumb_path ) ) {
                        $backup->delete_conversion_files( $thumb_path );
                    }
                }
            }

            // Clear companion meta.
            delete_post_meta( $attachment_id, '_mpio_companions' );
        }

        wp_send_json_success( array(
            'message' => __( 'Image excluded from optimization.', 'mpire-image-optimizer' ),
        ) );
    }

    /**
     * AJAX handler to remove exclusion from a single image.
     */
    public function ajax_include_single() {
        $attachment_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;

        if ( ! $attachment_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid attachment ID.', 'mpire-image-optimizer' ) ) );
        }

        check_ajax_referer( 'mpio_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_post', $attachment_id ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mpire-image-optimizer' ) ) );
        }

        delete_post_meta( $attachment_id, '_mpio_excluded' );

        wp_send_json_success( array(
            'message' => __( 'Image exclusion removed.', 'mpire-image-optimizer' ),
        ) );
    }

    /**
     * AJAX: Re-optimize an already optimized image.
     *
     * Restores from backup first (if available), then re-optimizes
     * with current settings. This allows changing quality/level.
     */
    public function ajax_reoptimize_single() {
        check_ajax_referer( 'mpio_nonce', 'nonce' );

        $attachment_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;

        if ( ! $attachment_id || ! current_user_can( 'upload_files' ) ) {
            wp_send_json_error( array(
                'message' => __( 'Permission denied.', 'mpire-image-optimizer' ),
            ) );
        }

        $backup    = MPIO_Backup::get_instance();
        $optimizer = MPIO_Optimizer::get_instance();

        // Restore from backup first so we re-optimize the original.
        if ( $backup->has_backup( $attachment_id ) ) {
            $backup->restore( $attachment_id );
        }

        // Re-create backup of the (now restored) original.
        $file_path = get_attached_file( $attachment_id );
        if ( $file_path && file_exists( $file_path ) && mpio_get_setting( 'keep_backup', true ) ) {
            $backup->backup( $attachment_id, $file_path );
        }

        // Optimize with current settings.
        $result = $optimizer->optimize( $attachment_id );

        if ( $result['success'] ) {
            mpio_log( 'Re-optimized image', 'info', [
                'id'      => $attachment_id,
                'savings' => $result['savings_percent'] . '%',
            ] );

            wp_send_json_success( array(
                'message'                => __( 'Image re-optimized successfully.', 'mpire-image-optimizer' ),
                'savings_percent'        => $result['savings_percent'],
                'original_size_formatted'  => mpio_format_bytes( $result['original_size'] ),
                'optimized_size_formatted' => mpio_format_bytes( $result['optimized_size'] ),
            ) );
        } else {
            wp_send_json_error( array(
                'message' => __( 'Re-optimization failed.', 'mpire-image-optimizer' ),
            ) );
        }
    }
}
