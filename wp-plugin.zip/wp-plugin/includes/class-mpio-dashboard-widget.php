<?php
/**
 * Dashboard widget for Mpire Image Optimizer.
 *
 * Shows a quick optimization stats summary on the WordPress admin dashboard.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

class MPIO_Dashboard_Widget {

    private static ?MPIO_Dashboard_Widget $instance = null;

    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'wp_dashboard_setup', [ $this, 'register_widget' ] );
    }

    public function register_widget(): void {
        if ( ! current_user_can( 'upload_files' ) ) {
            return;
        }

        wp_add_dashboard_widget(
            'mpio_dashboard_widget',
            __( 'Mpire Image Optimizer', 'mpire-image-optimizer' ),
            [ $this, 'render_widget' ]
        );
    }

    public function render_widget(): void {
        $stats = MPIO_Bulk_Optimizer::get_instance()->get_stats();

        $total_saved  = $stats['total_original_size'] - $stats['total_optimized_size'];
        $savings_pct  = $stats['total_original_size'] > 0
            ? round( ( $total_saved / $stats['total_original_size'] ) * 100, 1 )
            : 0;
        $optimized_pct = $stats['total_images'] > 0
            ? round( ( $stats['optimized'] / $stats['total_images'] ) * 100 )
            : 0;
        ?>
        <style>
            .mpio-dw-stats { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px; }
            .mpio-dw-stat { text-align: center; padding: 10px; background: #f6f7f7; border-radius: 6px; }
            .mpio-dw-stat-num { font-size: 22px; font-weight: 700; line-height: 1.2; }
            .mpio-dw-stat-label { font-size: 11px; color: #646970; }
            .mpio-dw-progress { background: #ddd; border-radius: 4px; height: 8px; margin: 8px 0; }
            .mpio-dw-progress-fill { height: 100%; border-radius: 4px; background: linear-gradient(90deg, #4f46e5, #10b981); }
            .mpio-dw-links { display: flex; gap: 8px; margin-top: 12px; }
            .mpio-dw-links a { font-size: 12px; }
            .mpio-dw-green { color: #10b981; }
            .mpio-dw-blue { color: #3b82f6; }
            .mpio-dw-orange { color: #f59e0b; }
            .mpio-dw-red { color: #ef4444; }
        </style>

        <div class="mpio-dw-stats">
            <div class="mpio-dw-stat">
                <div class="mpio-dw-stat-num mpio-dw-green"><?php echo esc_html( $stats['optimized'] ); ?></div>
                <div class="mpio-dw-stat-label"><?php esc_html_e( 'Optimized', 'mpire-image-optimizer' ); ?></div>
            </div>
            <div class="mpio-dw-stat">
                <div class="mpio-dw-stat-num mpio-dw-orange"><?php echo esc_html( $stats['unoptimized'] ); ?></div>
                <div class="mpio-dw-stat-label"><?php esc_html_e( 'Unoptimized', 'mpire-image-optimizer' ); ?></div>
            </div>
            <div class="mpio-dw-stat">
                <div class="mpio-dw-stat-num mpio-dw-blue"><?php echo esc_html( mpio_format_bytes( $total_saved ) ); ?></div>
                <div class="mpio-dw-stat-label"><?php esc_html_e( 'Total Saved', 'mpire-image-optimizer' ); ?></div>
            </div>
            <div class="mpio-dw-stat">
                <div class="mpio-dw-stat-num"><?php echo esc_html( $savings_pct . '%' ); ?></div>
                <div class="mpio-dw-stat-label"><?php esc_html_e( 'Avg Compression', 'mpire-image-optimizer' ); ?></div>
            </div>
        </div>

        <?php if ( $stats['total_images'] > 0 ) : ?>
        <div style="font-size: 12px; color: #646970;">
            <?php echo esc_html( $optimized_pct ); ?>% <?php esc_html_e( 'of images optimized', 'mpire-image-optimizer' ); ?>
        </div>
        <div class="mpio-dw-progress">
            <div class="mpio-dw-progress-fill" style="width: <?php echo esc_attr( $optimized_pct ); ?>%"></div>
        </div>
        <?php endif; ?>

        <?php if ( $stats['errors'] > 0 ) : ?>
        <div style="font-size: 12px; margin-bottom: 8px;">
            <span class="mpio-dw-red"><?php echo esc_html( $stats['errors'] ); ?> <?php esc_html_e( 'errors', 'mpire-image-optimizer' ); ?></span>
        </div>
        <?php endif; ?>

        <div class="mpio-dw-links">
            <?php if ( $stats['unoptimized'] > 0 ) : ?>
                <a href="<?php echo esc_url( admin_url( 'upload.php?page=mpio-bulk-optimizer' ) ); ?>" class="button button-primary button-small">
                    <?php esc_html_e( 'Bulk Optimize', 'mpire-image-optimizer' ); ?>
                </a>
            <?php endif; ?>
            <a href="<?php echo esc_url( admin_url( 'options-general.php?page=mpio-settings' ) ); ?>">
                <?php esc_html_e( 'Settings', 'mpire-image-optimizer' ); ?>
            </a>
            <a href="<?php echo esc_url( admin_url( 'upload.php' ) ); ?>">
                <?php esc_html_e( 'Media Library', 'mpire-image-optimizer' ); ?>
            </a>
        </div>
        <?php
    }
}
