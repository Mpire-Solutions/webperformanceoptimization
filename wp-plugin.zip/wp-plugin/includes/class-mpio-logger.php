<?php
/**
 * Error logger for Mpire Image Optimizer.
 *
 * Writes optimization errors and debug info to a log file
 * at wp-content/uploads/mpio-backups/mpio-debug.log.
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

class MPIO_Logger {

    private static ?MPIO_Logger $instance = null;

    /** @var string Log file path. */
    private string $log_file;

    /** @var int Max log file size in bytes (2MB). */
    const MAX_LOG_SIZE = 2097152;

    /** @var int Max number of recent entries to keep on rotation. */
    const KEEP_LINES = 500;

    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $upload_dir     = wp_upload_dir();
        $this->log_file = $upload_dir['basedir'] . '/mpio-backups/mpio-debug.log';
    }

    /**
     * Log an info message.
     */
    public function info( string $message, array $context = [] ): void {
        $this->write( 'INFO', $message, $context );
    }

    /**
     * Log a warning message.
     */
    public function warning( string $message, array $context = [] ): void {
        $this->write( 'WARNING', $message, $context );
    }

    /**
     * Log an error message.
     */
    public function error( string $message, array $context = [] ): void {
        $this->write( 'ERROR', $message, $context );
    }

    /**
     * Log a debug message (only if WP_DEBUG is on).
     */
    public function debug( string $message, array $context = [] ): void {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            $this->write( 'DEBUG', $message, $context );
        }
    }

    /**
     * Write a log entry.
     */
    private function write( string $level, string $message, array $context = [] ): void {
        $this->maybe_rotate();

        $dir = dirname( $this->log_file );
        if ( ! file_exists( $dir ) ) {
            wp_mkdir_p( $dir );
        }

        $timestamp = current_time( 'Y-m-d H:i:s' );
        $line      = "[{$timestamp}] [{$level}] {$message}";

        if ( ! empty( $context ) ) {
            $line .= ' | ' . wp_json_encode( $context, JSON_UNESCAPED_SLASHES );
        }

        $line .= "\n";

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        file_put_contents( $this->log_file, $line, FILE_APPEND | LOCK_EX );
    }

    /**
     * Rotate log file if it exceeds max size.
     */
    private function maybe_rotate(): void {
        if ( ! file_exists( $this->log_file ) ) {
            return;
        }

        if ( filesize( $this->log_file ) < self::MAX_LOG_SIZE ) {
            return;
        }

        // Keep last N lines.
        $lines = file( $this->log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
        if ( $lines === false ) {
            return;
        }

        $lines = array_slice( $lines, -self::KEEP_LINES );
        file_put_contents( $this->log_file, implode( "\n", $lines ) . "\n" );
    }

    /**
     * Get log file path.
     */
    public function get_log_file(): string {
        return $this->log_file;
    }

    /**
     * Get recent log entries.
     */
    public function get_recent( int $count = 50 ): array {
        if ( ! file_exists( $this->log_file ) ) {
            return [];
        }

        $lines = file( $this->log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
        if ( $lines === false ) {
            return [];
        }

        return array_slice( $lines, -$count );
    }

    /**
     * Get log file size in bytes.
     */
    public function get_log_size(): int {
        if ( ! file_exists( $this->log_file ) ) {
            return 0;
        }
        return (int) filesize( $this->log_file );
    }

    /**
     * Clear the log file.
     */
    public function clear(): void {
        if ( file_exists( $this->log_file ) ) {
            file_put_contents( $this->log_file, '' );
        }
    }
}

/**
 * Global helper to log messages.
 */
function mpio_log( string $message, string $level = 'info', array $context = [] ): void {
    $logger = MPIO_Logger::get_instance();

    switch ( $level ) {
        case 'error':
            $logger->error( $message, $context );
            break;
        case 'warning':
            $logger->warning( $message, $context );
            break;
        case 'debug':
            $logger->debug( $message, $context );
            break;
        default:
            $logger->info( $message, $context );
    }
}
