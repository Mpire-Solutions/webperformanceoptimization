<?php
/**
 * REST API endpoints for Mpire Image Optimizer.
 *
 * Registers all REST API routes consumed by the React admin UI.
 *
 * @package Mpire_Image_Optimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MPIO_REST_API
 *
 * Provides REST API endpoints for statistics, settings, single-image
 * optimization, bulk optimization, image listing, and engine info.
 */
class MPIO_REST_API {

	/**
	 * Singleton instance.
	 *
	 * @var MPIO_REST_API|null
	 */
	private static $instance = null;

	/**
	 * REST API namespace.
	 *
	 * @var string
	 */
	const API_NAMESPACE = 'mpio/v1';

	/**
	 * Return the singleton instance.
	 *
	 * @return MPIO_REST_API
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor. Hook into rest_api_init to register routes.
	 */
	private function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register all REST API routes.
	 *
	 * @return void
	 */
	public function register_routes() {

		// GET /mpio/v1/stats
		register_rest_route(
			self::API_NAMESPACE,
			'/stats',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_stats' ),
				'permission_callback' => array( $this, 'check_manage_options' ),
			)
		);

		// GET /mpio/v1/settings
		register_rest_route(
			self::API_NAMESPACE,
			'/settings',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_settings' ),
				'permission_callback' => array( $this, 'check_manage_options' ),
			)
		);

		// POST /mpio/v1/settings
		register_rest_route(
			self::API_NAMESPACE,
			'/settings',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'update_settings' ),
				'permission_callback' => array( $this, 'check_manage_options' ),
				'args'                => array(
					'settings' => array(
						'required'          => true,
						'type'              => 'object',
						'sanitize_callback' => array( $this, 'sanitize_settings_param' ),
					),
				),
			)
		);

		// POST /mpio/v1/optimize/{id}
		register_rest_route(
			self::API_NAMESPACE,
			'/optimize/(?P<id>[\d]+)',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'optimize_image' ),
				'permission_callback' => array( $this, 'check_upload_files' ),
				'args'                => array(
					'id' => array(
						'required'          => true,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
						'validate_callback' => array( $this, 'validate_attachment_id' ),
					),
				),
			)
		);

		// POST /mpio/v1/restore/{id}
		register_rest_route(
			self::API_NAMESPACE,
			'/restore/(?P<id>[\d]+)',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'restore_image' ),
				'permission_callback' => array( $this, 'check_upload_files' ),
				'args'                => array(
					'id' => array(
						'required'          => true,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
						'validate_callback' => array( $this, 'validate_attachment_id' ),
					),
				),
			)
		);

		// GET /mpio/v1/bulk/status
		register_rest_route(
			self::API_NAMESPACE,
			'/bulk/status',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_bulk_status' ),
				'permission_callback' => array( $this, 'check_manage_options' ),
			)
		);

		// POST /mpio/v1/bulk/start
		register_rest_route(
			self::API_NAMESPACE,
			'/bulk/start',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'start_bulk' ),
				'permission_callback' => array( $this, 'check_manage_options' ),
			)
		);

		// POST /mpio/v1/bulk/stop
		register_rest_route(
			self::API_NAMESPACE,
			'/bulk/stop',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'stop_bulk' ),
				'permission_callback' => array( $this, 'check_manage_options' ),
			)
		);

		// GET /mpio/v1/images
		register_rest_route(
			self::API_NAMESPACE,
			'/images',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_images' ),
				'permission_callback' => array( $this, 'check_upload_files' ),
				'args'                => array(
					'page'     => array(
						'default'           => 1,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
						'minimum'           => 1,
					),
					'per_page' => array(
						'default'           => 20,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
						'minimum'           => 1,
						'maximum'           => 100,
					),
					'status'   => array(
						'default'           => 'all',
						'type'              => 'string',
						'enum'              => array( 'all', 'optimized', 'unoptimized', 'error' ),
						'sanitize_callback' => 'sanitize_text_field',
					),
					'orderby'  => array(
						'default'           => 'date',
						'type'              => 'string',
						'enum'              => array( 'date', 'title', 'modified', 'ID' ),
						'sanitize_callback' => 'sanitize_text_field',
					),
					'order'    => array(
						'default'           => 'DESC',
						'type'              => 'string',
						'enum'              => array( 'ASC', 'DESC' ),
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// GET /mpio/v1/engine
		register_rest_route(
			self::API_NAMESPACE,
			'/engine',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_engine_info' ),
				'permission_callback' => array( $this, 'check_manage_options' ),
			)
		);
	}

	// -------------------------------------------------------------------------
	// Permission callbacks
	// -------------------------------------------------------------------------

	/**
	 * Check if the current user has manage_options capability.
	 *
	 * @return bool|WP_Error
	 */
	public function check_manage_options() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'mpio_rest_forbidden',
				__( 'You do not have permission to access this resource.', 'mpire-image-optimizer' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * Check if the current user has upload_files capability.
	 *
	 * @return bool|WP_Error
	 */
	public function check_upload_files() {
		if ( ! current_user_can( 'upload_files' ) ) {
			return new WP_Error(
				'mpio_rest_forbidden',
				__( 'You do not have permission to access this resource.', 'mpire-image-optimizer' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	// -------------------------------------------------------------------------
	// Validation helpers
	// -------------------------------------------------------------------------

	/**
	 * Validate that a parameter is a valid attachment ID.
	 *
	 * @param mixed           $value   The parameter value.
	 * @param WP_REST_Request $request The current request.
	 * @param string          $param   The parameter name.
	 * @return bool|WP_Error
	 */
	public function validate_attachment_id( $value, $request, $param ) {
		$id = absint( $value );

		if ( $id <= 0 ) {
			return new WP_Error(
				'mpio_rest_invalid_id',
				__( 'Invalid attachment ID.', 'mpire-image-optimizer' ),
				array( 'status' => 400 )
			);
		}

		$post = get_post( $id );

		if ( ! $post || 'attachment' !== $post->post_type ) {
			return new WP_Error(
				'mpio_rest_not_found',
				__( 'Attachment not found.', 'mpire-image-optimizer' ),
				array( 'status' => 404 )
			);
		}

		if ( ! wp_attachment_is_image( $id ) ) {
			return new WP_Error(
				'mpio_rest_not_image',
				__( 'The specified attachment is not an image.', 'mpire-image-optimizer' ),
				array( 'status' => 400 )
			);
		}

		return true;
	}

	/**
	 * Sanitize the settings parameter for the update settings endpoint.
	 *
	 * @param mixed $value The raw settings value.
	 * @return array Sanitized settings array.
	 */
	public function sanitize_settings_param( $value ) {
		if ( is_string( $value ) ) {
			$value = json_decode( $value, true );
		}
		return is_array( $value ) ? $value : array();
	}

	// -------------------------------------------------------------------------
	// Endpoint callbacks
	// -------------------------------------------------------------------------

	/**
	 * GET /mpio/v1/stats
	 *
	 * Returns overall optimization statistics.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return WP_REST_Response
	 */
	public function get_stats( WP_REST_Request $request ) {
		global $wpdb;

		// Total image attachments.
		$total_images = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->posts}
			 WHERE post_type = 'attachment'
			 AND post_mime_type LIKE 'image/%'"
		);

		// Optimized images.
		$optimized_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
				 WHERE p.post_type = 'attachment'
				 AND p.post_mime_type LIKE 'image/%%'
				 AND pm.meta_key = '_mpio_status'
				 AND pm.meta_value = %s",
				'optimized'
			)
		);

		// Images with errors.
		$error_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
				 WHERE p.post_type = 'attachment'
				 AND p.post_mime_type LIKE 'image/%%'
				 AND pm.meta_key = '_mpio_status'
				 AND pm.meta_value = %s",
				'error'
			)
		);

		$unoptimized_count = $total_images - $optimized_count - $error_count;

		// Total bytes saved — data is in serialized _mpio_data meta.
		$all_data = $wpdb->get_col(
			"SELECT pm.meta_value FROM {$wpdb->postmeta} pm
			 INNER JOIN {$wpdb->postmeta} pm2 ON pm.post_id = pm2.post_id
			 WHERE pm.meta_key = '_mpio_data'
			 AND pm2.meta_key = '_mpio_status'
			 AND pm2.meta_value = 'optimized'"
		);

		$total_original  = 0;
		$total_optimized = 0;
		foreach ( $all_data as $raw ) {
			$data = maybe_unserialize( $raw );
			if ( is_array( $data ) ) {
				$total_original  += (int) ( $data['original_size'] ?? 0 );
				$total_optimized += (int) ( $data['optimized_size'] ?? 0 );
			}
		}

		$total_saved   = max( 0, $total_original - $total_optimized );
		$savings_pct   = $total_original > 0 ? round( ( $total_saved / $total_original ) * 100, 1 ) : 0;

		// Backup stats.
		$backup_stats = MPIO_Backup::get_instance()->get_backup_stats();

		$data = array(
			'total_images'      => $total_images,
			'optimized_count'   => $optimized_count,
			'unoptimized_count' => $unoptimized_count,
			'error_count'       => $error_count,
			'total_original'    => $total_original,
			'total_optimized'   => $total_optimized,
			'total_saved'       => $total_saved,
			'savings_percent'   => $savings_pct,
			'total_saved_human' => mpio_format_bytes( $total_saved ),
			'backup'            => $backup_stats,
		);

		return new WP_REST_Response( $data, 200 );
	}

	/**
	 * GET /mpio/v1/settings
	 *
	 * Returns the current plugin settings.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return WP_REST_Response
	 */
	public function get_settings( WP_REST_Request $request ) {
		$settings = get_option( MPIO_Settings::OPTION_NAME, array() );
		$defaults = mpio_get_default_settings();
		$merged   = wp_parse_args( $settings, $defaults );

		return new WP_REST_Response( $merged, 200 );
	}

	/**
	 * POST /mpio/v1/settings
	 *
	 * Updates the plugin settings.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return WP_REST_Response
	 */
	public function update_settings( WP_REST_Request $request ) {
		$new_settings = $request->get_param( 'settings' );

		if ( ! is_array( $new_settings ) || empty( $new_settings ) ) {
			return new WP_REST_Response(
				array(
					'code'    => 'mpio_rest_invalid_settings',
					'message' => __( 'Invalid settings data.', 'mpire-image-optimizer' ),
				),
				400
			);
		}

		// Use the Settings class sanitizer to ensure consistency.
		$sanitized = MPIO_Settings::get_instance()->sanitize_settings( $new_settings );

		update_option( MPIO_Settings::OPTION_NAME, $sanitized );

		return new WP_REST_Response(
			array(
				'message'  => __( 'Settings saved successfully.', 'mpire-image-optimizer' ),
				'settings' => $sanitized,
			),
			200
		);
	}

	/**
	 * POST /mpio/v1/optimize/{id}
	 *
	 * Optimizes a single attachment image.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return WP_REST_Response
	 */
	public function optimize_image( WP_REST_Request $request ) {
		$attachment_id = (int) $request->get_param( 'id' );

		// Create a backup before optimization.
		$file_path = get_attached_file( $attachment_id );

		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return new WP_REST_Response(
				array(
					'code'    => 'mpio_rest_file_not_found',
					'message' => __( 'Image file not found.', 'mpire-image-optimizer' ),
				),
				404
			);
		}

		if ( mpio_get_setting( 'keep_backup' ) ) {
			MPIO_Backup::get_instance()->backup( $attachment_id, $file_path );
		}

		$result = MPIO_Optimizer::get_instance()->optimize( $attachment_id );

		if ( empty( $result['success'] ) ) {
			return new WP_REST_Response(
				array(
					'code'    => 'mpio_rest_optimization_failed',
					'message' => __( 'Optimization failed.', 'mpire-image-optimizer' ),
				),
				500
			);
		}

		return new WP_REST_Response(
			array(
				'message' => __( 'Image optimized successfully.', 'mpire-image-optimizer' ),
				'data'    => $result,
			),
			200
		);
	}

	/**
	 * POST /mpio/v1/restore/{id}
	 *
	 * Restores an attachment to its original from backup.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return WP_REST_Response
	 */
	public function restore_image( WP_REST_Request $request ) {
		$attachment_id = (int) $request->get_param( 'id' );

		$backup = MPIO_Backup::get_instance();

		if ( ! $backup->has_backup( $attachment_id ) ) {
			return new WP_REST_Response(
				array(
					'code'    => 'mpio_rest_no_backup',
					'message' => __( 'No backup found for this image.', 'mpire-image-optimizer' ),
				),
				404
			);
		}

		$result = $backup->restore( $attachment_id );

		if ( false === $result ) {
			return new WP_REST_Response(
				array(
					'code'    => 'mpio_rest_restore_failed',
					'message' => __( 'Failed to restore image from backup.', 'mpire-image-optimizer' ),
				),
				500
			);
		}

		return new WP_REST_Response(
			array(
				'message' => __( 'Image restored successfully.', 'mpire-image-optimizer' ),
			),
			200
		);
	}

	/**
	 * GET /mpio/v1/bulk/status
	 *
	 * Returns the current bulk optimization progress.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return WP_REST_Response
	 */
	public function get_bulk_status( WP_REST_Request $request ) {
		$bulk_optimizer = MPIO_Bulk_Optimizer::get_instance();

		$data = array(
			'is_running' => $bulk_optimizer->is_running(),
			'progress'   => $bulk_optimizer->get_progress(),
		);

		return new WP_REST_Response( $data, 200 );
	}

	/**
	 * POST /mpio/v1/bulk/start
	 *
	 * Starts the bulk optimization process.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return WP_REST_Response
	 */
	public function start_bulk( WP_REST_Request $request ) {
		$bulk_optimizer = MPIO_Bulk_Optimizer::get_instance();

		if ( $bulk_optimizer->is_running() ) {
			return new WP_REST_Response(
				array(
					'code'    => 'mpio_rest_bulk_already_running',
					'message' => __( 'Bulk optimization is already in progress.', 'mpire-image-optimizer' ),
				),
				409
			);
		}

		$result = $bulk_optimizer->start();

		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response(
				array(
					'code'    => $result->get_error_code(),
					'message' => $result->get_error_message(),
				),
				500
			);
		}

		return new WP_REST_Response(
			array(
				'message'  => __( 'Bulk optimization started.', 'mpire-image-optimizer' ),
				'progress' => $bulk_optimizer->get_progress(),
			),
			200
		);
	}

	/**
	 * POST /mpio/v1/bulk/stop
	 *
	 * Stops the bulk optimization process.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return WP_REST_Response
	 */
	public function stop_bulk( WP_REST_Request $request ) {
		$bulk_optimizer = MPIO_Bulk_Optimizer::get_instance();

		if ( ! $bulk_optimizer->is_running() ) {
			return new WP_REST_Response(
				array(
					'code'    => 'mpio_rest_bulk_not_running',
					'message' => __( 'No bulk optimization is currently running.', 'mpire-image-optimizer' ),
				),
				400
			);
		}

		$bulk_optimizer->stop();

		return new WP_REST_Response(
			array(
				'message' => __( 'Bulk optimization stopped.', 'mpire-image-optimizer' ),
			),
			200
		);
	}

	/**
	 * GET /mpio/v1/images
	 *
	 * Returns a paginated list of images with their optimization status.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return WP_REST_Response
	 */
	public function get_images( WP_REST_Request $request ) {
		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) );
		$status   = sanitize_text_field( $request->get_param( 'status' ) );
		$orderby  = sanitize_text_field( $request->get_param( 'orderby' ) );
		$order    = strtoupper( sanitize_text_field( $request->get_param( 'order' ) ) );

		// Validate order direction.
		if ( ! in_array( $order, array( 'ASC', 'DESC' ), true ) ) {
			$order = 'DESC';
		}

		// Validate orderby.
		$allowed_orderby = array( 'date', 'title', 'modified', 'ID' );
		if ( ! in_array( $orderby, $allowed_orderby, true ) ) {
			$orderby = 'date';
		}

		// Build query args.
		$query_args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => $orderby,
			'order'          => $order,
		);

		// Apply status filter via meta query.
		switch ( $status ) {
			case 'optimized':
				$query_args['meta_query'] = array(
					array(
						'key'     => '_mpio_status',
						'value'   => 'optimized',
						'compare' => '=',
					),
				);
				break;

			case 'unoptimized':
				$query_args['meta_query'] = array(
					'relation' => 'OR',
					array(
						'key'     => '_mpio_status',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => '_mpio_status',
						'value'   => '',
						'compare' => '=',
					),
				);
				break;

			case 'error':
				$query_args['meta_query'] = array(
					array(
						'key'     => '_mpio_status',
						'value'   => 'error',
						'compare' => '=',
					),
				);
				break;
		}

		$query  = new WP_Query( $query_args );
		$images = array();

		foreach ( $query->posts as $post ) {
			$mpio_status = get_post_meta( $post->ID, '_mpio_status', true );
			$mpio_data   = get_post_meta( $post->ID, '_mpio_data', true );
			$mpio_error  = get_post_meta( $post->ID, '_mpio_error', true );
			$file_path   = get_attached_file( $post->ID );
			$has_backup  = MPIO_Backup::get_instance()->has_backup( $post->ID );

			$original_size   = 0;
			$opt_size        = 0;
			$savings_percent = 0;
			if ( is_array( $mpio_data ) ) {
				$original_size   = (int) ( $mpio_data['original_size'] ?? 0 );
				$opt_size        = (int) ( $mpio_data['optimized_size'] ?? 0 );
				$savings_percent = (float) ( $mpio_data['savings_percent'] ?? 0 );
			}

			$images[] = array(
				'id'              => $post->ID,
				'title'           => get_the_title( $post->ID ),
				'filename'        => $file_path ? wp_basename( $file_path ) : '',
				'url'             => wp_get_attachment_url( $post->ID ),
				'thumbnail'       => wp_get_attachment_image_url( $post->ID, 'thumbnail' ),
				'mime_type'       => $post->post_mime_type,
				'date'            => $post->post_date,
				'status'          => $mpio_status ? $mpio_status : 'unoptimized',
				'original_size'   => $original_size ?: ( $file_path && file_exists( $file_path ) ? filesize( $file_path ) : 0 ),
				'optimized_size'  => $opt_size,
				'savings_percent' => $savings_percent,
				'error_message'   => $mpio_error ? $mpio_error : '',
				'has_backup'      => $has_backup,
			);
		}

		$data = array(
			'images'      => $images,
			'total'       => (int) $query->found_posts,
			'total_pages' => (int) $query->max_num_pages,
			'page'        => $page,
			'per_page'    => $per_page,
		);

		$response = new WP_REST_Response( $data, 200 );

		// Set pagination headers for convenience.
		$response->header( 'X-WP-Total', (int) $query->found_posts );
		$response->header( 'X-WP-TotalPages', (int) $query->max_num_pages );

		return $response;
	}

	/**
	 * GET /mpio/v1/engine
	 *
	 * Returns information about the active image processing engine.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @return WP_REST_Response
	 */
	public function get_engine_info( WP_REST_Request $request ) {
		$active_engine = mpio_get_engine();

		$gd_available      = extension_loaded( 'gd' );
		$imagick_available = extension_loaded( 'imagick' );

		$gd_info = $gd_available ? gd_info() : array();

		$imagick_formats = array();
		if ( $imagick_available ) {
			try {
				$imagick         = new Imagick();
				$imagick_formats = $imagick->queryFormats();
			} catch ( Exception $e ) {
				$imagick_formats = array();
			}
		}

		$data = array(
			'active_engine'     => $active_engine,
			'preferred_engine'  => mpio_get_setting( 'preferred_engine', 'auto' ),
			'gd'                => array(
				'available'    => $gd_available,
				'version'      => isset( $gd_info['GD Version'] ) ? $gd_info['GD Version'] : null,
				'webp_support' => ! empty( $gd_info['WebP Support'] ),
				'avif_support' => ! empty( $gd_info['AVIF Support'] ),
				'jpeg_support' => ! empty( $gd_info['JPEG Support'] ),
				'png_support'  => ! empty( $gd_info['PNG Support'] ),
			),
			'imagick'           => array(
				'available'    => $imagick_available,
				'version'      => $imagick_available && class_exists( 'Imagick' ) ? Imagick::getVersion()['versionString'] ?? null : null,
				'webp_support' => in_array( 'WEBP', $imagick_formats, true ),
				'avif_support' => in_array( 'AVIF', $imagick_formats, true ),
				'jpeg_support' => in_array( 'JPEG', $imagick_formats, true ),
				'png_support'  => in_array( 'PNG', $imagick_formats, true ),
			),
			'php_version'       => PHP_VERSION,
			'php_memory_limit'  => ini_get( 'memory_limit' ),
			'max_execution_time' => (int) ini_get( 'max_execution_time' ),
		);

		return new WP_REST_Response( $data, 200 );
	}
}
