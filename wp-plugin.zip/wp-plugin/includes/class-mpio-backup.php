<?php
/**
 * Backup and restore functionality for Mpire Image Optimizer.
 *
 * @package Mpire_Image_Optimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MPIO_Backup
 *
 * Handles backup and restoration of original image files
 * before optimization.
 */
class MPIO_Backup {

	/**
	 * Singleton instance.
	 *
	 * @var MPIO_Backup|null
	 */
	private static $instance = null;

	/**
	 * Base backup directory path.
	 *
	 * @var string
	 */
	private $backup_dir;

	/**
	 * Get singleton instance.
	 *
	 * @return MPIO_Backup
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$upload_dir       = wp_upload_dir();
		$this->backup_dir = $upload_dir['basedir'] . '/mpio-backups';

		// Clean up backups when an attachment is deleted.
		add_action( 'delete_attachment', array( $this, 'delete_backup' ) );

		// Schedule cleanup cron if keep_backup is enabled.
		$keep_backup = mpio_get_setting( 'keep_backup', true );
		if ( $keep_backup && ! wp_next_scheduled( 'mpio_cleanup_backups_cron' ) ) {
			wp_schedule_event( time(), 'daily', 'mpio_cleanup_backups_cron' );
		}

		add_action( 'mpio_cleanup_backups_cron', array( $this, 'cleanup_old_backups' ) );
	}

	/**
	 * Create a backup of the original file before optimization.
	 *
	 * @param int    $attachment_id The attachment post ID.
	 * @param string $file_path     Absolute path to the original file.
	 * @return bool True on success, false on failure.
	 */
	public function backup( int $attachment_id, string $file_path ): bool {
		if ( ! file_exists( $file_path ) ) {
			return false;
		}

		$year     = gmdate( 'Y' );
		$month    = gmdate( 'm' );
		$filename = wp_basename( $file_path );

		$dest_dir = $this->get_backup_dir() . '/' . $year . '/' . $month;

		if ( ! wp_mkdir_p( $dest_dir ) ) {
			return false;
		}

		$dest_path = $dest_dir . '/' . $filename;

		// If a backup already exists for this attachment, remove it first.
		$existing = $this->get_backup_path( $attachment_id );
		if ( $existing && file_exists( $existing ) && $existing !== $dest_path ) {
			wp_delete_file( $existing );
		}

		if ( ! copy( $file_path, $dest_path ) ) {
			return false;
		}

		update_post_meta( $attachment_id, '_mpio_backup_path', $dest_path );

		return true;
	}

	/**
	 * Restore an attachment from its backup.
	 *
	 * Copies the backup file back to the original location, removes
	 * optimization metadata, and deletes any generated WebP/AVIF files.
	 *
	 * @param int $attachment_id The attachment post ID.
	 * @return bool True on success, false on failure.
	 */
	public function restore( int $attachment_id ): bool {
		$backup_path = $this->get_backup_path( $attachment_id );

		if ( ! $backup_path || ! file_exists( $backup_path ) ) {
			return false;
		}

		$original_path = get_attached_file( $attachment_id );

		if ( ! $original_path ) {
			return false;
		}

		// Ensure the destination directory exists.
		$original_dir = dirname( $original_path );
		if ( ! wp_mkdir_p( $original_dir ) ) {
			return false;
		}

		if ( ! copy( $backup_path, $original_path ) ) {
			return false;
		}

		// Remove optimization meta.
		delete_post_meta( $attachment_id, '_mpio_data' );
		delete_post_meta( $attachment_id, '_mpio_status' );

		// Delete generated WebP and AVIF conversion files.
		$this->delete_conversion_files( $original_path );

		// Delete companion files tracked in meta (WebP/AVIF versions).
		$companions = get_post_meta( $attachment_id, '_mpio_companions', true );
		if ( is_array( $companions ) ) {
			foreach ( $companions as $companion_path ) {
				if ( file_exists( $companion_path ) ) {
					@unlink( $companion_path );
				}
			}
		}
		delete_post_meta( $attachment_id, '_mpio_companions' );

		return true;
	}

	/**
	 * Check whether a backup exists for the given attachment.
	 *
	 * @param int $attachment_id The attachment post ID.
	 * @return bool True if backup file exists.
	 */
	public function has_backup( int $attachment_id ): bool {
		$backup_path = $this->get_backup_path( $attachment_id );
		return $backup_path && file_exists( $backup_path );
	}

	/**
	 * Get the backup file path for an attachment.
	 *
	 * @param int $attachment_id The attachment post ID.
	 * @return string|null The backup path, or null if not set.
	 */
	public function get_backup_path( int $attachment_id ): ?string {
		$path = get_post_meta( $attachment_id, '_mpio_backup_path', true );
		return $path ? (string) $path : null;
	}

	/**
	 * Delete a backup file and its associated meta.
	 *
	 * @param int $attachment_id The attachment post ID.
	 * @return bool True on success, false on failure.
	 */
	public function delete_backup( int $attachment_id ): bool {
		$backup_path = $this->get_backup_path( $attachment_id );

		if ( $backup_path && file_exists( $backup_path ) ) {
			wp_delete_file( $backup_path );
		}

		delete_post_meta( $attachment_id, '_mpio_backup_path' );

		return true;
	}

	/**
	 * Clean up backups older than the configured retention period.
	 *
	 * Hooked to 'mpio_cleanup_backups_cron'. Only runs when
	 * keep_backup is enabled.
	 *
	 * @return void
	 */
	public function cleanup_old_backups(): void {
		if ( ! mpio_get_setting( 'keep_backup', true ) ) {
			return;
		}

		$backup_days = (int) mpio_get_setting( 'backup_days', 30 );

		// 0 means keep forever.
		if ( 0 === $backup_days ) {
			return;
		}
		$threshold   = time() - ( $backup_days * DAY_IN_SECONDS );
		$backup_dir  = $this->get_backup_dir();

		if ( ! is_dir( $backup_dir ) ) {
			return;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $backup_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $iterator as $file ) {
			if ( $file->isFile() && $file->getMTime() < $threshold ) {
				$file_path = $file->getPathname();

				// Find the attachment that references this backup and clean its meta.
				$attachment_ids = get_posts(
					array(
						'post_type'  => 'attachment',
						'meta_key'   => '_mpio_backup_path',
						'meta_value' => $file_path,
						'fields'     => 'ids',
						'numberposts' => 1,
					)
				);

				if ( ! empty( $attachment_ids ) ) {
					delete_post_meta( $attachment_ids[0], '_mpio_backup_path' );
				}

				wp_delete_file( $file_path );
			}
		}

		// Remove empty subdirectories.
		$dir_iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $backup_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $dir_iterator as $item ) {
			if ( $item->isDir() ) {
				$dir_path = $item->getPathname();
				// Only remove if the directory is empty.
				if ( count( glob( $dir_path . '/*' ) ) === 0 ) {
					rmdir( $dir_path );
				}
			}
		}
	}

	/**
	 * Get statistics about current backups.
	 *
	 * @return array {
	 *     @type int         $total_backups Number of backup files.
	 *     @type int         $total_size    Total size in bytes.
	 *     @type string|null $oldest_backup Datetime of the oldest backup, or null.
	 * }
	 */
	public function get_backup_stats(): array {
		$stats = array(
			'total_backups' => 0,
			'total_size'    => 0,
			'oldest_backup' => null,
		);

		$backup_dir = $this->get_backup_dir();

		if ( ! is_dir( $backup_dir ) ) {
			return $stats;
		}

		$oldest_time = PHP_INT_MAX;

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $backup_dir, RecursiveDirectoryIterator::SKIP_DOTS )
		);

		foreach ( $iterator as $file ) {
			if ( $file->isFile() ) {
				$stats['total_backups']++;
				$stats['total_size'] += $file->getSize();

				$mtime = $file->getMTime();
				if ( $mtime < $oldest_time ) {
					$oldest_time = $mtime;
				}
			}
		}

		if ( $stats['total_backups'] > 0 ) {
			$stats['oldest_backup'] = gmdate( 'Y-m-d H:i:s', $oldest_time );
		}

		return $stats;
	}

	/**
	 * Get the backup directory path, creating it if it does not exist.
	 *
	 * @return string The backup directory path.
	 */
	public function get_backup_dir(): string {
		if ( ! is_dir( $this->backup_dir ) ) {
			wp_mkdir_p( $this->backup_dir );

			// Protect the directory from direct web access.
			$htaccess = $this->backup_dir . '/.htaccess';
			if ( ! file_exists( $htaccess ) ) {
				file_put_contents( $htaccess, "Deny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			}

			$index = $this->backup_dir . '/index.php';
			if ( ! file_exists( $index ) ) {
				file_put_contents( $index, "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			}
		}

		return $this->backup_dir;
	}

	/**
	 * Delete WebP and AVIF conversion files for a given original file.
	 *
	 * @param string $original_path The path to the original image file.
	 * @return void
	 */
	public function delete_conversion_files( string $original_path ): void {
		$webp_path = $original_path . '.webp';
		$avif_path = $original_path . '.avif';

		if ( file_exists( $webp_path ) ) {
			wp_delete_file( $webp_path );
		}

		if ( file_exists( $avif_path ) ) {
			wp_delete_file( $avif_path );
		}

		// Also check for conversions with replaced extensions.
		$pathinfo  = pathinfo( $original_path );
		$base_path = $pathinfo['dirname'] . '/' . $pathinfo['filename'];

		$webp_alt = $base_path . '.webp';
		$avif_alt = $base_path . '.avif';

		if ( $webp_alt !== $webp_path && file_exists( $webp_alt ) ) {
			wp_delete_file( $webp_alt );
		}

		if ( $avif_alt !== $avif_path && file_exists( $avif_alt ) ) {
			wp_delete_file( $avif_alt );
		}
	}
}
