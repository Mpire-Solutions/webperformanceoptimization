<?php
/**
 * CDN compatibility for Mpire Image Optimizer.
 *
 * Fires cache purge actions after image optimization for popular
 * CDN/cache plugins (Cloudflare, WP Rocket, W3 Total Cache, etc.).
 *
 * @package Mpire_Image_Optimizer
 */

defined( 'ABSPATH' ) || exit;

class MPIO_CDN_Compat {

    private static ?MPIO_CDN_Compat $instance = null;

    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Purge cache after single image optimization.
        add_action( 'mpio_after_optimize', [ $this, 'purge_image_cache' ], 10, 2 );

        // Purge cache after auto-optimize on upload.
        add_action( 'mpio_after_auto_optimize', [ $this, 'purge_image_cache' ], 10, 2 );

        // Purge all caches after bulk optimization completes.
        add_action( 'mpio_bulk_complete', [ $this, 'purge_all_cache' ] );
    }

    /**
     * Purge cache for a single image after optimization.
     */
    public function purge_image_cache( int $attachment_id, array $result = [] ): void {
        $url = wp_get_attachment_url( $attachment_id );
        if ( ! $url ) {
            return;
        }

        // Collect all URLs to purge (main + companions).
        $urls = [ $url ];

        // Add companion URLs (WebP/AVIF).
        $companions = get_post_meta( $attachment_id, '_mpio_companions', true );
        if ( is_array( $companions ) ) {
            $upload_dir = wp_upload_dir();
            foreach ( $companions as $path ) {
                $companion_url = str_replace( $upload_dir['basedir'], $upload_dir['baseurl'], $path );
                $urls[]        = $companion_url;
            }
        }

        // Add thumbnail URLs.
        $metadata = wp_get_attachment_metadata( $attachment_id );
        if ( ! empty( $metadata['sizes'] ) ) {
            $base_url = dirname( $url );
            foreach ( $metadata['sizes'] as $size_data ) {
                $urls[] = $base_url . '/' . $size_data['file'];
            }
        }

        $this->purge_urls( $urls );

        /**
         * Allow other plugins/themes to react to cache purge.
         *
         * @param int   $attachment_id The attachment that was optimized.
         * @param array $urls          URLs that were purged.
         */
        do_action( 'mpio_cache_purged', $attachment_id, $urls );
    }

    /**
     * Purge all caches after bulk optimization.
     */
    public function purge_all_cache(): void {
        // WP Rocket.
        if ( function_exists( 'rocket_clean_domain' ) ) {
            rocket_clean_domain();
        }

        // W3 Total Cache.
        if ( function_exists( 'w3tc_flush_all' ) ) {
            w3tc_flush_all();
        }

        // WP Super Cache.
        if ( function_exists( 'wp_cache_clear_cache' ) ) {
            wp_cache_clear_cache();
        }

        // LiteSpeed Cache.
        if ( class_exists( 'LiteSpeed_Cache_API' ) && method_exists( 'LiteSpeed_Cache_API', 'purge_all' ) ) {
            \LiteSpeed_Cache_API::purge_all();
        }
        // LiteSpeed Cache v4+.
        if ( class_exists( '\LiteSpeed\Purge' ) && method_exists( '\LiteSpeed\Purge', 'purge_all' ) ) {
            \LiteSpeed\Purge::purge_all();
        }

        // Cloudflare (via WP Cloudflare Super Page Cache or CF plugin).
        if ( class_exists( 'CF\WordPress\Hooks' ) ) {
            do_action( 'cloudflare_purge_everything' );
        }

        // SG Optimizer (SiteGround).
        if ( function_exists( 'sg_cachepress_purge_everything' ) ) {
            sg_cachepress_purge_everything();
        }

        // Autoptimize.
        if ( class_exists( 'autoptimizeCache' ) && method_exists( 'autoptimizeCache', 'clearall' ) ) {
            \autoptimizeCache::clearall();
        }

        // Kinsta Cache.
        if ( class_exists( '\Jeero\KinstaMUPlugins\Cache\Cache' ) ) {
            wp_remote_get( home_url( '/?kinsta-clear-cache-all' ), [ 'timeout' => 5 ] );
        }

        // Generic: fire a hook others can use.
        do_action( 'mpio_purge_all_cache' );
    }

    /**
     * Purge specific URLs from caches.
     */
    private function purge_urls( array $urls ): void {
        if ( empty( $urls ) ) {
            return;
        }

        // WP Rocket — purge by URL.
        if ( function_exists( 'rocket_clean_files' ) ) {
            rocket_clean_files( $urls );
        }

        // W3 Total Cache — purge by URL.
        if ( function_exists( 'w3tc_flush_url' ) ) {
            foreach ( $urls as $url ) {
                w3tc_flush_url( $url );
            }
        }

        // LiteSpeed Cache — purge by URL.
        if ( class_exists( 'LiteSpeed_Cache_API' ) && method_exists( 'LiteSpeed_Cache_API', 'purge_url' ) ) {
            foreach ( $urls as $url ) {
                \LiteSpeed_Cache_API::purge_url( $url );
            }
        }

        // SG Optimizer — purge by URL.
        if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
            foreach ( $urls as $url ) {
                sg_cachepress_purge_cache( $url );
            }
        }

        // Nginx Helper.
        if ( class_exists( 'Jeero\NginxHelper\Admin' ) || function_exists( 'rt_nginx_helper_purge_url' ) ) {
            foreach ( $urls as $url ) {
                if ( function_exists( 'rt_nginx_helper_purge_url' ) ) {
                    rt_nginx_helper_purge_url( $url );
                }
            }
        }

        // Varnish / Proxy purge.
        if ( class_exists( 'VarnishPurger' ) ) {
            foreach ( $urls as $url ) {
                do_action( 'varnish_http_purge_url', $url );
            }
        }

        // Generic hook for custom CDN integrations.
        do_action( 'mpio_purge_urls', $urls );
    }
}
